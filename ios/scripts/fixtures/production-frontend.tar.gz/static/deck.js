// Pixel Deck pages built from feeds: Cluster, Launch, Dev, Life (v6), Keys connections, Home products, Today sections (v7).
// Loaded after app.js and uses its globals ($, $$, jget, esc, todayLast, ensureToday, pname).
// ==== DECK V6 UI HELPERS BEGIN (pure: no DOM, no fetch, no globals; tests/deck_v6_ui.test.js loads this block) ====
const DeckUI=(()=>{
 const esc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const isObj=x=>x!==null&&typeof x==='object'&&!Array.isArray(x);
 const arr=x=>Array.isArray(x)?x:[];
 const num=v=>typeof v==='number'&&isFinite(v)?v:null;
 const str=(v,n)=>typeof v==='string'?v.trim().slice(0,n||120):'';
 const SD=k=>'<i class="sd '+k+'"></i>';
 // null is never zero: unknown prints "--", a measured 0 prints "0"
 const fmt=(v,d,unit)=>{const n=num(v);if(n==null)return '--';return (d?n.toFixed(d):String(Math.round(n)))+(unit||'')};
 const toEpoch=v=>{if(num(v)!=null)return v>1e12?v/1000:v;if(typeof v==='string'&&v){const p=Date.parse(v);return isFinite(p)?p/1000:null}return null};
 // relative times a person says out loud: "just now", "2 min ago", "3 h ago", "4 d ago"
 function lapse(x,now){const s=Math.max(0,Math.round(now/1000-x));return s<45?'':s<5400?Math.max(1,Math.round(s/60))+' min':s<172800?Math.round(s/3600)+' h':Math.round(s/86400)+' d'}
 function ago(t,now){const x=toEpoch(t);if(x==null)return 'time unknown';const p=lapse(x,now);return p?p+' ago':'just now'}
 // how long something has been going on, without the word "ago"
 function dur(t,now){const x=toEpoch(t);return x==null?'':lapse(x,now)||'under a minute'}
 function until(t,now){const x=toEpoch(t);if(x==null)return 'time unknown';const s=Math.round(x-now/1000);if(s<=0)return 'due';
  return s<5400?'in '+Math.max(1,Math.round(s/60))+' min':s<172800?'in '+Math.round(s/3600)+' h':'in '+Math.round(s/86400)+' d'}
 function clock(t){const x=toEpoch(t);if(x==null)return '--';const d=new Date(x*1000);return d.toLocaleDateString([],{weekday:'short'})+' '+d.toLocaleTimeString([],{hour:'numeric',minute:'2-digit'})}
 const hm=t=>{const x=toEpoch(t);if(x==null)return '--:--';const d=new Date(x*1000);return String(d.getHours()).padStart(2,'0')+':'+String(d.getMinutes()).padStart(2,'0')};
 const usd=v=>{const n=num(v);if(n==null)return '--';return n>=1e6?'$'+(n/1e6).toFixed(n>=1e7?1:2).replace(/\.?0+$/,'')+'M':n>=1e3?'$'+Math.round(n/1e3)+'K':'$'+Math.round(n)};
 const compass=d=>{const n=num(d);if(n==null)return '';return ['N','NE','E','SE','S','SW','W','NW'][Math.round(((n%360)+360)%360/45)%8]};
const safeUrl=u=>typeof u==='string'&&/^https?:\/\/[^\s"'<>\\@]+$/i.test(u)?u:'';
 // ---- copy: no file names, endpoints, ports, raw ids or HTTP codes on screen. Anything technical rides in a hidden .diag span that the
 // detail sheet shows under "Details". Home folders read "~" and account flags are masked there too. ----
 // ONE home-folder rule for the whole deck (run prose, unit logs, tool arguments, Today diagnostics): /home/<user>, /Users/<user>, /root and $HOME become ~
 // wherever a path starts: at the start of the text, after a space or punctuation (, > | { ( [ = : " ' `), after file://, after a glued flag (-C/home/x) and when
 // JSON escapes the slashes (\/home\/x). Never the middle of a path (/opt/home/x, /mnt/home/x stay).
 const HOME_RE=/(^|[^A-Za-z0-9_.\/\\~-]|(?:^|\s)-[A-Za-z]|file:\/\/)(?:\\?\/home\\?\/[A-Za-z0-9._-]+|\\?\/Users\\?\/[A-Za-z0-9._-]+|\\?\/root(?![A-Za-z0-9_-])|\$(?:HOME(?![A-Za-z0-9_])|\{HOME\}))/g;
 const homeTilde=s=>String(s==null?'':s).replace(HOME_RE,'$1~');
 // ONE credential scanner for every line that can reach the screen. It is the same algorithm as rust/src/actions.rs `redact` and scripts/deck-launch
 // `redact_line`; tests/fixtures/redact-cases.json runs through all three. A credential name (a whole word: key, token, secret, password, session ...,
 // also inside API_SERVER_KEY or accessToken) takes its value (quoted values whole, JSON `"name":"value"`, Authorization and Cookie to the end of the line);
 // known token shapes, `Bearer x`, `Basic x`, `?k=x` and url userinfo go wherever they stand. opts.mark replaces what was cut (default [redacted]);
 // opts.query also cuts url query strings and fragments (tool arguments do; prose keeps its links).
 const SECRET_WORDS=new Set(['key','token','secret','password','passwd','passphrase','auth','authorization','cookie','credential','credentials','apikey','apitoken','authtoken','accesstoken','privatekey','session','sessionid','pdeck']);
 const REST_WORDS=new Set(['authorization','cookie']);
 const isUp=c=>c>='A'&&c<='Z',isLow=c=>c>='a'&&c<='z',isDig=c=>c>='0'&&c<='9',isAlnum=c=>isUp(c)||isLow(c)||isDig(c);
 function nameWords(name){const ch=Array.from(name),words=[];let cur='';
  for(let i=0;i<ch.length;i++){const c=ch[i];
   if(!isAlnum(c)){if(cur){words.push(cur);cur=''}continue}
   if(cur&&i>0){const p=ch[i-1],nextLow=i+1<ch.length&&isLow(ch[i+1]);
    if((isUp(c)&&isLow(p))||(isUp(c)&&isUp(p)&&nextLow)||isDig(c)!==isDig(p)){words.push(cur);cur=''}}
   cur+=c.toLowerCase()}
  if(cur)words.push(cur);return words}
 const secretName=n=>nameWords(n).some(w=>SECRET_WORDS.has(w));
 const restName=n=>nameWords(n).some(w=>REST_WORDS.has(w));
 // known credential shapes, on the lower-cased name-like run: prefix plus a body of at least n characters (al: letters and digits only)
 function secretShape(low){const body=(p,n,al)=>{if(!low.startsWith(p))return false;const r=low.slice(p.length);return r.length>=(n||8)&&(!al||/^[a-z0-9]+$/.test(r))};
  return ['sk-','sk_','pk_','rk_','rk-','ghp_','gho_','ghs_','ghu_','github_pat_','xoxb-','xoxa-','xoxp-','xoxr-','xoxs-','akia'].some(p=>body(p))||body('glpat-',16)||body('hf_',16,1)||body('npm_',16,1)||body('aiza',16)||(low.startsWith('eyj')&&low.length>=20)}
 const nameByte=c=>isAlnum(c)||c==='_'||c==='-'||c==='.';
 const valueEnd=c=>' ,;&)}]"\''.includes(c);
 // `Basic dXNlcjpwYXNz`: base64 of at least 8 characters that is not an ordinary word (a digit, = + / or a capital after the first letter)
 const b64Cred=c=>c.length>=8&&/^[A-Za-z0-9+\/=]+$/.test(c)&&(/[0-9+\/=]/.test(c)||/[A-Z]/.test(c.slice(1)));
 function redactLine(line,mark){const L=line.length;let out='',i=0;
  while(i<L){const ch=line[i];
   if(!nameByte(ch)){out+=ch;i++;continue}
   const start=i;while(i<L&&nameByte(line[i]))i++;
   const run=line.slice(start,i),low=run.toLowerCase();
   if(low==='bearer'){out+=run;let j=i;while(j<L&&line[j]===' ')j++;
    if(j>i&&j<L){let k=j;while(k<L&&line[k]!==' ')k++;out+=line.slice(i,j);const w=line.slice(j,k);
     // a name after a stray `Bearer` (`password:`, `KEY=`) is scanned as a name, not eaten as the token
     if(w.endsWith(':')||w.endsWith('='))i=j;else{out+=mark;i=k}}
    continue}
   if(low==='basic'){out+=run;let j=i;while(j<L&&line[j]===' ')j++;
    if(j>i){let k=j;while(k<L&&/[A-Za-z0-9+\/=]/.test(line[k]))k++;
     if(b64Cred(line.slice(j,k))&&(k>=L||valueEnd(line[k]))){out+=line.slice(i,j)+mark;i=k}}
    continue}
   if(secretShape(low)){out+=mark;continue}
   // NAME, an optional closing quote, optional spaces, then `=` or `:` (but not the `://` of a url)
   let k=i;if(k<L&&(line[k]==='"'||line[k]==="'"))k++;
   while(k<L&&line[k]===' ')k++;
   const sep=k<L&&(line[k]==='='||line[k]===':')&&!(line[k]===':'&&line[k+1]==='/');
   const camKey=low==='k'&&start>0&&(line[start-1]==='?'||line[start-1]==='&');
   if(!(sep&&(secretName(run)||camKey))){out+=run;continue}
   let v=k+1;while(v<L&&line[v]===' ')v++;
   out+=line.slice(start,k+1);if(v>k+1)out+=' ';out+=mark;
   let end;
   if(line.startsWith(mark,v))end=v+mark.length; // already cut (a second pass over a server-scrubbed line)
   else if(restName(run))end=L;
   else if(v<L&&(line[v]==='"'||line[v]==="'")){const q=line[v];let e=v+1;while(e<L&&line[e]!==q)e+=line[e]==='\\'?2:1;end=Math.min(e+1,L)}
   else{let e=v;while(e<L&&!valueEnd(line[e]))e++;
    // `Bearer x`, `Basic x`: the scheme word is not the secret, the word after it is
    if(['bearer','basic','digest'].includes(line.slice(v,e).toLowerCase())){let e2=e;while(e2<L&&line[e2]===' ')e2++;while(e2<L&&!valueEnd(line[e2]))e2++;end=e2}else end=e}
   i=end}
  return out}
 function scanSecrets(s,opts){const mark=opts&&opts.mark||'[redacted]';
  let t=String(s==null?'':s).replace(/[^\S ]/g,' ').replace(/([A-Za-z][A-Za-z0-9+.\-]*:\/\/)[^\s\/?#]*@/g,'$1'+mark+'@');
  if(opts&&opts.query)t=t.replace(/([A-Za-z][A-Za-z0-9+.\-]*:\/\/[^\s?#"'<>]+)[?#][^\s"'<>]*/g,'$1');
  return redactLine(t,mark)}
 const ACCT_RE=/(--account[= ]+|--user[= ]+|\baccount[=:] ?|\buser_id["']? ?[:=] ?)(["']?)[^\s"'}),;]+/gi;
 const redact=s=>homeTilde(scanSecrets(s)).replace(ACCT_RE,'$1$2\u2026');
 const diagHtml=ds=>arr(typeof ds==='string'?[ds]:ds).map(d=>str(typeof d==='string'?d:'',200)).filter(Boolean).map(d=>'<span class="diag">'+esc(redact(d))+'</span>').join('');
 const sentence=s=>{const t=String(s==null?'':s).replace(/[_-]+/g,' ').trim();return t?t.charAt(0).toUpperCase()+t.slice(1).toLowerCase():''};
 // "daily_digest.json" or "accounts.json" read as a name: "Daily digest", "Accounts"
 const friendly=s=>{const t=String(s==null?'':s).replace(/\.(json|db|tsv|md)$/i,'').replace(/[_-]+/g,' ').trim();return t?t.charAt(0).toUpperCase()+t.slice(1):''};
 const kilo=v=>{const n=num(v);return n==null?'--':n>=10000?Math.round(n/1000)+'K':n>=1000?(n/1000).toFixed(1).replace(/\.0$/,'')+'K':String(Math.round(n))};
 // repos read "name", not "org/name"; two repos that share a name keep their org. Long names are cut in the middle so the end stays readable.
 const midCut=(s,n)=>{s=String(s==null?'':s);return s.length<=n?s:s.slice(0,Math.ceil((n-1)*.6))+'\u2026'+s.slice(s.length-Math.floor((n-1)*.4))};
 function repoLabels(repos){const full=r=>str(r,80),short=r=>full(r).split('/').pop(),seen={},out={};
  for(const r of repos){const s=short(r);(seen[s]=seen[s]||new Set()).add(full(r))}
  for(const r of repos){const f=full(r),s=short(r);out[f]=midCut(seen[s]&&seen[s].size>1?f:s,28)}return out}
 const uniq=(xs,key)=>{const seen=new Set();return arr(xs).filter(x=>{const k=key(x);if(seen.has(k))return false;seen.add(k);return true})};
 // one sentence for a failed action; never "http 502" or a raw server word
 function humanErr(j,status){const e=isObj(j)?str(j.error,120).toLowerCase():'',s=num(status),m=/already (\w+)/.exec(e);
  if(isObj(j)&&num(j.retry_s)!=null)return 'Too many tries. Wait '+Math.ceil(j.retry_s)+' s, then try again.';
  if(s===429||/rate|too many/.test(e))return 'Too many tries. Wait a moment, then try again.';
  if(e==='gate blocked')return 'Jev did not approve this run. Nothing was started.';
  if(e==='gate unsure')return 'Jev was not sure about this run. Nothing was started.';
  if(e==='gate unavailable')return 'Jev and Clef did not answer. Nothing was started.';
  if(e==='route invalid')return 'The run model setting is not valid. Nothing was started.';
  if(m)return 'It is already '+m[1]+'.';
  if(s===401||s===403||/auth|forbid|token|csrf|sign/.test(e))return 'You are signed out. Reload the deck to sign in again.';
  if(s===404||/unknown|not found|no run/.test(e))return 'That item is gone. Refresh the page and try again.';
  if(s===502||s===503||s===504||/unreach|gateway|did not answer/.test(e))return 'Hermes did not answer. Check that it is running, then try again.';
  if(!isObj(j)&&!s)return 'No answer from the deck. Check your connection, then try again.';
  if(s>=500)return 'The deck had a problem. Try again in a moment.';
  return 'That did not go through. Try again.'}
 // what a feed that did not report says to a person, plus the raw cause for the detail sheet
 function problem(f){const raw=isObj(f)?str(f.error,120):'',src=isObj(f)?str(f.src,120):'';
  const line=!isObj(f)?'The deck did not answer. Check your connection, then try again.':/missing|not found|no such file|not written/i.test(raw)?'Nothing has been collected yet. It fills in after the next refresh.':
   /time(?:d)?[ _-]?out|too long/i.test(raw)?'The source took too long to answer. Try again in a moment.':'The source is not reporting. Try again in a moment.';
  return {line,diag:[raw||(isObj(f)?'':'no answer from the deck server'),src].filter(Boolean)}}
 // the one empty-state component: icon, title, one line, optional 44 px Retry. k: idle (nothing to show), stale, bad. Static; never a spinner.
 const ES_ICON={idle:'<svg class="es-i" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 13l2.6-7h10.8L20 13v5H4z"/><path d="M4 13h4.6l1 2h4.8l1-2H20"/></svg>',
  stale:'<svg class="es-i" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M12 7.5V12l3 2"/></svg>',
  bad:'<svg class="es-i" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M12 7.5v5.5M12 16.4v.1"/></svg>'};
 function empty(o){o=isObj(o)?o:{};const k=o.k==='bad'||o.k==='stale'?o.k:'idle',key=/^[a-z0-9-]{1,20}$/.test(o.retry||'')?o.retry:'';
  return '<div class="es es-'+k+'" role="status">'+ES_ICON[k]+'<b class="es-t">'+esc(str(o.title,80)||'Nothing here yet')+'</b>'+(o.line?'<span class="es-l">'+esc(str(o.line,160))+'</span>':'')+
   (key?'<button type="button" class="b es-retry" data-retry="'+key+'">Try again</button>':'')+diagHtml(o.diag)+'</div>'}
 // "0 8,20 * * *" -> "Daily at 8 AM and 8 PM". Unusual expressions say so; the raw text stays in the detail sheet.
 const hour12=(h,m)=>{const n=+h;return ((n%12)||12)+(+m?':'+String(m).padStart(2,'0'):'')+' '+(n<12||n===24?'AM':'PM')};
 const DOWN=['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
 function schedule(raw){const s=str(raw,60);if(!s)return 'Schedule unknown';
  let m=/^every (\d+) ?(m|h|d)/i.exec(s);
  if(m){const n=+m[1],u=m[2].toLowerCase();return n===1?(u==='m'?'Every minute':u==='h'?'Every hour':'Every day'):'Every '+n+(u==='m'?' min':u==='h'?' h':' days')}
  m=/^(\S+) (\S+) \* \* (\S+)$/.exec(s);if(!m)return 'Custom schedule';
  const mi=m[1],hr=m[2],dw=m[3];let st=null,r2;
  if(/^\*\/\d+$/.test(mi)&&hr==='*'&&dw==='*')return 'Every '+mi.slice(2)+' min';
  if(/^\d+$/.test(mi)&&hr==='*'&&dw==='*')return 'Hourly at :'+mi.padStart(2,'0');
  if(/^\d+$/.test(mi)&&/^\d+(,\d+)*$/.test(hr))st='at '+hr.split(',').map(h=>hour12(h,mi)).join(' and ');
  else if(/^\d+$/.test(mi)&&(r2=/^(\d+)-(\d+)\/(\d+)$/.exec(hr)))st='every '+r2[3]+' h, '+hour12(r2[1],mi)+' to '+hour12(r2[2],mi);
  if(st==null)return 'Custom schedule';
  let day;
  if(dw==='*')day='Daily';else if(dw==='1-5')day='Weekdays';else if(/^[0-7](,[0-7])*$/.test(dw))day=dw.split(',').map(d=>DOWN[+d%7]).join(', ');
  else return 'Custom schedule';
  return day+' '+st}
 // state of a whole feed: bad (no data), stale (old), ok
 function state(f){if(!isObj(f)||f.error)return 'bad';return f.stale?'stale':'ok'}
 // one short status line: "Updated 2 min ago", "Out of date \u00B7 Updated 3 h ago", or what is wrong when the feed did not report
 function line(f,now){if(!isObj(f)||f.error)return problem(f).line;
  return (f.stale?'Out of date \u00B7 ':'')+(toEpoch(f.t)==null?'Update time unknown':'Updated '+ago(f.t,now))}
 const tile=(h,v,t,k,extra,dg)=>'<div class="tile'+(k=='bad'?' bad':k=='stale'||k=='warn'?' stale':'')+(extra?' '+extra:'')+'"><div class="h">'+(k?SD(k=='stale'?'warn':k):'')+esc(h)+'</div><div class="v">'+esc(v)+'</div>'+(t!=null?'<div class="t">'+esc(t)+'</div>':'')+diagHtml(dg)+'</div>';
 const head=(title,f,now)=>'<div class="secttl"><span>'+esc(title)+'</span><span>'+esc(isObj(f)&&!f.error?line(f,now):'Not reporting')+'</span></div>';
 const down=(title,f,retry)=>{const p=problem(f),t=str(title,60).replace(/ feed$/i,'');return empty({k:'bad',title:t+(/[^s]s$/i.test(t)?' are':' is')+' not reporting',line:p.line,retry,diag:p.diag})};
// "Fix these": one button above a list of failing jobs or checks. It only opens the message to the AI assistant for the person to read; nothing is sent until they tap Send (agents.js).
const FIX_KINDS={crons:['job','jobs'],ci:['check','checks']};
const fixRow=(kind,n)=>FIX_KINDS[kind]&&num(n)>0?'<div class="fixrow"><button type="button" class="b fix" data-fix="'+esc(kind)+'">Fix these</button><small>Opens a message to your AI assistant about '+esc(String(n))+' failing '+FIX_KINDS[kind][n===1?0:1]+'. Nothing starts until you tap Send.</small></div>':'';
// failed parts of a feed collapse into ONE line per panel: the count, then the first three names in plain words; the reasons are in the detail sheet.
// A source id is drawn only when it already reads as a name ("ebay", "spark engine"). Ids with a colon, dot or slash ("fred:RSXFS", "sites.field-desk") and
// internal words (sqlite, json, api, gateway ...) stay in the hidden details: the deck draws no plumbing.
const PLUMB=/sqlite|json|\bdb\b|sql|\bapi\b|http|fred|wikipedia|pageview|shoptrends|gateway|rclone|\bmcp\b|\btsv\b|cache/i;
const errNames=es=>{const nm=[];es.forEach(e=>{const raw=redact(str(e.source,40));if(!/^[A-Za-z][A-Za-z0-9 _-]{1,28}$/.test(raw)||PLUMB.test(raw))return;const n=friendly(raw);if(n&&!nm.includes(n))nm.push(n)});
 return nm.length?nm.slice(0,3).join(', ')+(nm.length>3?' and '+(nm.length-3)+' more':''):''};
const errRows=f=>{const es=arr(isObj(f)&&f.errors).filter(isObj);if(!es.length)return '';const names=errNames(es);
  return '<div class="frow err"><span>'+(es.length===1?'One source is not reporting.':es.length+' sources are not reporting.')+'</span>'+(names?'<span class="errn">'+esc(names)+'</span>':'')+
   diagHtml(es.slice(0,8).map(e=>(str(e.source,40)||'source')+': '+(str(e.reason,120)||'no reason given')))+'</div>'};
 // every link shows a small trailing arrow so the owner can tell a link from a plain row (aria-hidden, the anchor keeps its own text)
 const LK='<span class="lk" aria-hidden="true">\u2197</span>';
 // attrs (already escaped, built by dattr) go before class so the class attribute stays directly before the first child
 const dattr=(n,v)=>' data-'+n+'="'+esc(v)+'"';
const row=(main,sub,right,k,url,attrs,dg,more)=>{const u=safeUrl(url),tag=u?'a':'div';
  return '<'+tag+(attrs||'')+' class="frow'+(k?' '+k:'')+'"'+(u?' href="'+esc(u)+'" target="_blank" rel="noopener noreferrer"':'')+'>'+'<span class="fl"><b>'+esc(main)+'</b>'+(sub?'<small>'+esc(sub)+'</small>':'')+(more||'')+'</span>'+(right!=null&&right!==''?'<span class="fr">'+right+'</span>':'')+(u?LK:'')+diagHtml(dg)+'</'+tag+'>'};
 const yes=(v,a,b,u)=>v===true?a:v===false?b:(u||'unknown');

// A bench is shown only for the model that produced it. The collector sets bench.stale (and ratchet.stale)
// when that model is not the served one: the card then names the served model and the last bench, no numbers.
const staleBench=(b,e)=>'No current benchmark for '+(str(e.served_name,60)||'the served model')+'; last bench was '+(str(b.model,60)||'an unknown model')+' on '+(str(b.measured_at,12)||'an unknown date');
const staleBenchHtml=(b,e)=>'<div class="es es-stale" role="status">'+ES_ICON.stale+'<b class="es-t">'+esc(staleBench(b,e))+'</b></div>';
 // ---- cluster ----
 function cluster(f,now){
  if(state(f)=='bad')return [head('Engine',f,now)+down('Cluster',f,'cluster'),'',''];
  const k=state(f),e=isObj(f.engine)?f.engine:{},p=isObj(f.proxy)?f.proxy:{},b=isObj(f.bench)?f.bench:{},r=isObj(f.ratchet)?f.ratchet:{};
  const est=str(e.status,12)||'unknown',ek=est=='up'?(k=='stale'?'stale':'ok'):est=='loading'?'stale':'bad';
  const engine=tile('Model',(str(e.served_name,60)||'Model unknown')+' \u00B7 '+({up:'Running',loading:'Loading',down:'Down'}[est]||'Status unknown'),
   (num(e.max_model_len)==null?'':kilo(e.max_model_len)+' token context \u00B7 ')+(e.up_since==null?'Start time unknown':'Up '+dur(e.up_since,now)),ek,'wrap',
   [str(e.container,32)&&'Container '+str(e.container,32),num(e.port)!=null&&'Port '+e.port,str(e.lock_model,60)&&'Locked to '+str(e.lock_model,60)].filter(Boolean));
  const models=arr(p.models).map(m=>str(m,40)).filter(Boolean);
  const proxy=tile('Proxy \u00B7 pc-desktop',p.pc_desktop_8080_up===true?'Up':p.pc_desktop_8080_up===false?'Down':'Status unknown',models.length?models.join(', '):'No models listed',
   p.pc_desktop_8080_up===true?(k=='stale'?'stale':'ok'):p.pc_desktop_8080_up===false?'bad':'stale','',['Port 8080 on pc-desktop']);
  const bench=b.stale===true?staleBenchHtml(b,e):b.prose_tps==null&&b.code_tps==null?empty({k:'stale',title:'No speed measured yet',line:'The next benchmark run fills this in.'}):
   tile('Speed',fmt(b.prose_tps,1)+' tok/s writing \u00B7 '+fmt(b.code_tps,1)+' coding',
   'Prefill '+fmt(b.prefill_tps)+' tok/s \u00B7 6 at once '+fmt(b.conc6_tps)+' \u00B7 measured '+(b.at==null?'at an unknown time':ago(b.at,now)),k,'',[str(b.source,40)]);
  const ratchet=r.stale===true?tile('GLM history',(sentence(str(r.last_outcome,40))||'No result')+(str(r.last_step,40)?' \u00B7 '+str(r.last_step,40).replace(/_/g,' '):''),
   'Last GLM run '+(str(r.last_date,20)||'unknown')+'. Not the served model.','stale'):
   tile('Tuning',(sentence(str(r.last_outcome,40))||'No result yet')+(str(r.last_step,40)?' \u00B7 '+str(r.last_step,40).replace(/_/g,' '):''),
   'Last run '+(str(r.last_date,20)||'unknown')+' \u00B7 next '+(r.next_run==null?'not scheduled':until(r.next_run,now)),k);
  const col1=head('Engine',f,now)+engine+proxy+bench+ratchet;
  const nodes=arr(f.nodes).map(n=>{const ok=n&&n.reachable===true,used=num(n&&n.mem_used_gb),tot=num(n&&n.mem_total_gb),pct=used!=null&&tot?Math.round(used/tot*100):null,hot=num(n&&n.gpu_temp_c)!=null&&n.gpu_temp_c>=85;
   const nk=!ok?'bad':(k=='stale'||hot)?'stale':'ok',cs=arr(n&&n.containers).map(c=>str(c,32)).filter(Boolean);
   return '<div class="tile node'+(nk=='bad'?' bad':nk=='stale'?' stale':'')+'"><div class="h">'+SD(nk=='stale'?'warn':nk)+esc(str(n&&n.name,20)||'Node')+'</div>'+
    '<div class="v">'+(ok?fmt(n.gpu_temp_c,0,'\u00B0C')+' \u00B7 '+fmt(n.gpu_util_pct,0,'%')+' busy \u00B7 '+fmt(n.power_w,0,' W'):'Not reachable')+'</div>'+
    '<div class="bar'+(pct!=null&&pct>=99?' hot':'')+'"><i style="width:'+(pct||0)+'%"></i></div>'+
    '<div class="t">'+(ok?'Memory '+fmt(used)+' of '+fmt(tot)+' GB \u00B7 up '+(num(n&&n.uptime_s)==null?'time unknown':Math.round(n.uptime_s/86400)+' d'):'Check that the machine is on and on the network.')+'</div>'+
    (ok?'<div class="t">'+(cs.length?cs.length+(cs.length>1?' services':' service')+' running':'No services listed')+'</div>':'')+
    diagHtml([str(n&&n.lan_ip,20)&&'Address '+str(n&&n.lan_ip,20),num(n&&n.load1)!=null&&'Load '+fmt(n.load1,1),cs.length&&'Containers: '+cs.join(', ')].filter(Boolean))+'</div>'}).join('');
  const col2=head('Nodes',f,now)+(nodes||empty({k:'idle',title:'No machines reported',line:'They appear here after the next check.',retry:'cluster'}))+errRows(f);
  const cands=arr(f.candidates);
  const col3=head('Candidates',f,now)+(cands.length?'<div class="flist">'+cands.map(c=>{const s=str(c&&c.status,16)||'unknown';
   return row(str(c&&c.name,60)||'Model',(str(c&&c.format,16)||'Format unknown')+' \u00B7 '+fmt(c&&c.size_gb,1,' GB'),'<span class="pill'+(s=='rejected'?' bad':'')+'">'+esc(sentence(s))+'</span>','')}).join('')+'</div>':
   empty({k:'idle',title:'No candidate models',line:'Models being considered for the cluster show up here.'}));
  return [col1,col2,col3]}

 // ---- launch ----
 const KIND_ORDER=['command','skill','mcp','tool','plugin','automation'];
 const KIND_LABEL={command:'Commands',skill:'Skills',mcp:'MCPs',tool:'Tools',plugin:'Plugins',automation:'Automations'};
 // tier/score/where/why come from the LaunchAudit contract; a missing tier is "unrated" and sorts before dead
 const TIERS=['core','useful','niche','dead'];
 const TIER_ORDER=['core','useful','niche','unrated','dead'];
 const TIER_LABEL={core:'Core',useful:'Useful',niche:'Niche',unrated:'Unrated',dead:'Dead'};
 const WHERE_LABEL={omp:'OMP',hermes:'Hermes',kody:'Kody','pc-desktop':'pc-desktop','mac-mini':'Mac mini',dell:'Dell',spark:'Spark',ascent:'Ascent'};
 // label, does, area, ao (the area's place in the owner's list) and earns come from the launch feed; an old feed without them shows raw names, tiers and kinds as before
 function launchItems(f){return arr(isObj(f)&&f.items).filter(x=>isObj(x)&&typeof x.id==='string'&&KIND_ORDER.includes(x.kind)).map(x=>{
  const where=arr(x.where).map(w=>str(w,20).toLowerCase()).filter(w=>w&&w!=='omp').slice(0,8),why=str(x.why,90),label=str(x.label,32),does=str(x.does,90),area=str(x.area,24),ao=num(x.ao),earns=x.earns===true;
  return {id:x.id,kind:x.kind,name:str(x.name,80)||str(x.arg,80)||x.id,label,does,area,ao:area&&ao!=null?Math.max(0,Math.min(98,Math.round(ao))):null,earns,desc:str(x.desc,90),group:str(x.group,40),
  targets:arr(x.targets).filter(t=>t==='hermes'),tier:TIERS.includes(x.tier)?x.tier:'unrated',
  score:num(x.score)==null?null:Math.max(0,Math.min(100,Math.round(x.score))),where,why,
  hay:[label,does,area,x.name,x.desc,x.group,x.arg,x.kind,why,where.join(' ')].map(s=>String(s||'').toLowerCase()).join(' ')}})}
 function launchFavorites(f,items){const by=new Map(items.map(x=>[x.id,x]));
 return arr(isObj(f)&&f.favorites).map(x=>{if(!isObj(x))return null;const id=str(x.id,100),it=by.get(id),label=str(x.label,20);
  return id&&it&&it.targets.includes('hermes')?{id,label:label||it.name,name:it.name,tier:it.tier}:null}).filter(Boolean).slice(0,12)}
// the curated row above the list; the same .lnb button and the same second-tap arming as a list row
function launchFavs(favs,armed){if(!favs.length)return '';
 return '<div class="tgrp fvg">Favorites</div><div class="lnfavrow">'+favs.map(x=>{const on=armed===x.id+'|hermes';
  return '<button class="b lnb lnfavb'+(on?' armed':'')+'" data-id="'+esc(x.id)+'" data-target="hermes" aria-label="Run in Hermes: '+esc(x.name)+'">'+(on?'Tap again':esc(x.label))+'</button>'}).join('')+'</div>'}
function launchCounts(items){const c={all:items.length};for(const k of KIND_ORDER)c[k]=0;for(const x of items)c[x.kind]++;return c}
 // areas in the feed's own order, with how many items each holds
 function launchAreas(items){const m=new Map();for(const x of items){if(!x.area)continue;const e=m.get(x.area)||{area:x.area,ao:x.ao==null?99:x.ao,n:0,earns:false};e.n++;e.earns=e.earns||x.earns;if(x.ao!=null&&x.ao<e.ao)e.ao=x.ao;m.set(x.area,e)}
  return [...m.values()].sort((a,b)=>a.ao-b.ao||a.area.localeCompare(b.area))}
 // tier counts in tier order, where counts most common first, areas in feed order
 function launchFacets(items){const tier={all:items.length},w={};for(const t of TIER_ORDER)tier[t]=0;
  for(const x of items){tier[x.tier]++;for(const h of x.where)w[h]=(w[h]||0)+1}
  return {tier,area:launchAreas(items),where:Object.keys(w).sort((a,b)=>w[b]-w[a]||a.localeCompare(b)).map(h=>({w:h,n:w[h],label:WHERE_LABEL[h]||h}))}}
 function launchFilter(items,query,kind,limit,opt){const toks=String(query||'').toLowerCase().split(/\s+/).filter(Boolean),o=opt||{},tier=o.tier||'all',where=o.where||'all',area=o.area||'all';
  const hit=items.filter(x=>(!kind||kind==='all'||x.kind===kind)&&(tier==='all'||x.tier===tier)&&(area==='all'||x.area===area)&&(where==='all'||x.where.includes(where))&&toks.every(t=>x.hay.includes(t)));
  const score=x=>{const n=(x.label||x.name).toLowerCase();return toks.length&&toks.every(t=>n.includes(t))?(n.startsWith(toks[0])?0:1):2},ord=x=>x.ao==null?99:x.ao;
  // browsing: area first, then tier. Searching: how well it matches first, so the best hit is on top whatever its area
  const byArea=(a,b)=>ord(a)-ord(b)||(a.area||'').localeCompare(b.area||'');
  const rest=(a,b)=>TIER_ORDER.indexOf(a.tier)-TIER_ORDER.indexOf(b.tier)||score(a)-score(b)||(b.score==null?-1:b.score)-(a.score==null?-1:a.score)||KIND_ORDER.indexOf(a.kind)-KIND_ORDER.indexOf(b.kind)||(a.label||a.name).localeCompare(b.label||b.name);
  hit.sort(toks.length?(a,b)=>score(a)-score(b)||byArea(a,b)||rest(a,b):(a,b)=>byArea(a,b)||rest(a,b));
  const n=limit||120;return {rows:hit.slice(0,n),total:hit.length}}
 // a row: the plain label, what it does, then tier, the earns marker and the raw name (small, dimmed, still searchable), then hosts
 function launchRow(x,armed){const title=x.label||x.name,btn=t=>{const on=armed===x.id+'|'+t;
   return '<button class="b lnb'+(on?' armed':'')+'" data-id="'+esc(x.id)+'" data-target="'+t+'" aria-label="Run in Hermes: '+esc(title)+'">'+(on?'Tap again':'Hermes')+'</button>'};
  const tag=x.tier!=='unrated'?'<span class="tier t-'+x.tier+'">'+TIER_LABEL[x.tier]+(x.score!=null?' '+x.score:'')+'</span>':'',
   earn=x.earns?'<span class="pill earn">Earns money</span>':'',raw=x.label&&x.label!==x.name?'<small class="raw">'+esc(x.name)+'</small>':'',
   dz=x.does||[x.group,x.why||x.desc].filter(Boolean).join(' \u00B7 ');
  return '<div class="lnrow tr-'+x.tier+(x.earns?' earns':'')+'"><div class="fl"><b>'+esc(title)+'</b>'+(dz?'<small class="dz">'+esc(dz)+'</small>':'')+
   (tag||earn||raw?'<span class="lnm">'+tag+earn+raw+'</span>':'')+
   (x.where.length?'<span class="whr">'+x.where.map(w=>'<i>'+esc(WHERE_LABEL[w]||w)+'</i>').join('')+'</span>':'')+'</div>'+
   '<div class="lnbs">'+(x.targets.length?x.targets.map(btn).join(''):'<span class="pill">view only</span>')+'</div></div>'}
 // groups by area (in the feed's order) when the feed carries areas and no single area is chosen, else by tier once the feed carries tiers, else by kind
 function launchList(res,armed,opt){if(!res.rows.length)return empty({k:'idle',title:'No match',line:'Try fewer words or another filter.'});
  const o=opt||{},byArea=!o.q&&(!o.area||o.area==='all')&&res.rows.some(x=>x.area),byTier=!o.q&&!byArea&&res.rows.some(x=>x.tier!=='unrated'),mode=o.q?'flat':byArea?'area':byTier?'tier':'kind';
  const grp=x=>mode==='area'?(x.area||'Other'):mode==='tier'?x.tier:mode==='kind'?x.kind:'';
  let out='',last='';for(const x of res.rows){const g=grp(x);if(mode!=='flat'&&g!==last){out+='<div class="tgrp'+(mode==='tier'?' g-'+g:mode==='area'?' g-area':'')+'">'+esc(mode==='tier'?TIER_LABEL[g]:mode==='kind'?KIND_LABEL[g]:g)+'</div>';last=g}out+=launchRow(x,armed)}
  if(res.total>res.rows.length)out+='<div class="tnote">Showing '+res.rows.length+' of '+res.total+'. Type to narrow.</div>';return out}
 function launchResult(r,status){if(!isObj(r))return {k:'bad',text:humanErr(null,status)};
  if(!r.ok)return {k:'bad',text:humanErr(r,status)};
  return {k:'ok',text:(/queue/i.test(str(r.status,20))?'Queued in Hermes':'Started in Hermes')+(str(r.name,40)?' \u00B7 '+str(r.name,40):'')}}

 // ---- dev ----
// D2: a failed Vercel read says so and why; an empty list would read as "no projects". The reason is the collector's own text ("... expired 335200s ago").
function vercelEmpty(d){const e=arr(isObj(d)&&d.errors).filter(isObj).find(x=>/^vercel$/i.test(str(x.source,20)));
 if(!e)return empty({title:'No Vercel projects',line:'Projects show up here once Vercel is connected.'});
 const m=/expired\s+(\d+)\s*s\s+ago/i.exec(str(e.reason,200)),s=m?+m[1]:null,age=s==null?'':s<172800?Math.max(1,Math.round(s/3600))+' h':Math.round(s/86400)+' d';
 return empty({k:'bad',title:'Vercel not reporting',line:s==null?'The Vercel read failed. Projects show again once it works.':'Token expired '+age+' ago. Projects show again once it is refreshed.',diag:[str(e.reason,120)]})}
// tf = GET /api/testflight (undefined for a caller that has no such feed: no App builds section)
function dev(d,now,tf){
  const cols=['','',''];
  if(state(d)=='bad')cols[0]=head('GitHub',d,now)+down('Dev',d,'dev');
  else{const g=isObj(d.github)?d.github:{},fm=uniq(arr(g.failing_main).filter(isObj),x=>str(x.repo,80)+'|'+str(x.workflow,60)),prs=uniq(arr(g.open_prs).filter(isObj),x=>str(x.repo,80)+'#'+fmt(x.num));
  const rl=repoLabels(fm.concat(prs).map(x=>x.repo)),nm=x=>rl[str(x.repo,80)]||'Repo';
  const ci=c=>'<span>'+(c==='pass'?SD('ok')+'Passing':c==='fail'?SD('bad')+'Failing':c==='pending'?SD('warn')+'Running':'No checks')+'</span>';
   // A GitHub rate limit serves the last good block (collector sets stale + stale_reason): label it, never paint it red.
   // No github block at all is unknown, never "0 open".
   const gstale=g.stale===true,gsub=gstale?'As of '+hm(g.at)+' \u00B7 '+(g.stale_reason==='rate_limited'?'GitHub rate limit':'GitHub unreachable'):g.at==null?line(d,now):'Checked '+ago(g.at,now);
   cols[0]=head('GitHub',d,now)+(isObj(d.github)?tile('Pull requests',prs.length+' open'+(fm.length?' \u00B7 '+fm.length+' failing on main':''),gsub,fm.length?'bad':gstale?'stale':state(d)):tile('Pull requests','No reading','GitHub did not report \u00B7 '+line(d,now),'bad'))+
    (isObj(d.github)?fixRow('ci',fm.length+prs.filter(x=>x.ci==='fail').length):'')+
    '<div class="flist">'+fm.map(x=>row(nm(x)+' \u00B7 main',str(x.workflow,60),ci('fail'),'bad',x.url,'',[str(x.repo,80)])).join('')+
   prs.slice(0,40).map(x=>row(nm(x)+' #'+fmt(x.num),str(x.title,90),ci(x.ci),'',x.url,'',[str(x.repo,80)])).join('')+'</div>'+errRows(d);
   const v=arr(isObj(d.vercel)&&d.vercel.projects),s=arr(isObj(d.supabase)&&d.supabase.projects);
   cols[1]=head('Vercel',d,now)+(v.length?'<div class="fchips">'+v.map(p=>{const st=str(p&&p.state,16)||'unknown',bad=/error|fail/i.test(st);
     return chipA(str(p&&p.name,30)||'Project',(p&&p.paused?'Paused \u00B7 ':'')+sentence(st)+(p&&p.last_deploy_at!=null?' \u00B7 '+ago(p.last_deploy_at,now):''),bad?'bad':p&&p.paused?'stale':'ok',p&&p.url)}).join('')+'</div>':vercelEmpty(d))+
    head('Supabase',d,now)+(s.length?'<div class="fchips">'+s.map(p=>{const st=str(p&&p.status,24)||'unknown';
     return chipA(str(p&&p.name,30)||'Project',sentence(st)+(str(p&&p.region,16)?' \u00B7 '+str(p.region,16):''),/HEALTHY|ACTIVE/i.test(st)?'ok':/PAUSE|INACTIVE/i.test(st)?'stale':'bad','')}).join('')+'</div>':empty({title:'No Supabase projects',line:'Projects show up here once Supabase is connected.'}));
   const h=isObj(d.herdr)?d.herdr:{},c=isObj(d.chromium)?d.chromium:{},gr=isObj(d.grok)?d.grok:{},ht=arr(h.tabs);
   cols[2]=head('Workspace',d,now)+
    tile('Herdr',ht.length+(ht.length===1?' tab':' tabs')+' \u00B7 '+fmt(h.agents_busy)+' agents busy',ht.slice(0,5).map(t=>str(t&&t.name,20)).filter(Boolean).join(', ')||line(d,now),isObj(d.herdr)?state(d):'stale')+
    tile('Browser',yes(c.cdp_up,'Up','Down','Status unknown')+' \u00B7 '+fmt(c.tabs)+' tabs','Page titles hidden \u00B7 '+line(d,now),c.cdp_up===false?'bad':c.cdp_up===true?state(d):'stale','',['Debug port 9333'])+
    tile('Grok',gr.build_cli?'Version '+str(gr.build_cli,24):'Not installed',yes(gr.logged_in,'Signed in','Signed out','Sign-in unknown')+' \u00B7 '+line(d,now),gr.build_cli&&gr.logged_in===true?state(d):'stale')}
  if(tf!==undefined)cols[2]+=appBuilds(tf,now);
  return cols}

 // ---- keys page: connections (accounts feed) ----
 const HOST_LABEL={mesh:'Dell','mac-mini':'Mac mini','pc-desktop':'pc-desktop'};
 const DRIVE_LABEL={gdrive:'Google Drive',onedrive:'OneDrive',icloud:'iCloud Drive'};
 const n0=v=>{const n=num(v);return n==null?'--':String(Math.round(n)).replace(/\B(?=(\d{3})+(?!\d))/g,',')};
 const mini=(h,v,t,k,dg)=>'<div class="mt'+(k=='bad'?' bad':k=='stale'?' stale':'')+'"><span>'+(k?SD(k=='stale'?'warn':k):'')+esc(h)+'</span><b>'+esc(v)+'</b>'+(t?'<small>'+esc(t)+'</small>':'')+diagHtml(dg)+'</div>';
 function mcpTile(name,m,k){if(!isObj(m))return empty({k:'bad',title:name+' tools are unreadable',line:'Their settings could not be read. Try again.',retry:'keys'});
  const need=arr(m.auth_needed),down=arr(m.unreachable);
  return tile(name+' tools',fmt(m.enabled)+' of '+fmt(m.declared)+' on \u00B7 '+fmt(m.signed_in)+' of '+fmt(m.oauth)+' signed in',
   fmt(m.stdio)+' local \u00B7 '+fmt(m.http)+' remote \u00B7 '+(need.length?need.length+' need sign-in':'No sign-in needed')+(down.length?' \u00B7 '+down.length+' not answering':''),
   need.length||down.length?'stale':k,'wrap',[need.length&&'Needs sign-in: '+need.join(', '),down.length&&'Not answering: '+down.join(', ')].filter(Boolean))}
 function conn(a,now){
  if(state(a)=='bad')return [head('Connections',a,now)+down('Connections',a,'keys'),''];
  const k=state(a),op=arr(isObj(a.onepassword)&&a.onepassword.hosts),dr=arr(a.drives),ap=isObj(a.apple)?a.apple:{},lib=isObj(ap.library)?ap.library:{};
  const co=isObj(a.composio)?a.composio:null,mc=isObj(a.mcp)?a.mcp:{},da=isObj(a.dev_auth)?a.dev_auth:{};
  const opc=head('1Password',a,now)+(op.length?'<div class="fchips">'+op.map(h=>chipA(HOST_LABEL[str(h&&h.host,20)]||str(h&&h.host,20)||'Device',
   (h&&h.token_ok===true?'Signed in':h&&h.token_ok===false?'Needs sign-in':'Status unknown')+' \u00B7 '+n0(h&&h.items)+' items',h&&h.token_ok===true&&h.op_cli?k:h&&h.token_ok===false?'bad':'stale','',['Vault Hermes',h&&h.op_cli?'op '+str(h.op_cli,12):'op is not installed'])).join('')+'</div>':empty({title:'No devices listed',line:'Devices that can reach 1Password show up here.'}));
  let coc;
  if(!co)coc=head('Connected services',a,now)+empty({k:'bad',title:'Connected services are not reporting',line:'The list could not be read. Try again.',retry:'keys'});
  else{const kits=arr(co.toolkits),live=kits.filter(t=>num(t&&t.active)>0||arr(t&&t.aliases).length),rest=kits.length-live.length;
   coc='<div class="secttl"><span>Connected services</span><span>'+fmt(co.active)+' connected \u00B7 '+fmt(co.expired)+' expired</span></div>'+(live.length?'<div class="flist">'+live.map(t=>{const al=arr(t.aliases),on=num(t.active)>0;
    return row(friendly(str(t.toolkit,30))||'Service',al.length?al.length+(al.length===1?' account':' accounts')+(num(t.expired)>0?' \u00B7 '+fmt(t.expired)+' expired':''):'Not connected',
     '<b>'+(on?'Connected':'Reconnect')+'</b>',on?'':'bad','','',al.map(x=>str(x&&x.alias,30)+' '+(x&&x.status==='ACTIVE'?'on':'expired')))}).join('')+
    (rest>0?'<div class="frow"><span class="fl"><small>'+rest+' more service'+(rest>1?'s':'')+' with only expired links</small></span></div>':'')+'</div>':empty({title:'No connected services',line:'Services you connect show up here.'}))}
  const dv=x=>isObj(x)?x:{},gh=dv(da.github),vc=dv(da.vercel),sb=dv(da.supabase);
  const api=(n,x)=>chipA(n,(x.ok===true?'Connected':x.ok===false?'Not connected':'Status unknown')+(x.projects!=null?' \u00B7 '+x.projects+' projects':'')+' \u00B7 Tools '+(x.mcp_signed_in===true?'signed in':x.mcp_signed_in===false?'signed out':'unknown'),
   x.ok===false?'bad':x.ok===true&&x.mcp_signed_in!==false?k:'stale','');
  const account=str(gh.account,39),accountUrl=gh.ok===true&&/^[A-Za-z0-9](?:[A-Za-z0-9-]{0,37}[A-Za-z0-9])?$/.test(account)?'https://github.com/'+account:'';
  const dec=head('Developer sign-in',a,now)+'<div class="fchips">'+chipA('GitHub',gh.ok===true?'Signed in':gh.ok===false?'Signed out':'Status unknown',gh.ok===true?k:gh.ok===false?'bad':'stale',accountUrl,gh.ok===true&&account?['Account '+account]:[])+api('Vercel',vc)+api('Supabase',sb)+'</div>';
  const mcc=head('Tools',a,now)+mcpTile('OMP',mc.omp,k)+mcpTile('Hermes',mc.hermes,k);
  const reach=ap.mini_reachable!==false;
  const apc='<div class="secttl"><span>Apple \u00B7 Mac mini</span><span>'+(reach?(str(lib.account,60)?'iCloud connected':'Account unknown'):'Mac mini not reachable')+'</span></div><div class="mgrid">'+
   mini('iMessage',reach?n0(ap.imessage_unread)+' unread':'--',lib.messages===true?'Messages readable':'',reach?k:'bad')+
   mini('Notes',n0(lib.notes),n0(ap.notes_recent_7d)+' this week',reach?k:'bad')+
   mini('Photos',n0(lib.photos),n0(ap.photos_recent_7d)+' added this week',reach?k:'bad')+
   mini('Calendar',n0(ap.calendar_today)+' today',n0(lib.calendars)+' calendars',reach?k:'bad')+
   mini('Reminders',n0(ap.reminders_open)+' open',n0(lib.reminder_stores)+' lists',reach?k:'bad')+
   mini('Contacts',lib.contacts===true?'Readable':lib.contacts===false?'Not available':'--','Address book',lib.contacts===true?k:'stale')+
   mini('Wallet',n0(lib.wallet_passes)+' passes','Passes only, no details',lib.wallet===true?k:'stale')+
   mini('iCloud Drive',lib.icloud_drive===true?'Readable':lib.icloud_drive===false?'Not available':'--','File names only',lib.icloud_drive===true?k:'stale')+'</div>';
  const kinds={};
  const drc=head('Drives',a,now)+(dr.length?'<div class="flist">'+dr.map(x=>{const kd=str(x&&x.kind,12),base=DRIVE_LABEL[kd]||kd||'Drive',n=kinds[base]=(kinds[base]||0)+1;
   return row(n>1?base+' '+n:base,x&&x.ok===false?'Could not check free space':fmt(x&&x.free_gb,0,' GB')+' free',x&&x.ok===false?SD('bad')+'Not reachable':'<b>'+fmt(x&&x.used_gb,0,' GB')+'</b><small>used</small>',x&&x.ok===false?'bad':'','','',[str(x&&x.remote,30)&&'Remote '+str(x&&x.remote,30)])}).join('')+'</div>':empty({title:'No drives listed',line:'Cloud drives you connect show up here.'}));
  return [opc+dec+mcc+errRows(a),apc+drc+coc]}
 function chipA(b,s,k,url,dg){const u=safeUrl(url),tag=u?'a':'div';return '<'+tag+' class="chip'+(k=='bad'?' bad':k=='stale'?' stale':'')+'"'+(u?' href="'+esc(u)+'" target="_blank" rel="noopener noreferrer"':'')+'><b>'+SD(k=='stale'?'warn':k||'ok')+esc(b)+'</b><small>'+esc(s)+'</small>'+(u?LK:'')+diagHtml(dg)+'</'+tag+'>'}

 // ---- life ----
 // list sizes the Life columns still hand to the old Show more count (the jobs column pages by filter now)
const JOB_SHORT=12,JOB_STEP=50,HOME_SHORT=8,COM_SHORT=5,JOB_CAP=400,HOME_CAP=20,COM_CAP=20;
const jobKey=x=>[str(x&&x.title,90),str(x&&x.company,40),str(x&&x.location,40)].join('|').toLowerCase();
 const jobList=j=>uniq(arr(j&&j.listings).filter(isObj),jobKey);
// reading cues the feed writes per posting (deck-feed-jobs): `flags` ids, `flag_text` words and a one-line `note`. Shown as quiet pills and one line so a posting can be
// skipped without opening it. No flag means nothing was found in the text the source gave: it never reads as "clearance not required".
const JOB_FLAG_TEXT={clearance_required:'Clearance required',login_for_match:'Login needed for match'};
function jobCue(x){const ft=arr(x&&x.flag_text).map(s=>str(s,40)).filter(Boolean),ids=arr(x&&x.flags).map(f=>str(f,30)).filter(Boolean);
 const words=ft.length?ft:ids.map(f=>JOB_FLAG_TEXT[f]||'').filter(Boolean),note=str(x&&x.note,140);
 return (words.length?'<small class="jflags">'+words.slice(0,4).map(w=>'<span class="pill warn">'+esc(w)+'</span>').join(' ')+'</small>':'')+(note?'<small class="jnote">'+esc(note)+'</small>':'')}
 
 const ft1=v=>{const n=num(v);return n==null?'--':Number.isInteger(n)?String(n):n.toFixed(1)};
 const surfSize=x=>{const a=ft1(x&&x.wave_ft_min),b=ft1(x&&x.wave_ft_max);return (a===b?a:a+'-'+b)+' ft'};
 const surfCond=x=>[num(x&&x.period_s)!=null&&fmt(x.period_s,0,' s')+(compass(x.swell_dir_deg)?' swell from '+compass(x.swell_dir_deg):' swell'),num(x&&x.wind_kt)!=null&&'wind '+fmt(x.wind_kt,0,' kt')+(compass(x.wind_dir_deg)?' '+compass(x.wind_dir_deg):''),num(x&&x.water_temp_f)!=null?fmt(x.water_temp_f,0,'\u00B0F')+' water':'water --'].filter(Boolean).join(' \u00B7 ');
 function surfGroups(spots){const g=[],by={};for(const x of arr(spots).filter(isObj)){const key=surfSize(x)+'|'+surfCond(x)+'|'+str(x.rating,16),nm=spotLabel(x);
   if(by[key]){if(!by[key].names.includes(nm))by[key].names.push(nm)}else{by[key]={x,names:[nm]};g.push(by[key])}}return g}
 const surfName=names=>names.length<=3?names.slice(0,-1).join(', ')+(names.length>1?' and ':'')+names[names.length-1]:names.slice(0,2).join(', ')+' and '+(names.length-2)+' more';
 const surfRow=g=>row(surfName(g.names),surfCond(g.x),'<b>'+esc(surfSize(g.x))+'</b><small>'+esc(sentence(str(g.x.rating,16)))+'</small>',g.x.role==='reference'?'sh-ref':'','','',g.names.length>3?[g.names.join(', ')]:[]);
 const tideRow=(tide,list)=>list.length?row('Tides',list.map(t=>(t&&t.type==='H'?'High ':'Low ')+clock(t&&t.at).replace(/^\w+ /,'')+' '+fmt(t&&t.ft,1,' ft')).join(' \u00B7 '),'','','','',[str(tide.station,30)&&'Station '+str(tide.station,30)].filter(Boolean)):'';

 const JMETRO={south_oc:'South OC',oc:'OC',la:'LA',sd:'SD',remote:'Remote'};
 const JMETRO_CHIP={south_oc:'South OC',oc:'OC',la:'LA',sd:'SD',remote:'Remote $100k+'};
 const JMETRO_ORDER=['south_oc','oc','la','sd','remote'];
 const JMODE={in_person:'in person',hybrid:'hybrid',remote:'remote'};
 // chip counts come from the deduped rows on screen, so a site count is never a bigger feed total
 // and "All" is never smaller than the sites under it
 function jobSites(j){const by={};for(const x of jobList(j)){const s=str(x.site,30);if(s)by[s]=(by[s]||0)+1}
  return Object.keys(by).map(s=>({site:s,n:by[s]})).sort((a,b)=>b.n-a.n||a.site.localeCompare(b.site))}
 const jdef=v=>({slug:str(v&&v.slug,40),name:str(v&&v.name,60)||str(v&&v.slug,40),definition:str(v&&v.definition,220)});
 function jobTax(j){return arr(isObj(j)&&j.taxonomy).filter(isObj).map(t=>{const d=jdef(t);
  return d.slug?{slug:d.slug,name:d.name,definition:d.definition,subs:arr(t.subs).filter(isObj).map(jdef).filter(s=>s.slug)}:null}).filter(Boolean)}
 function jobCat(tax,slug){const s=str(slug,40);return s&&Array.isArray(tax)?tax.find(t=>t.slug===s)||null:null}
 function jobSub(cat,slug){const s=str(slug,40);return cat&&s?cat.subs.find(x=>x.slug===s)||null:null}
 function jobCounts(list){const c={};for(const x of list){const k=str(x&&x.category,40);if(k)c[k]=(c[k]||0)+1}return c}
 function jobFacets(j){const list=jobList(j),tax=jobTax(j),by=jobCounts(list),sub={};
  for(const x of list){const c=str(x&&x.category,40),s=str(x&&x.subcategory,40);if(c&&s){(sub[c]=sub[c]||{})[s]=(sub[c][s]||0)+1}}
  const cats=tax.map(t=>({slug:t.slug,name:t.name,n:by[t.slug]||0})).filter(t=>t.n>0);
  for(const k of Object.keys(by))if(!cats.some(c=>c.slug===k))cats.push({slug:k,name:k.replace(/_/g,' '),n:by[k]});
  return {cats,sub,total:list.length,metro:list.some(x=>{const m=str(x&&x.metro,12);return m!==''&&JMETRO[m]!=null})}}
 const jsc=x=>num(x&&x.score)==null?-1:x.score;
 // filter is a site string (v6 callers) or {cat,sub,metro,site}; best fit first, newest breaks ties
 function jobFilter(j,f){const o=typeof f==='string'?{site:f}:(isObj(f)?f:{}),cat=str(o.cat,40),sub=str(o.sub,40),metro=str(o.metro,12),site=str(o.site,30);
  const list=jobList(j).filter(x=>(!site||site==='all'||str(x.site,30)===site)&&(!cat||cat==='all'||str(x.category,40)===cat)&&
   (!sub||sub==='all'||str(x.subcategory,40)===sub)&&(!metro||metro==='all'||str(x.metro,12)===metro));
  // the collector already emits a curated order (score inside each category, categories interleaved);
  // re-sorting here stacked one category on top and hid the owner's mix.
  return list}
 // annual pay: hourly text and unknown pay stay words; a known range reads $150K-$200K
 function jobPay(x){const lo=num(x&&x.pay_min),hi=num(x&&x.pay_max);
  if(lo!=null&&hi!=null)return lo===hi?usd(lo):usd(lo)+'-'+usd(hi);
  if(hi!=null)return 'up to '+usd(hi);if(lo!=null)return usd(lo)+'+';
  return str(x&&x.pay_text,48)||str(x&&x.salary,40)}
// one posting is one row: the row itself opens the detail sheet, the arrow beside it opens the
// posting, and only a safe http(s) url becomes that link. The cues ride inside the row.
 function jobRow(x,i,now){const t=str(x&&x.title,90)||'listing',pay=jobPay(x),sc=num(x&&x.score),ageTxt=x&&x.posted_at!=null?ago(x.posted_at,now):'',
  sub=[str(x&&x.company,40),JMETRO[str(x&&x.metro,12)]||str(x&&x.location,40),JMODE[str(x&&x.mode,12)]||(x&&x.remote===true?'remote':'')].filter(Boolean).join(' \u00B7 '),
  meta=[pay,str(x&&x.site,16),ageTxt].filter(Boolean).join(' \u00B7 '),u=safeUrl(x&&x.url);
  return '<div class="frow"><button type="button" class="jrow" data-j="'+i+'" aria-label="Job detail: '+esc(t)+'"><span class="jl"><b>'+esc(t)+'</b>'+
   (sub?'<small>'+esc(sub)+'</small>':'')+'<small class="jm">'+esc(meta||'pay and date not reported')+'</small>'+jobCue(x)+'</span>'+
   '<span class="jr"><b>'+(sc==null?'--':fmt(sc))+'</b><small>'+esc(ageTxt?'fit \u00B7 '+ageTxt:'fit')+'</small></span></button>'+
   (u?'<a class="jl-open" href="'+esc(u)+'" target="_blank" rel="noopener noreferrer" aria-label="'+esc('Open posting: '+t)+'">'+LK+'</a>':'')+'</div>'}
 // compact market strip for the chosen category (whole-market totals when no category is chosen)
 function jobStrip(j,catName,slug,opt,now){const mk=isObj(j&&j.market)?j.market:null;if(!mk)return '';
  const bc=slug&&isObj(mk.by_category)&&isObj(mk.by_category[slug])?mk.by_category[slug]:null;
  if(!bc&&!isObj(mk.by_metro))return '';
  const bm=bc&&isObj(bc.by_metro)?bc.by_metro:mk.by_metro;
  // a metro entry is a count, or {total, by_category} in the whole-market block
  const mv=v=>num(v)!=null?num(v):isObj(v)?num(v.total):null;
  const nums=JMETRO_ORDER.map(m=>({m,n:bm?mv(bm[m]):null}));
  const cells='<div class="jcs">'+nums.map(x=>'<span class="jc"><b>'+(x.n==null?'--':fmt(x.n))+'</b>'+esc(JMETRO[x.m])+'</span>').join('')+'</div>';
  const med=num(bc&&bc.median_pay_max),dv=num(bc&&bc.delta_vs_prev),drop=num(bc&&bc.remote_unknown_pay_dropped);
  const emp=arr(bc&&bc.top_employers).filter(isObj).map(e=>{const n=str(e.name,26);return n?n+' '+fmt(e.count):''}).filter(Boolean).slice(0,3);
  const ins=isObj(opt&&opt.insight)?opt.insight:null,take=ins&&slug&&isObj(ins.categories)?str(ins.categories[slug],220):'';
  const lines=[];
  if(num(bc&&bc.total)!=null)lines.push(fmt(bc.total)+' jobs');
  if(med!=null)lines.push('median top pay '+usd(med));
  if(dv!=null)lines.push((dv>0?'+'+fmt(dv):dv<0?fmt(dv):'no change')+' vs last run');
  if(emp.length)lines.push('hiring most: '+emp.join(' \u00B7 '));
  if(drop!=null&&drop>0)lines.push(fmt(drop)+' remote dropped: pay unknown');
  const hdr='<div class="secttl"><span>'+esc('Market \u00B7 '+(catName||'all jobs'))+'</span><span>'+esc(mk.generated_at!=null?ago(mk.generated_at,now):'no date reported')+'</span></div>';
  return '<div class="jstrip">'+hdr+
   cells+(lines.length?'<div class="jline">'+esc(lines.join(' \u00B7 '))+'</div>':'')+
   (take?'<div class="jtk2"><b>Local cluster read</b> '+esc(take)+'<small>'+esc((str(ins.model,40)||'model not reported')+' \u00B7 '+ago(ins.t,now))+'</small></div>':'')+'</div>'}
 // detail sheet body: category and sub-category with their definitions, summary, why reasons, the
 // local cluster take with its model and age, pay, flags, the owner's note and the source link
 function jobSheet(x,j,opt,now){if(!isObj(x))return '<div class="jshb"><div class="tnote">No listing selected</div></div>';
  const o=isObj(opt)?opt:{},ins=isObj(o.insight)?o.insight:null,tax=jobTax(j),cat=jobCat(tax,x.category),sub=jobSub(cat,x.subcategory);
  const t=str(x.title,90)||'listing',u=safeUrl(x.url),pay=str(x.pay_text,60)||jobPay(x),sum=str(x.summary,280);
  const why=arr(x.why).map(w=>str(w,120)).filter(Boolean).slice(0,3),own=str(x.cluster_take,200);
  const take=own||(ins&&isObj(ins.takes)?str(ins.takes[str(x.url,400)],200):'');
  const ftxt=arr(x.flag_text).map(f=>str(f,80)).filter(Boolean);
  const flags=ftxt.length?ftxt:arr(x.flags).map(f=>str(f,20).replace(/_/g,' ')).filter(Boolean);
  const meta=[str(x.company,40),JMETRO[str(x.metro,12)]||str(x.location,40),JMODE[str(x.mode,10)]||(x.remote===true?'remote':'')].filter(Boolean).join(' \u00B7 ');
  const when=[str(x.site,16),x.posted_at!=null?'posted '+ago(x.posted_at,now):''].filter(Boolean).join(' \u00B7 ');
  return '<div class="jshbar"><div class="jsht">'+esc(t)+'</div><button type="button" class="vb" id="jshx" aria-label="Close job detail">\u2715</button></div><div class="jshb">'+
   (meta?'<div class="jshco">'+esc(meta)+'</div>':'')+
   (cat?'<div class="jtags"><span class="jtag">'+esc(cat.name)+'</span>'+(sub?'<span class="jtag alt">'+esc(sub.name)+'</span>':'')+'</div>':'')+
   (cat&&(cat.definition||(sub&&sub.definition))?'<div class="jdef"><b>'+esc(cat.name)+'.</b> '+esc(cat.definition||'no definition yet')+
     (sub?' <b>'+esc(sub.name)+'.</b> '+esc(sub.definition||'no definition yet'):'')+'</div>':'')+
   (sum?'<p class="jsum">'+esc(sum)+'</p>':'')+
   (why.length?'<div class="jwhy"><b>Why it fits</b><ul>'+why.map(w=>'<li>'+esc(w)+'</li>').join('')+'</ul></div>':'')+
   (take?'<div class="jtk"><b>Local cluster take</b><p>'+esc(take)+'</p><small>'+esc(str(ins&&ins.model,40)||'model not reported')+(ins&&ins.t!=null?' \u00B7 '+esc(ago(ins.t,now)):'')+'</small></div>':'')+
   (pay?'<div class="jline"><b>Pay.</b> '+esc(pay)+'</div>':'')+
   (flags.length?'<div class="jtags">'+flags.map(f=>'<span class="jflag">'+esc(f)+'</span>').join('')+'</div>':'')+
   (x.note?'<div class="jline"><b>Your note.</b> '+esc(str(x.note,200))+'</div>':'')+
   (when?'<div class="jshf">'+esc(when)+'</div>':'')+
   (u?'<a class="b jshopen" href="'+esc(u)+'" target="_blank" rel="noopener noreferrer">Open posting</a>':'<div class="jshf">No link reported by the source</div>')+'</div>'}
 // normalized filter state for one jobs feed: category, sub-category, metro and site
 function jobStateOf(j,facets,tax,f){const o=typeof f==='string'?{site:f}:(isObj(f)?f:{});
  const cat=facets.cats.some(c=>c.slug===str(o.cat,40))?str(o.cat,40):'all',catObj=jobCat(tax,cat);
  return {cat,catObj,sub:jobSub(catObj,o.sub)?str(o.sub,40):'all',metro:JMETRO[str(o.metro,12)]?str(o.metro,12):'all',
   site:str(o.site,30)||'all',all:jobList(j),sites:jobSites(j)}}
 function jobFilterSummary(st){const p=[st.catObj?st.catObj.name:'All '+st.all.length+' jobs'];
  const s=st.catObj&&st.sub!=='all'?jobSub(st.catObj,st.sub):null;
  if(s)p.push(s.name);
  if(st.metro!=='all')p.push(JMETRO[st.metro]);
  if(st.site!=='all')p.push(st.site);
  return p.join(' \u00B7 ')}
 // chip groups in the order they appear inline and in the filter sheet. A feed with no taxonomy
 // gets the site group only, which is the whole filter for the old contract.
 function jobChipGroups(j,facets,st){const g=[];
  const siteRow='<div class="chips" id="jsites" role="group" aria-label="Job sites"><button type="button" class="b jchip'+(st.site==='all'?' on':'')+'" data-site="all">All '+st.all.length+'</button>'+
   st.sites.map(s=>'<button type="button" class="b jchip'+(st.site===s.site?' on':'')+'" data-site="'+esc(s.site)+'">'+esc(s.site)+' '+fmt(s.n)+'</button>').join('')+'</div>';
  if(!facets.cats.length){g.push({k:'site',label:'Site',html:siteRow});return g}
  const cnt=facets.cats.find(c=>c.slug===st.cat);
  g.push({k:'cat',label:'Category',html:'<div class="chips" id="jcat" role="group" aria-label="Job categories"><button type="button" class="b jchip'+(st.cat==='all'?' on':'')+'" data-cat="all">All '+st.all.length+'</button>'+
   facets.cats.map(c=>'<button type="button" class="b jchip'+(st.cat===c.slug?' on':'')+'" data-cat="'+esc(c.slug)+'">'+esc(c.name)+' '+c.n+'</button>').join('')+'</div>'});
  if(st.catObj){const bySub=facets.sub[st.catObj.slug]||{},subs=st.catObj.subs.filter(s=>bySub[s.slug]!=null).map(s=>({slug:s.slug,name:s.name,n:bySub[s.slug]}));
   for(const k of Object.keys(bySub))if(!subs.some(s=>s.slug===k))subs.push({slug:k,name:k.replace(/_/g,' '),n:bySub[k]});
   if(subs.length)g.push({k:'sub',label:st.catObj.name,html:'<div class="chips" id="jsub" role="group" aria-label="Job sub-categories"><button type="button" class="b jchip'+(st.sub==='all'?' on':'')+'" data-sub="all">All '+(cnt?cnt.n:subs.reduce((a,b)=>a+b.n,0))+'</button>'+
    subs.map(s=>'<button type="button" class="b jchip'+(st.sub===s.slug?' on':'')+'" data-sub="'+esc(s.slug)+'">'+esc(s.name)+' '+s.n+'</button>').join('')+'</div>'})}
  if(facets.metro)g.push({k:'metro',label:'Where',html:'<div class="chips" id="jmetro" role="group" aria-label="Job metro"><button type="button" class="b jchip'+(st.metro==='all'?' on':'')+'" data-metro="all">Anywhere</button>'+
   JMETRO_ORDER.map(m=>'<button type="button" class="b jchip'+(st.metro===m?' on':'')+'" data-metro="'+m+'">'+esc(JMETRO_CHIP[m])+'</button>').join('')+'</div>'});
  g.push({k:'site',label:'Site',html:siteRow});
  return g}
// paging shared by the two Life lists: a number is how many rows to show, 'short' opens short,
// 'all' opens everything up to the cap, and no mode is the plain list. Every Show more count is
// exactly what that tap adds, and a list past its cap says "Showing N of M".
 const moreBtn=(k,label)=>'<button type="button" class="b more" data-more="'+k+'">'+esc(label)+'</button>';
 const fewerBtn=k=>'<button type="button" class="b more" data-less="1" data-more="'+k+'">Show fewer</button>';
 const capNote=(shown,total,cap)=>total>cap?'<div class="tnote">Showing '+shown+' of '+total+'</div>':'';
 function paged(mode,short,step,cap,total){const reach=Math.min(total,cap),
  n=typeof mode==='number'&&isFinite(mode)?Math.round(mode):mode==='short'?short:mode==='all'?cap:null,
  lim=n==null?cap:Math.max(short,Math.min(n,cap)),shown=Math.min(reach,lim);
  return {shown,reach,page:n!=null,fewer:n!=null&&shown>short,
   more:(k,label)=>n!=null&&reach>shown?moreBtn(k,'Show '+Math.min(step,reach-shown)+' more'+(label||'')):''}}
 function jobs(j,filter,now,opt){if(state(j)=='bad')return head('Jobs',j,now)+down('Jobs feed',j,'life');
  const o=isObj(opt)?opt:{},mode=isObj(opt)?(num(o.page)!=null?num(o.page):'short'):opt,
   facets=jobFacets(j),tax=jobTax(j),st=jobStateOf(j,facets,tax,filter),groups=jobChipGroups(j,facets,st);
  if(!st.all.length)return head('Jobs',j,now)+empty({title:'No job listings yet',line:'New matches show up after the next search.',retry:'life'})+errRows(j);
  const list=jobFilter(j,{cat:st.cat,sub:st.sub,metro:st.metro,site:st.site}),pg=paged(mode,JOB_SHORT,JOB_STEP,JOB_CAP,list.length),shown=list.slice(0,pg.shown);
  let chips;
  if(!facets.cats.length||!o.compact)chips=groups.map(g=>g.k==='site'&&facets.cats.length?'<details class="jsec"><summary>Site filter</summary>'+g.html+'</details>':g.html).join('');
  else chips='<button type="button" class="b jfbar" data-filter="open" aria-label="Job filters">'+esc(jobFilterSummary(st))+'<small>Filter</small></button>';
  return head('Jobs',j,now)+chips+(o.compact?'':(jobProfileNote(o.profile)||''))+
   (o.compact?'':(jobStrip(j,st.catObj?st.catObj.name:'',st.cat==='all'?'':st.cat,o,now)))+
   '<div class="flist jlist">'+(shown.length?shown.map((x,i)=>jobRow(x,i,now)).join(''):'<div class="frow"><span class="fl"><small>No listings for this filter</small></span></div>')+'</div>'+
   capNote(pg.shown,list.length,JOB_CAP)+(pg.page?pg.more('jobs','')+(pg.fewer?fewerBtn('jobs'):''):'')+errRows(j)}
 // the filter sheet body: every group with its own label, the same buttons as the inline row
 function jobFilters(j,filter,now,opt){if(state(j)=='bad')return '<div class="jshbar"><div class="jsht">Job filters</div><button type="button" class="vb" id="jfx" aria-label="Close filters">\u2715</button></div><div class="jshb"><div class="tnote">Jobs feed unavailable</div></div>';
  const o=isObj(opt)?opt:{},facets=jobFacets(j),tax=jobTax(j),st=jobStateOf(j,facets,tax,filter),groups=jobChipGroups(j,facets,st);
  return '<div class="jshbar"><div class="jsht">Job filters</div><button type="button" class="vb" id="jfx" aria-label="Close filters">\u2715</button></div><div class="jshb">'+
   (jobProfileNote(o.profile)||'')+
   groups.map(g=>'<div class="jgrp"><div class="jlab">'+esc(g.label)+'</div>'+g.html.replace('class="chips"','class="chips wrap"')+'</div>').join('')+
   jobStrip(j,st.catObj?st.catObj.name:'',st.cat==='all'?'':st.cat,{},now)+
   '<div class="jshf">'+esc(jobSrcLine(j,now))+'</div></div>'}
 function jobSrcLine(j,now){return 'jobs.json \u00B7 '+(j&&j.t!=null?ago(j.t,now):'no time')+' \u00B7 '+arr(isObj(j)&&j.listings).length+' listings'}
 // the interest profile is still reading the owner's own sources: name how many parts and their size,
 // never their contents. A profile with no pending parts and partial false says nothing at all.
 function jobProfileNote(prof){const p=isObj(prof)?prof:{},pend=arr(p.pending),n=pend.length;
  if(!n&&p.partial!==true)return null;
  const bytes=pend.reduce((a,x)=>a+(num(isObj(x)?x.bytes:null)||0),0),gb=bytes>0?bytes/1073741824:null;
  return '<div class="jline"><span class="jflag">profile partial</span> '+
   (n?n+' takeout part'+(n===1?'':'s')+' still loading'+(gb!=null?' ('+gb.toFixed(0)+' GB)':''):'still reading your sources')+'</div>'}
 // Personally relevant headlines only: housing, rates, OC economy, AI companies, fire/public
 // safety, sports business. Each row names its source and age; the topic chip comes from the feed.
 const TOPIC_WORD={housing:'Housing',rates:'Rates',local:'Local',ai:'AI companies',fire:'Fire',sports:'Sports business',markets:'Markets'};
 // a story is a link only when its url is a safe http(s) one; otherwise the row is plain text
 function markets(t,now,failed){const k=isObj(t)&&isObj(t.markets)?t.markets:null;
  if(!k||k.error||!Array.isArray(k.items)){const p=problem(k||null);
   return '<div class="secttl"><span>Market news</span><span>Not reporting</span></div>'+empty({k:'bad',title:'Market news is not reporting',line:p.line,retry:'life',diag:p.diag})}
  return '<div class="secttl"><span>Market news</span><span>'+((failed||k.stale)?'Out of date \u00B7 ':'')+'Updated '+esc(ago(k.t,now))+'</span></div><div class="flist">'+
   k.items.filter(isObj).slice(0,6).map(i=>{const tp=str(i&&i.topic,16),word=TOPIC_WORD[tp]||'';
    return row(str(i&&i.title,140),str(i&&i.source,30)+' \u00B7 '+ago(i&&i.at,now),word?'<small class="mk-t">'+esc(word)+'</small>':'','',i&&i.url)}).join('')+'</div>'}
 function spotLabel(x){const name=str(x&&x.name,30)||'spot',aka=str(x&&x.aka,16);return aka?aka+' / '+name:name}
 function ftPair(a,b,d){const lo=fmt(a,d),hi=fmt(b,d);return lo===hi?lo:lo+'-'+hi}
 function surfOutlook(spots,now){const rows=arr(spots).filter(isObj).slice(0,8).map(x=>{
   const days=arr(x.outlook).filter(isObj).slice(0,5),win=isObj(x.best_window)?x.best_window:null;
   if(!days.length&&!win)return '';
   const src=str((win&&win.source)||(days[0]&&days[0].source),80),at=win&&win.at!=null?win.at:(days[0]&&days[0].at);
   return '<div class="sh-spot'+(x.role==='reference'?' sh-ref':'')+'"><b>'+esc(spotLabel(x))+'</b>'+
    (win?'<small>'+esc(str(win.label,40))+' \u00B7 '+esc(str(win.reason,140))+'</small>':'')+
    (days.length?'<div class="sh-days">'+days.map(d=>'<span>'+esc((str(d.date,10).slice(5)||'--')+' '+ftPair(d.wave_ft_min,d.wave_ft_max,0))+'</span>').join('')+'</div>':'')+
    (src?'<small class="sh-src">'+esc(src)+(at!=null?' \u00B7 '+esc(ago(at,now)):'')+'</small>':'')+'</div>'}).join('');
  return rows?'<div class="sh-outlook">'+rows+'</div>':''}
 function sunRow(tide){const sun=isObj(tide&&tide.sun)?tide.sun:null;if(!sun)return '';
  const rise=str(sun.sunrise_pt,20)||clock(sun.sunrise),set=str(sun.sunset_pt,20)||clock(sun.sunset);
  return row('Sun',rise+' to '+set,'<small>'+esc(str(sun.source,40))+'</small>','','')}
 function teamExtra(t){const n=isObj(t&&t.next_game)?t.next_game:{},bits=[str(t&&t.form,24)?str(t.abbr,6)+' form '+str(t.form,24):'',str(n.time_pt,28),str(t&&t.league,8)==='AHL'?'AHL':'',str(t&&t.source,40)].filter(Boolean);
  return bits.length?'<div class="sh-form">'+esc(bits.join(' \u00B7 '))+'</div>':''}
 function surf(s,now){if(state(s)=='bad')return head('Surf',s,now)+down('Surf feed',s,'life');
  const tide=isObj(s.tide)?s.tide:{},nx=arr(tide.next).slice(0,3),gs=surfGroups(s.spots).slice(0,8),sun=sunRow(tide);
 return head('Surf',s,now)+(gs.length||nx.length||sun?'<div class="flist">'+gs.map(surfRow).join('')+tideRow(tide,nx)+sun+'</div>':'')+surfOutlook(s.spots,now)+errRows(s)}
// Life: On this day. Per-year counts from the photo catalog, the total and the years only: no item ids, names or thumbnails.
const MON3=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
function onThisDay(f,now){const k=state(f);
 if(k=='bad')return head('On this day',f,now)+down('On this day',f,'life');
 const tot=num(f.total),yrs=arr(f.years).filter(isObj).filter(y=>num(y.year)!=null&&num(y.count)!=null).sort((a,b)=>b.year-a.year);
 const p=str(f.month_day,5).split('-'),mo=MON3[parseInt(p[0],10)-1],dd=parseInt(p[1],10),when=mo&&dd?mo+' '+dd:'today';
 if(tot==null)return head('On this day',f,now)+empty({k:'bad',title:'Photo counts are not reporting',line:'The photo catalog could not be read. Nothing is shown as zero.',retry:'life'})+errRows(f);
 if(tot===0)return head('On this day',f,now)+empty({k:'idle',title:'No photos or videos from earlier years on '+when,line:'Counted from the photo catalog, Pacific time.'})+errRows(f);
 return head('On this day',f,now)+tile('Taken on '+when,cnt(tot)+(tot===1?' photo or video':' photos and videos'),yrs.length+(yrs.length===1?' earlier year':' earlier years')+' with a match',k=='stale'?'stale':'ok')+
  '<div class="flist">'+yrs.map(y=>row(String(y.year),cnt(y.count)+(y.count===1?' item':' items'),'','')).join('')+'</div>'+errRows(f)}
// Life: Years in photos. Per-year image and video counts and the totals only: no item ids, names or thumbnails.
// Years with nothing are left out of the list; the tile says how many years have photos.
function yearsInPhotos(f,now){const k=state(f);
 if(k=='bad')return head('Years in photos',f,now)+down('Years in photos',f,'life');
 const tot=num(f.dated_total),und=num(f.undated),
  ys=arr(f.years).filter(isObj).filter(y=>num(y.year)!=null&&num(y.image)!=null&&num(y.video)!=null).map(y=>({year:y.year,image:y.image,video:y.video,n:y.image+y.video})).filter(y=>y.n>0).sort((a,b)=>b.year-a.year).slice(0,40);
 if(tot==null)return head('Years in photos',f,now)+empty({k:'bad',title:'Photo counts are not reporting',line:'The photo catalog could not be read. Nothing is shown as zero.',retry:'life'})+errRows(f);
 if(tot===0&&!ys.length)return head('Years in photos',f,now)+empty({k:'idle',title:'No dated photos or videos in the catalog',line:'Counted from the photo catalog, Pacific time.'})+errRows(f);
 const sub=ys.length+(ys.length===1?' year':' years')+' with photos or videos'+(und>0?' \u00B7 '+cnt(und)+' without a date':'');
 return head('Years in photos',f,now)+tile('Photos and videos by year',cnt(tot)+(tot===1?' photo or video':' photos and videos'),sub,k=='stale'?'stale':'ok')+
  '<div class="flist">'+ys.map(y=>row(String(y.year),cnt(y.image)+(y.image===1?' photo':' photos')+(y.video>0?', '+cnt(y.video)+(y.video===1?' video':' videos'):''),'<b>'+cnt(y.n)+'</b>','')).join('')+'</div>'+errRows(f)}
// Life: Reply block. Written before 09:00 by reply-block (Gmail drafts only, never sent). Counts, the ranked threads and links into Gmail;
// no message text. Links open only mail.google.com.
const gmailUrl=u=>/^https:\/\/mail\.google\.com\/mail\/u\/\d\/#[a-z]+(\/[\w-]+)?$/.test(u)?u:'';
function replyBlock(f,now){const k=state(f);
 if(k=='bad')return head('Reply block',f,now)+down('Reply block',f,'life');
 const c=isObj(f.counts)?f.counts:{},drafted=num(c.drafted),wait=num(c.waiting),cap=num(c.cap),over=num(c.over_cap),after=num(c.gmail_drafts_after),dry=f.mode==='dry-run';
 if(drafted==null||wait==null)return head('Reply block',f,now)+empty({k:'bad',title:'Reply counts are not reporting',line:'The reply block ran but its counts are missing. Nothing is shown as zero.',retry:'life'})+errRows(f);
 const model=isObj(f.model)&&f.model.used?'written by the local model':'plain templates, local model offline',
  sub=cnt(wait)+(wait===1?' thread':' threads')+' waiting on you'+(cap!=null?' \u00B7 up to '+cnt(cap)+' a day':'')+(over>0?' \u00B7 '+cnt(over)+' held over the cap':'')+(drafted>0?' \u00B7 '+model:'');
 const items=arr(f.items).filter(isObj).slice(0,15),
  rows=items.map(i=>row(clip(str(i.name,80),40)||'Unknown sender',clip(str(i.subject,160),70),'<b>'+(i.drafted===true?'Draft ready':'Held')+'</b>','',gmailUrl(str(i.draft_url,200))||gmailUrl(str(i.thread_url,200)))).join(''),
  all=gmailUrl(str(f.drafts_url,200));
 return head('Reply block',f,now)+tile(dry?'Dry run, nothing drafted':'Replies for the 09:00 block',cnt(drafted)+(drafted===1?' draft':' drafts'),sub,k=='stale'?'stale':'ok')+
  (rows?'<div class="flist">'+rows+'</div>':'<div class="flist">'+row('Nothing is waiting on you','The overnight pass found no thread that needs a reply.','','')+'</div>')+
  (all?'<div class="flist">'+row('Open Gmail drafts',after!=null?cnt(after)+(after===1?' draft':' drafts')+' in Gmail':'Drafts folder','','',all)+'</div>':'')+errRows(f)}
// Life: App Store rank watch. Chart fetch health, alert counts and the three newest alerts (warnings first). No per-app tables.
const RW_KIND={jump:'Jump',new_entrant:'New entrant',own_entered:'Entered chart',own_dropped:'Dropped out',own_live:'Live',own_gone:'Gone',category_mismatch:'Category'};
function rankWatch(f,now){const k=state(f);
 if(k=='bad')return head('Rank watch',f,now)+down('Rank watch',f,'life');
 const run=isObj(f.run)?f.run:{},c=isObj(f.counts)?f.counts:{},ok=num(run.ok_charts),bad=num(run.failed_charts),a7=num(c.alerts_7d),a1=num(c.alerts_today),apps=num(c.apps),live=num(c.live);
 if(ok==null||a7==null)return head('Rank watch',f,now)+empty({k:'bad',title:'Rank watch is not reporting charts',line:'The chart run or the alert counts are missing. Nothing is shown as zero.',retry:'life'})+errRows(f);
 const total=ok+(bad||0),
  al=arr(f.alerts).filter(isObj).map((a,i)=>({a,i})).sort((x,y)=>(y.a.severity==='warn')-(x.a.severity==='warn')||x.i-y.i).slice(0,3).map(x=>x.a);
 return head('Rank watch',f,now)+
  tile('App Store charts',cnt(ok)+' of '+cnt(total)+' read',(apps!=null?cnt(apps)+' apps tracked':'Apps tracked unknown')+(live!=null?' \u00B7 '+cnt(live)+' live':''),k=='stale'?'stale':bad>0?'warn':'ok')+
  tile('Alerts',cnt(a7)+(a7===1?' alert':' alerts')+' in 7 days',(a1!=null?cnt(a1)+' today':'Today unknown'),k=='stale'?'stale':a1>0?'warn':'ok')+
  '<div class="flist">'+(al.length?al.map(a=>row(clip(str(a.name,80),40)||'App',clip(str(a.text,240),110),'<b>'+esc(RW_KIND[a.kind]||str(a.kind,30).replace(/_/g,' ')||'Alert')+'</b>',a.severity==='warn'?'attnrow':'')).join(''):row('No alerts','Nothing moved in the last 7 days.','',''))+'</div>'+errRows(f)}
 const hockeyLink=g=>isObj(g)&&typeof g.gc==='string'&&g.gc.startsWith('/gamecenter/')?'https://www.nhl.com'+g.gc:'';
 function hockey(h,now){if(state(h)=='bad')return head('Hockey',h,now)+down('Hockey feed',h);
 // collector score order is home-away; say so instead of leaving it to guess
 const live=arr(h.live).map(g=>row('LIVE '+str(g&&g.away,6)+' @ '+str(g&&g.home,6),'P'+fmt(g&&g.period)+' \u00B7 '+str(g&&g.clock,8),'<b>'+esc(str(g&&g.score,12))+'</b><small>'+esc(str(g&&g.home,6))+' first</small>','',hockeyLink(g)));
 const teams=arr(h.teams).slice(0,6);
 return head('Hockey',h,now)+'<div class="flist">'+live.join('')+teams.map(t=>{const l=isObj(t&&t.last_game)?t.last_game:{},n=isObj(t&&t.next_game)?t.next_game:{};
   return row((str(t&&t.abbr,6)||str(t&&t.name,30))+' '+(str(t&&t.record,16)||'--')+' \u00B7 '+fmt(t&&t.points)+' pts',
    'Last '+(str(l.result,4)||'--')+' '+(str(l.score,12)||'')+' vs '+(str(l.opp,6)||'--')+' \u00B7 Next '+(n.home===false?'at ':'vs ')+(str(n.opp,6)||'--')+' '+clock(n.at)+(str(n.tv,16)?' \u00B7 '+str(n.tv,16):'')+(str(n.time_pt,28)?' \u00B7 '+str(n.time_pt,28):''),
    '<small>'+esc(str(t&&t.standing,24)||str(t&&t.league,8))+'</small>','',hockeyLink(n))}).join('')+'</div>'+teams.map(teamExtra).join('')+errRows(h)}
 function housingMatches(x,filter={}){
  return (!filter.state||filter.state==='all'||String(x.state||'').toUpperCase()===filter.state)&&(!filter.zip||String(x.zip||'').slice(0,5)===filter.zip);
 }
 function housingSources(r,now,compact=false,filter={}){
  const f=isObj(r&&r.market)&&isObj(r.market.feed_sources)?r.market.feed_sources:null;
  if(!f)return '';
  const sources=arr(f.sources).filter(isObj),ok=sources.filter(s=>s.status==='ok'),listing=ok.filter(s=>s.kind==='listings').length;
  const summary=tile('Housing source adapters',sources.length+' configured \u00B7 '+ok.length+' responding',
   listing+' additional listing feeds \u00B7 '+(ok.length-listing)+' enrichment sources \u00B7 checked '+ago(f.checked_at,now),ok.length?'ok':'stale');
  const scope=isObj(f.scope)?f.scope:{},national=scope.country==='US';
  const nationalNote=national?'<div class="tnote">United States: all states and DC requested. Published market data is not complete residential/commercial listing inventory.</div>':'';
  if(compact)return summary+nationalNote;
  const labels={ok:'Data returned',needs_key:'Needs API key',needs_approval:'Needs license/budget approval',needs_dataset:'Needs licensed/geographic dataset',stale:'STALE cache',error:'Request failed',unavailable:'Unavailable'};
  const status=s=>labels[s.status]||str(s.status,30)||'Unknown';
  const detail=s=>[str(s.kind,30).replace(/_/g,' '),str(s.coverage,180),'data as of '+(str(s.data_as_of,60)||'not reported'),
   'checked '+ago(s.checked_at,now),s.all_states_observed?'All states observed in returned data':'',str(s.reason,140)].filter(Boolean).join(' \u00B7 ');
  const rows=sources.map(s=>row(str(s.name,60),detail(s),'<b>'+esc(status(s))+'</b><small>'+(s.count==null?'--':fmt(s.count))+' records'+(s.sample?' \u00B7 sample':'')+'</small>',s.status==='ok'?'':s.status==='error'?'bad':'stale',s.docs)).join('');
  const states=arr(scope.states).concat(arr(scope.districts));
  const controls=national?'<div class="tnote">State and ZIP filters apply to returned API previews, not every cached record. Missing matches do not mean no homes or market data.</div><div class="housing-filters chips wrap"><label class="chip hf"><small>State</small><select data-housing-state aria-label="Housing state"><option value="all">Whole United States</option>'+states.map(s=>'<option value="'+esc(s)+'"'+(filter.state===s?' selected':'')+'>'+esc(s)+'</option>').join('')+'</select></label><label class="chip hf"><small>ZIP</small><input data-housing-zip aria-label="Housing ZIP" inputmode="numeric" maxlength="5" value="'+esc(filter.zip||'')+'"></label><button type="button" class="b hfa" data-housing-apply>Apply</button></div>':'';
  // W6: the live page opens short (3 sources, 4 records each); Show more is the same toggle as the homes list and opens 20 records of every source. No page mode (older callers) keeps the plain 20.
  const pg=filter&&(filter.page==='short'||filter.page==='all')?filter.page:null,short=pg==='short',per=short?4:20,srcCap=short?3:1e3;
  const blocks=sources.filter(s=>s.status==='ok').map(s=>({s,matches:arr(s.records).filter(isObj).filter(x=>x.metric).filter(x=>housingMatches(x,filter))})).filter(b=>b.matches.length);
  const stats=blocks.slice(0,srcCap).map(({s,matches})=>
   '<div class="secttl"><span>'+esc(str(s.name,60))+'</span><span>'+matches.length+' matching records</span></div><div class="flist wrap">'+
    matches.slice(0,per).map(x=>row(str(x.zip,8)||str(x.place,70)||str(x.metric,60),
      [str(x.state,2),str(x.city,40),str(x.as_of,30),str(x.metric,50)].filter(Boolean).join(' \u00B7 '),
      '<b>'+esc(x.currency==='USD'?usd(x.value):fmt(x.value,2,x.unit==='percent'?'%':''))+'</b>','','')).join('')+
    '</div>'+(matches.length>per?'<div class="tnote">Showing '+per+' of '+matches.length+' matching records. '+(short?'Show more to read further.':'Select a state or ZIP to narrow.')+'</div>':'')).join('')+
   (short&&blocks.length>srcCap?'<div class="tnote">'+(blocks.length-srcCap)+(blocks.length-srcCap===1?' more source has':' more sources have')+' matching records.</div>':'');
  const open=short&&(blocks.length>srcCap||blocks.some(b=>b.matches.length>per)),back=pg==='all'&&(blocks.length>3||blocks.some(b=>b.matches.length>4));
  return summary+nationalNote+controls+stats+(open?moreBtn('homes','Show more records'):back?fewerBtn('homes'):'')+'<details><summary>Source health and coverage</summary><div class="flist">'+rows+'</div></details>';
 }
 // ---- life: Homes. Owner markets first (Dana Point, South OC, then OC, LA, SD), US selectable.
 // Every number carries its publisher and date; a missing series prints "--", never zero.
 const TIER_WORD={home:'Home ZIP',south_oc:'South OC',oc:'Orange County',la:'LA County',sd:'San Diego',us:'United States'};
 const mileage=v=>{const n=num(v);if(n==null)return '--';if(n>=1e6)return '$'+(n/1e6).toFixed(2)+'M';if(n>=1e3)return '$'+Math.round(n/1e3)+'K';return '$'+Math.round(n)};
 const bn=v=>{const n=num(v);if(n==null)return '--';return n>=1000?'$'+(n/1000).toFixed(2)+'T':'$'+Math.round(n)+'B'};
 const signed=v=>{const n=num(v);return n==null?'':' '+(n>0?'+':'')+n.toFixed(1)+'%'};
 const day=v=>str(v,10)||'no date';
 const hcnt=v=>{const n=num(v);return n==null?'--':String(Math.round(n)).replace(/\B(?=(\d{3})+(?!\d))/g,',')};
 const areaLine=(a)=>{
  const zhvi=isObj(a&&a.zhvi)?a.zhvi:null,parts=[];
  if(isObj(a&&a.inventory))parts.push('inv '+hcnt(a.inventory.value));
  else if(num(a&&a.active_listings)!=null)parts.push('inv '+cnt(a.active_listings));
  const list=isObj(a&&a.list_price)?a.list_price.value:num(a&&a.realtor_list_price);
  if(num(list)!=null)parts.push('list '+mileage(list));
  if(isObj(a&&a.sale_price))parts.push('sale '+mileage(a.sale_price.value));
  if(isObj(a&&a.days_to_pending))parts.push(fmt(a.days_to_pending.value)+'d to pending');
  else if(num(a&&a.days_on_market)!=null)parts.push(fmt(a.days_on_market)+'d on market');
  const right=zhvi?'<b>'+esc(mileage(zhvi.value))+'</b><small>ZHVI'+esc(signed(zhvi.yoy_pct))+(zhvi.yoy_pct!=null?' 1y':'')+'</small>':'<b>--</b><small>no ZHVI</small>';
  return '<div class="hm-area frow"><span class="fl"><b>'+esc(str(a&&a.name,40)||'area')+'<em class="hm-tier">'+esc((TIER_WORD[a&&a.tier]||'')+(a&&a.zip?' '+a.zip:''))+'</em></b>'+
   '<small>'+esc(parts.join(' \u00B7 ')||'no public numbers for this area')+'</small>'+
   '<small class="hm-asof">'+(zhvi?'Zillow ZHVI as of '+esc(day(zhvi.as_of)):'as of unavailable')+'</small></span><span class="fr">'+right+'</span></div>'};
 // Feeds written before the area series existed carry one headline median for the owner's area. Show that
 // number with its publisher and date instead of claiming there is no market series at all.
 const legacyMarkets=(m,now)=>{
  const lp=num(m&&m.median_list_price),rent=num(m&&m.median_rent),area=str(m&&m.area,40),src=str(m&&m.source,20),at=toEpoch(m&&m.at);
  if(lp==null&&rent==null)return '';
  const parts=[area?esc(area):'',lp!=null?'median list '+mileage(lp):'',rent!=null?'median rent '+usd(rent):'',src?esc(src):''].filter(Boolean).join(' \u00B7 ');
  return '<div class="hm-area frow"><span class="fl"><b>'+esc(area||'Median price')+'</b><small>'+parts+'</small>'+
   '<small class="hm-asof">'+(at!=null?'as of '+esc(ago(at,now)):'as of unavailable')+'</small></span>'+
   '<span class="fr"><b>'+esc(mileage(lp))+'</b><small>median list</small></span></div>'};
 function marketAreas(m,filter,now){
  const res=isObj(m&&m.residential)?m.residential:null;
  if(!res||!arr(res.areas).length){const leg=legacyMarkets(m,now==null?Date.now()/1000:now);
   return {html:leg||tile('Your markets','No series yet','no public market series in the feed yet','stale'),note:''}}
  const scope=filter&&filter.scope==='us'?'us':'markets',areas=arr(res.areas).filter(isObj);
  const shown=scope==='us'?areas.filter(a=>a.tier==='us'):areas;
  const chips='<div class="chips hm-scope"><button type="button" class="b hmsc'+(scope==='markets'?' on':'')+'" data-housing-scope="markets">My markets</button>'+
   '<button type="button" class="b hmsc'+(scope==='us'?' on':'')+'" data-housing-scope="us">United States</button></div>';
  const note=scope==='us'?'<div class="tnote">Whole US national series. Switch back to My markets for Dana Point and South OC.</div>':'';
  return {html:chips+'<div class="hm-list">'+shown.map(areaLine).join('')+'</div>'+
   '<div class="tnote">Zillow Research for value, inventory and prices. Realtor.com for days on market. County order: '+
   esc(str(isObj(res.scope)?res.scope.home:'',40))+' outward.</div>',note}};
 function marketRates(m){
  const mo=isObj(m&&m.mortgage)?m.mortgage:{},r30=isObj(mo.rate_30y)?mo.rate_30y:null,r15=isObj(mo.rate_15y)?mo.rate_15y:null;
  if(!r30&&!r15)return tile('Mortgage rates','No reading','FRED did not answer','bad');
  return '<div class="hm-rates">'+mini('30y fixed',r30?fmt(r30.value,2,'%'):'No reading','FRED '+day(r30&&r30.as_of),r30?'ok':'bad')+
   mini('15y fixed',r15?fmt(r15.value,2,'%'):'No reading','FRED '+day(r15&&r15.as_of),r15?'ok':'bad')+'</div>'};
 function marketTake(m,now){
  const t=isObj(m&&m.cluster_take)?m.cluster_take:null;
  if(!t)return '';
  if(t.status==='unavailable')return '<div class="hm-take bad"><div class="h">'+SD('warn')+'Cluster take</div><p>'+esc(str(t.reason,160)||'local cluster did not answer')+'</p><small>local cluster · no take instead of an invented one</small></div>';
  return '<div class="hm-take"><div class="h">'+SD('ok')+'Cluster take</div><p>'+esc(str(t.text,400))+'</p><small>'+esc(str(t.model,40)||'local cluster')+' · '+(t.t==null?'no time':ago(t.t,now))+(t.cached?' · cached':'')+' · numbers only</small></div>'};
 function commercialBlock(m,r,cs,now){
  const c=isObj(m&&m.commercial_indicators)?m.commercial_indicators:{},g=isObj(c.price_growth)?c.price_growth:null,loans=isObj(c.loan_balance_bn)?c.loan_balance_bn:null;
  const vac=isObj(c.vacancy)?c.vacancy:null;
  let html='<div class="secttl"><span>Commercial</span><span>'+(g||loans?'FRED · '+cs.length+' for-sale listings':'no indicator')+'</span></div>';
  if(g||loans)html+='<div class="hm-rates">'+mini('CRE price growth',g?fmt(g.value,1,'%')+' /yr':'--','CoStar via FRED · '+day(g&&g.as_of),g?'ok':'bad')+
   mini('CRE bank loans',loans?bn(loans.value):'--','all US banks · '+day(loans&&loans.as_of),loans?'ok':'bad')+'</div>';
  html+=vac&&vac.status==='unavailable'?'<div class="hm-na"><b>Office and industrial vacancy</b><small>unavailable: '+esc(str(vac.reason,240))+'</small></div>':'';
  return html}

 function homes(r,now,filter={}){if(state(r)=='bad')return head('Homes',r,now)+down('Real estate feed',r,'life');
  const mode=typeof filter==='string'?filter:(isObj(filter)&&(filter.page==='short'||filter.page==='all'||num(filter.page)!=null)?filter.page:null),flt=isObj(filter)?filter:{},m=isObj(r.market)?r.market:{},
   hs=uniq(arr(r.homes).filter(isObj).filter(x=>housingMatches(x,flt)),x=>[x.addr,x.price,x.city,x.beds,x.sqft].join('|')),
   cs=uniq(arr(r.commercial).filter(isObj).filter(x=>housingMatches(x,flt)),x=>[x.addr,x.price,x.city,x.type,x.sqft].join('|')),
   hp=paged(mode,HOME_SHORT,HOME_CAP,HOME_CAP,hs.length),cp=paged(mode,COM_SHORT,COM_CAP,COM_CAP,cs.length),
   mk=marketAreas(m,flt,now);
  return head('Homes',r,now)+
   '<div class="secttl"><span>Your markets</span><span>'+(num(m.residential&&m.residential.areas_with_zhvi)?m.residential.areas_with_zhvi+' with ZHVI':'public series')+'</span></div>'+
   mk.html+mk.note+marketRates(m)+marketTake(m,now)+commercialBlock(m,r,cs,now)+
   '<div class="secttl"><span>For sale now</span><span>'+(hs.length?hs.length+' homes':'no listing rows')+'</span></div>'+
   '<div class="flist">'+hs.slice(0,hp.shown).map(x=>row(usd(x&&x.price)+' \u00B7 '+(str(x&&x.addr,50)||'address withheld'),[str(x&&x.city,24),fmt(x&&x.beds)+' bd',fmt(x&&x.baths,num(x&&x.baths)%1?1:0)+' ba',fmt(x&&x.sqft)+' sqft'].filter(Boolean).join(' \u00B7 '),
    '<small>'+esc(str(x&&x.source,16))+(x&&x.listed_at!=null?' \u00B7 '+esc(ago(x.listed_at,now)):'')+'</small>','',x&&x.url)).join('')+
   (hs.length?'' :empty({title:'No homes for this filter',line:'Every home in the feed is outside the state or ZIP you picked.'}))+'</div>'+
   capNote(hp.shown,hs.length,HOME_CAP)+(hp.page?hp.more('homes',' homes')+(hp.fewer?fewerBtn('homes'):''):'')+
   (cs.length?'<div class="secttl"><span>Commercial for sale</span><span>'+cs.length+'</span></div><div class="flist">'+cs.slice(0,cp.shown).map(x=>row(usd(x&&x.price)+' \u00B7 '+(str(x&&x.type,20)||'type?')+' \u00B7 '+(str(x&&x.city,24)||''),
    [str(x&&x.addr,50),fmt(x&&x.sqft)+' sqft',x&&x.cap_rate!=null?'cap rate '+fmt(x.cap_rate,1,'%'):''].filter(Boolean).join(' \u00B7 '),'<small>'+esc(str(x&&x.source,16))+'</small>','',x&&x.url)).join('')+'</div>'+
    capNote(cp.shown,cs.length,COM_CAP)+(cp.page?cp.more('homes','')+(cp.fewer?fewerBtn('homes'):''):''):'')+
   (m.legacy_inventory_scope?'<div class="tnote">'+esc(m.legacy_inventory_scope)+'</div>':'')+
   housingSources(r,now,false,flt)+errRows(r)}
 // ---- cluster tuning loop (perfloop feed, written by PerfLoop) ----
// The tuning loop was retired on 2026-10-07 and its feed keeps the last stale reading, including "STOP file present".
// Say it is retired, in one card, not the held reasons.
const RET_MON=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
const retiredOn=pf=>{if(!isObj(pf)||!(pf.retirement_date||/^retired/i.test(str(pf.status,40))))return null;const d=new Date(str(pf.retirement_date,30));
 return isNaN(d.getTime())?'earlier':RET_MON[d.getUTCMonth()]+' '+d.getUTCDate()};
 function perf(pf,now){if(state(pf)=='bad')return head('Tuning loop',pf,now)+down('Perf loop feed',pf,'cluster');
  const ret=retiredOn(pf);if(ret)return head('Tuning loop',pf,now)+tile('Status','Retired','Stopped on '+ret+'. Cluster tuning moved to Cluster Improve.','stale','wrap');
  const k=state(pf),ag=isObj(pf.agents)?pf.agents:{},ax=isObj(pf.active_experiment)?pf.active_experiment:null,lr=isObj(pf.last_result)?pf.last_result:null,
   q=isObj(pf.queue)?pf.queue:{},rt=isObj(pf.runs_today)?pf.runs_today:{},bl=isObj(pf.exec_blocked_by)?pf.exec_blocked_by:{},blk=Object.keys(bl).map(x=>str(x,30).replace(/_/g,' ')+': '+str(bl[x],80));
  const on=pf.stop===true?'Stopped':pf.enabled===true?'Running':pf.enabled===false?'Off':'Unknown';
  return head('Tuning loop',pf,now)+tile('Perf loop',on+' \u00B7 '+fmt(rt.total)+' runs today \u00B7 '+fmt(pf.experiments_today)+' experiments',
   'queue '+fmt(q.queued)+' queued, '+fmt(q.running)+' running \u00B7 last tick '+ago(pf.last_tick,now)+(pf.stop===true?' \u00B7 STOP file set':''),pf.stop===true?'stale':k,'wrap')+
   '<div class="flist">'+Object.keys(ag).filter(n=>isObj(ag[n])).map(n=>{const a=ag[n];
    return row(str(a.label,40)||n,(a.running===true?'running since '+ago(a.since,now).replace(' ago',''):'idle')+' \u00B7 last '+(str(a.last_action,30).replace(/_/g,' ')||'--'),'<b>'+fmt(a.runs_today)+'</b><small>runs today</small>',a.last_action==='error'?'bad':'','')}).join('')+
   (ax?row('Now: '+(str(ax.title,80)||str(ax.id,40)||'experiment'),(str(ax.phase,30)||'phase unknown')+(ax.eta?' \u00B7 eta '+str(ax.eta,30):''),'','',''):'')+
   (lr?row('Last: '+(str(lr.title,80)||str(lr.id,40)||'experiment'),(str(lr.note,90)||'')+(lr.finished?' \u00B7 '+ago(lr.finished,now):''),'<b>'+esc(str(lr.outcome,20).toLowerCase().replace(/_/g,' ')||'--')+'</b>'+(lr.gain!=null?'<small>gain '+esc(String(lr.gain).slice(0,12))+'</small>':''),/FAIL/.test(str(lr.outcome,20))?'bad':'',''):'')+
   blk.map(b=>row('Held',b,'','','')).join('')+'</div>'+errRows(pf)}

 // ---- home: products and owner actions (products feed) ----
// ---- home: products and owner actions (products feed) ----
 const ASC_WORD={PREPARE_FOR_SUBMISSION:'in prep',READY_FOR_SALE:'live',WAITING_FOR_REVIEW:'waiting for review',IN_REVIEW:'in review',UNRESOLVED_ISSUES:'issues open',
  REJECTED:'rejected',READY_FOR_REVIEW:'ready for review',COMPLETE:'complete',VALID:'valid',PROCESSING:'processing',INVALID:'invalid',FAILED:'failed',
  DEVELOPER_REJECTED:'pulled back',PENDING_DEVELOPER_RELEASE:'approved, not released'};
 const ascWord=s=>{const k=str(s,40);return ASC_WORD[k]||k.toLowerCase().replace(/_/g,' ')||'unknown'};
 const ptile=(h,v,t1,t2,k,url)=>{const u=safeUrl(url),tag=u?'a':'div';return '<'+tag+' class="tile pt'+(k=='bad'?' bad':k=='stale'?' stale':'')+'"'+(u?' href="'+esc(u)+'" target="_blank" rel="noopener noreferrer"':'')+'><div class="h">'+SD(k=='stale'?'warn':k||'ok')+esc(h)+'</div><div class="v">'+esc(v)+'</div>'+(t1?'<div class="t">'+esc(t1)+'</div>':'')+(t2?'<div class="t">'+esc(t2)+'</div>':'')+(u?LK:'')+'</'+tag+'>'};
 function appTile(a,k,now){
  if(!isObj(a))return empty({k:'bad',title:'App Store is not reporting',line:'App Store Connect did not answer. Try again.',retry:'home'});
  if(a.withheld===true)return ptile('App Store','Hidden','Details are not shown on this screen','','stale','');
  const name=str(a.name,60)||'App Store',v=isObj(a.version)?a.version:{},b=isObj(a.latest_build)?a.latest_build:{},r=isObj(a.review)?a.review:{},rs=str(r.state,30),live=str(a.live_version,12);
  return ptile(name,rs?ascWord(rs).replace(/^./,c=>c.toUpperCase()):'Not submitted','Version '+(str(v.string,12)||'unknown')+', '+ascWord(v.state)+' \u00B7 build '+fmt(v.build)+' attached',
   'Newest build '+fmt(b.number)+', '+ascWord(b.state)+(b.uploaded?' \u00B7 '+ago(b.uploaded,now):'')+(live?' \u00B7 live '+live:''),/UNRESOLVED|REJECT/.test(rs)?'bad':k,a.url)}
// every App Store app the feed lists, one tile each, at most eight. A feed without that list shows its single app_store as before.
function appTiles(p,k,now){const list=arr(isObj(p)?p.app_stores:null).filter(isObj).slice(0,8);
 return list.length?list.map(a=>appTile(a,k,now)).join(''):appTile(isObj(p)?p.app_store:null,k,now)}
 function siteTile(s,k){const st=str(s&&s.state,8),m=isObj(s&&s.monitor)?s.monitor:null,fails=m?arr(m.failing).length:0,
  code=num(s&&s.code),ep=s&&s.error_page===true,
  // An auth challenge (401/403) is the product refusing an anonymous read: "Up, sign-in required",
  // never an error page. Anything else at 400 or above, or a document the collector identified as
  // an error page, is Down. Up beside "Showing an error page" was the contradiction in
  // pixel-deck#35, where the Console's 10 ms proxy note was read as content.
  auth=code!=null&&(code===401||code===403),
  bad=code==null||ep||st=='down'||(code>=400&&!auth),
  label=bad?'Down':auth||st=='gated'?'Up, sign-in required':st=='up'?'Up':'Down',
  t=code==null?'No answer':bad?'Showing an error page':'Responding',
  // a failed connect has no response time; printing one would read as a fast answer
  lat=code!=null&&num(s&&s.ms)!=null?' \u00B7 '+fmt(s.ms,0,' ms'):'';
  return ptile(str(s&&s.name,30)||'Site',label,t+lat,
   m?fmt(m.ok)+' of '+fmt(m.checks)+' checks passing'+(fails?' \u00B7 failing: '+arr(m.failing).join(', '):''):auth||st=='gated'?'Private, needs sign-in':'',bad||fails?'bad':st?k:'stale',s&&s.url)}
 const SEV={high:'Now',med:'Soon',low:'Later'};
 // Legacy feeds have no owner field. A failed check alone is never an owner decision.
 const ownerDecision=x=>isObj(x)&&(x.owner?x.owner==='owner':
  (/^(app store connect|asc)$/i.test(x.source||'')&&/^(Answer App Review|Reply to App Review|Attach build)\b/.test(str(x.text,120)))||
  (x.source==='accounts.json'&&/^(Sign in|Reconnect)\b/.test(str(x.text,120))));
 const decisionDataComplete=p=>state(p)==='ok'&&Array.isArray(p.needs)&&!arr(p.errors).length;
// a list of rows sits in one .flist card; an empty state is the one .es component and never sits inside a card of its own
const flist=body=>/^<div class="es\b/.test(body)?body:'<div class="flist">'+body+'</div>';
// "Your decisions" (and Maintenance): every row has its own Open button. It only opens the page in a new tab; it never approves, sends or changes anything.
// A row with no page says so instead of showing a dead button. A due date shows exactly (`due` or `deadline`: epoch or YYYY-MM-DD); a deadline text that only says
// "about" or "confirm date" is tagged for an owner check. No producer in this repo writes `due` yet [INFERENCE]: the tag keeps such a row honest until one does.
const DUE_TZ='America/Los_Angeles',DUE_WORDS=/\b(deadline|due|expires?|expired|expiry|redemption|redeem|renew(?:al)?)\b/i,DUE_FUZZY=/\b(about|around|approx(?:imately)?|roughly|est\.?)\b|confirm(?:\s+the)?\s+date/i;
function dueTag(x){if(!isObj(x))return null;const raw=x.due!=null?x.due:x.deadline;
 if(typeof raw==='string'&&/^\d{4}-\d{2}-\d{2}$/.test(raw)){const d=new Date(raw+'T00:00:00Z');if(isFinite(d))return {k:'exact',text:'Due '+d.toLocaleDateString('en-US',{year:'numeric',month:'short',day:'numeric',timeZone:'UTC'})}}
 const e=toEpoch(raw);if(e!=null&&e>1.5e9)return {k:'exact',text:'Due '+new Date(e*1000).toLocaleDateString('en-US',{year:'numeric',month:'short',day:'numeric',timeZone:DUE_TZ})};
 const words=str(x.text,120)+' '+str(x.why,160)+' '+str(x.due_note,80);
 return DUE_WORDS.test(words)&&DUE_FUZZY.test(words)?{k:'check',text:'Owner check: confirm date'}:null}
function decisionRow(x,maint){const sv=['high','med','low'].includes(x.sev)?x.sev:'low',u=safeUrl(x.url),due=dueTag(x),name=str(x.text,90);
 const sub=[redact(str(x.why,120)),friendly(str(x.source,40))].filter(Boolean).join(' \u00B7 ');
 const open=x.noOpen===true?'':u?'<a class="b open" href="'+esc(u)+'" target="_blank" rel="noopener noreferrer" aria-label="'+esc('Open '+name+' in a new tab')+'">Open</a>':'<small class="nolink">No page to open</small>';
 const tag=maint?'<small>Maintenance</small>':'<span class="pill sv-'+sv+'">'+SD(sv=='high'?'bad':sv=='med'?'warn':'ok')+SEV[sv]+'</span>';
 return '<div class="frow'+(maint?(x.sev==='high'?' need sv-high':''):' need sv-'+sv)+'"><span class="fl"><b>'+esc(name)+'</b>'+(sub?'<small>'+esc(sub)+'</small>':'')+
  (due?'<small class="due"><span class="pill'+(due.k==='check'?' warn':'')+'">'+esc(due.text)+'</span></small>':'')+'</span><span class="fr">'+tag+open+'</span></div>'}
 // extra = rows from other feeds (renewals, deadlines, TestFlight): with extras the list is sorted Now, Soon, Later (stable, owner decisions first); without them the feed order stays
 const SEV_RANK={high:0,med:1,low:2};
 function needRows(p,limit,where,extra){const ns=arr(isObj(p)&&p.needs).filter(ownerDecision),ex=arr(extra).filter(isObj),n=limit||6;
  if(!ns.length&&!ex.length)return decisionDataComplete(p)?empty({title:'Nothing needs you',line:'Every source reported in.'}):empty({k:'stale',title:'Some decisions may be missing',line:'A source is out of date or not reporting.'});
  const all=ex.length?ns.concat(ex).map((x,i)=>({x,i,r:SEV_RANK[x.sev]==null?2:SEV_RANK[x.sev]})).sort((a,b)=>a.r-b.r||a.i-b.i).map(o=>o.x):ns;
  return all.slice(0,n).map(x=>decisionRow(x,false)).join('')+
   (all.length>n?'<div class="frow"><span class="fl"><small>'+(all.length-n)+' more'+(where?' '+esc(where):'')+'</small></span></div>':'')}
 function maintenanceRows(p,limit){const ns=arr(isObj(p)&&p.needs).filter(isObj).filter(x=>!ownerDecision(x)),n=limit||6;
  if(!ns.length)return decisionDataComplete(p)?none('No maintenance problems','Everything that was checked is fine.'):none('Maintenance data is incomplete','A source is out of date or not reporting.');
  return ns.slice(0,n).map(x=>decisionRow(x,true)).join('')+
   (ns.length>n?row((ns.length-n)+' more maintenance items','Open Dev or Fleet for details','',''):'')}
// ---- House: car, Apple Watch and printer ink. An empty card never stands alone: it says why, when it was last seen and the one next step (no invented values). ----
function emptyFacts(o){o=isObj(o)?o:{};const k=o.k==='bad'||o.k==='stale'?o.k:'idle';
 return '<div class="es es-'+k+'" role="status">'+ES_ICON[k]+'<b class="es-t">'+esc(str(o.title,80)||'Nothing here yet')+'</b>'+
  [['Why',o.cause],['Last seen',o.last],['Next step',o.step]].filter(x=>str(x[1],240)).map(x=>'<span class="es-l"><b class="es-w">'+x[0]+':</b> '+esc(str(x[1],240))+'</span>').join('')+
  (str(o.how,300)?'<span class="es-l how">'+esc(str(o.how,300))+'</span>':'')+diagHtml(o.diag)+'</div>'}
// the car's own reading time is `seen` (generatedAt minus ageSeconds in car.json, worked out by the server); the file time says only when the poller last ran.
// Values from a car that has not answered recently carry a Cached badge, never "Updated N min ago".
function carCard(c,now){
 if(!isObj(c))return tile('Car','Not reporting','The deck did not answer. It tries again on its own.','bad');
 if(c.error){const p=problem(c);return emptyFacts({k:'bad',title:'Car is not reporting',cause:p.line,last:'No car reading has reached the deck yet',step:'Sign the car account in again if this keeps happening.',diag:p.diag})}
 const ch=/charg/i.test(c.charging||'')&&!/dis/i.test(c.charging||''),b=num(c.battery),lim=num(c.charge_limit),seen=toEpoch(c.seen),cached=c.fresh===false||c.stale===true;
 const plug=ch?'Charging':/^disconnected$/i.test(c.charging||'')?'Cable not connected':(str(c.charging,24)||'Charge unknown');
 const asleep=/^(offline|asleep)$/i.test(c.awake||'')?'The car is '+String(c.awake).toLowerCase()+'. ':'';
 return '<div class="tile car'+(cached?' stale':'')+'"><div class="h">'+SD(cached?'warn':'ok')+'Car'+(cached?' <span class="pill warn">Cached</span>':'')+'</div><div class="cr"><b>'+(b!=null?Math.round(b)+'%':'--')+'</b><div class="bar"><i style="width:'+(b||0)+'%"></i>'+(lim!=null?'<u style="left:'+lim+'%"></u>':'')+'</div><span>'+(num(c.range)!=null?Math.round(c.range)+' mi':'')+'</span></div>'+
  '<div class="t">'+esc(plug)+(lim!=null?' \u00B7 limit '+Math.round(lim)+'%':'')+' \u00B7 '+(c.locked==null?'lock unknown':c.locked===true?'Locked':'Unlocked')+'</div>'+
  '<div class="t">'+esc(seen==null?'Last seen time unknown':'Last seen '+ago(seen,now))+'</div>'+
  (cached?'<div class="t">'+esc(asleep+'These values are from the last time the car answered.')+'</div>':'')+
  (c.stale===true&&toEpoch(c.t)!=null?'<div class="t">'+esc('The car check last ran '+ago(c.t,now)+'.')+'</div>':'')+'</div>'}
// Apple Watch: BLE only proves the watch is near the Mac mini. Health numbers arrive from the iPhone Health app through Home Assistant (skill apple-watch-bridge-ops).
const WATCH_HOW='How to connect: the watch link only shows it is near. Heart rate, HRV and sleep come from the iPhone Health app through Home Assistant, and the deck reads them from the watch status file every hour.';
// why, last seen and the next step for an Apple Watch that has no readings (or no file). One source for the House card and the Today tile.
function watchFacts(w,now){
 if(!isObj(w)||w.error){const missing=isObj(w)&&w.error==='file missing';
  return {k:'bad',cause:missing?'There is no watch status file yet.':'The watch feed did not answer.',last:missing?'The watch has never reported':'Not known',step:'Check that the Apple Watch bridge timer is running, then wait for the next hourly check.'}}
 const t=toEpoch(w.t),mt=toEpoch(w.metrics_t),near=w.near===true?'Watch near the Mac mini':w.near===false?'Watch not near the Mac mini':'Watch link',
  link=near+(w.connected===false?', not connected':'')+(t==null?'':', checked '+ago(t,now));
 return {k:'idle',cause:str(w.reason,160)||(mt==null?'No health reading has reached the deck yet.':'The last health sync had no values.'),
  last:link+' \u00B7 '+(mt==null?'no reading yet':'last reading '+ago(mt,now)),step:'Open Home Assistant on the iPhone and allow Health access. Readings show up after the next hourly check.'}}
// D9: a payload with no reading at all and no link to the Mac mini is ONE statement of the reason, never a row of empty values
const watchUnlinked=w=>isObj(w)&&!w.error&&w.near===false&&w.connected===false&&['hr','hrv','sleep_h','battery'].every(k=>num(w[k])==null);
function watchEmpty(w,now,title){const f=watchFacts(w,now);
 if(!isObj(w)||w.error)return emptyFacts({k:'bad',title:'Apple Watch is not reporting',cause:f.cause,last:f.last,step:f.step,how:WATCH_HOW,diag:[isObj(w)?str(w.error,80):'no answer from the deck server','status file: watch.json']});
 return emptyFacts({k:'idle',title:watchUnlinked(w)&&!str(w.reason,160)?'Apple Watch is not linked to the Mac mini':str(title,80)||'No health readings yet',cause:f.cause,last:f.last,step:f.step,how:WATCH_HOW,diag:['status file: watch.json']})}
// printer ink: a missing value says why, when Home Assistant last changed it and what to do
function inkTile(l,s,now){const p=s&&!isNaN(+s.state)&&s.state!==''&&s.state!=null?+s.state:null,low=p!=null&&p<20,t=s&&s.updated!=null?toEpoch(s.updated):null;
 if(p==null&&s&&s.state==='unavailable')return '<div class="tile stale"><div class="h">'+SD('warn')+esc(l)+' ink</div><div class="v">Printer offline</div>'+
  '<div class="t">'+esc(t!=null?'Last seen '+ago(t,now):'Never seen')+'</div><div class="t">Next step: turn the printer on and wait for the next refresh.</div></div>';
 if(p==null)return '<div class="tile stale"><div class="h">'+SD('warn')+esc(l)+' ink</div><div class="v">No reading</div>'+
  '<div class="t">'+esc(s?'Home Assistant has no value for this cartridge. The printer is usually off or asleep.':'Home Assistant has no sensor for this cartridge.')+'</div>'+
  '<div class="t">'+esc(t!=null?'Last changed '+ago(t,now):'Never seen')+'</div><div class="t">Next step: turn the printer on and wait for the next refresh.</div></div>';
 return '<div class="tile'+(low?' bad':'')+'"><div class="h">'+SD(low?'bad':'ok')+esc(l)+' ink</div><div class="v">'+p+'%'+(low?' Low':'')+'</div><div class="bar"><i style="width:'+Math.max(0,Math.min(100,p))+'%"></i></div><div class="t">'+esc(t!=null?'Updated '+ago(t,now):'')+'</div></div>'}
 function products(p,now){
  if(state(p)=='bad')return {grid:down('Products',p,'home'),needs:'',src:'Not reporting',count:'--'};
  const k=state(p);
  return {grid:appTiles(p,k,now)+arr(p.products).filter(isObj).map(s=>siteTile(s,k)).join(''),needs:flist(needRows(p,6)),maintenance:sec('Maintenance',p,now,maintenanceRows(p)+errRows(p)),src:line(p,now),count:decisionDataComplete(p)?String(arr(p.needs).filter(ownerDecision).length):'--'}}

 // ---- today (v7): one compact section per source, each with its own source and age ----
// ---- today: the top strip. Only what needs Tanner now, each with a one-line cause; everything else stays calm ----
 // W5: the strip keeps its last good read (closure state, no DOM). ctx = {failed, missing}: a failed refresh keeps the old rows marked out of date and
 // never reads "all clear"; sections that did not report are named, never counted as clean.
 let attGood=null;
 function attention(items,now,ctx){
  const c=isObj(ctx)?ctx:{},failed=c.failed===true,missing=arr(c.missing).map(n=>str(n,40)).filter(Boolean).filter((n,i,a)=>a.indexOf(n)===i);
  const read=arr(items).filter(isObj).map(x=>({k:x.k==='bad'?'bad':'warn',text:str(x.text,90),why:str(x.why,130)}));
  if(!failed)attGood={xs:read,at:now};
  const xs=failed&&attGood?attGood.xs:read,bad=xs.filter(x=>x.k==='bad').length,last=failed&&attGood?'last read '+ago(attGood.at,now):'';
  const one=(k,t,w)=>'<div class="frow attnrow'+(k==='bad'?' sev-high':'')+'">'+SD(k==='bad'?'bad':'warn')+'<span class="fl"><b>'+esc(t)+'</b>'+(w?'<small>'+esc(w)+'</small>':'')+'</span></div>';
  let body='';
  if(failed)body+=one('warn','Could not refresh',attGood?'Out of date \u00B7 '+last+(xs.length?'. These rows may have changed.':', when nothing needed you. That may have changed.'):'Nothing has been read yet, so nothing is shown as clear.');
  body+=xs.map(x=>one(x.k,x.text,x.why)).join('');
  if(!failed&&missing.length)body+=one('warn','Some checks did not report',missing.slice(0,5).join(', ')+(missing.length>5?' and '+(missing.length-5)+' more':''));
  if(!body)body='<div class="frow attnrow ok">'+SD('ok')+'<span class="fl"><b>Nothing needs you</b><small>gateway, mail, crons, cluster, feeds and calendar all read clean</small></span></div>';
  const right=failed?'Out of date'+(last?' \u00B7 '+last:''):xs.length?xs.length+(bad?' \u00B7 '+bad+' urgent':'')+(missing.length?' \u00B7 checks missing':''):missing.length?'some checks missing':'all clear';
  return '<div class="secttl"><span>Needs you</span><span>'+esc(right)+'</span></div><div class="flist attnl">'+body+'</div>'}
 const sec=(title,f,now,body)=>'<section class="tsec">'+head(title,f,now)+body+'</section>';
 const none=(title,line)=>empty({k:'idle',title,line});
 function tNeeds(p,now,extra){const ex=arr(extra).filter(isObj);
  if(state(p)=='bad')return sec('Your decisions',p,now,down('Products',p,'today')+(ex.length?flist(needRows(null,6,'',ex)):''));
  return sec('Your decisions',p,now,flist(needRows(p,ex.length?6:3,'on Home',ex)))}
 function tMaintenance(p,now){if(state(p)=='bad')return sec('Maintenance and waiting',p,now,down('Products',p,'today'));
  return sec('Maintenance and waiting',p,now,appTiles(p,state(p),now)+flist(maintenanceRows(p,3))+errRows(p))}
// ---- 2026-10-29: Renewals and deadlines (GET /api/deadlines) and App builds (GET /api/testflight). Read only, no amounts, no evidence. A key a feed
// does not carry is "not reported", never a number. Rows go to the Today lists and, when they need a person, to Your decisions. ----
const DL_WINDOW=60,DL_NOW=7,DL_SOON=30,DL_LIST=12;
const DL_SOURCE={subsradar:'Subscription renewals',renewals:'Subscription renewals',paperwork:'Paperwork deadlines'};
const dlDay=raw=>{const m=/^(\d{4})-(\d{2})-(\d{2})/.exec(str(raw,20));if(!m)return '';const d=new Date(Date.UTC(+m[1],+m[2]-1,+m[3]));return isFinite(d)?d.toLocaleDateString('en-US',{month:'short',day:'numeric',timeZone:'UTC'}):''};
const dlSev=days=>days<=DL_NOW?'high':days<=DL_SOON?'med':'low';
const dlWhen=days=>days<0?'Expired '+(-days)+(days===-1?' day ago':' days ago'):days===0?'Today':days===1?'Tomorrow':'In '+days+' days';
// merged renewals and paperwork, expired first then by days, next DL_WINDOW days; the same vendor and date from both sources is one row
function dlItems(d){const out=[],seen=new Set(),add=x=>{const k=x.name.toLowerCase()+'|'+x.date;if(!seen.has(k)){seen.add(k);out.push(x)}};
 arr(isObj(d)&&d.paperwork).filter(isObj).forEach(p=>{const days=num(p.days_left);if(days==null||days>DL_WINDOW)return;
  add({src:'paperwork',name:str(p.thing,60)||friendly(str(p.kind,30))||'Paperwork',date:str(p.date,10),days,what:friendly(str(p.kind,30))||'Deadline'})});
 arr(isObj(d)&&d.renewals).filter(isObj).forEach(r=>{const days=num(r.days);if(days==null||days>DL_WINDOW)return;
  add({src:'renewal',name:str(r.vendor,60)||'Renewal',date:str(r.date,10),days,what:'Renews'})});
 return out.sort((a,b)=>a.days-b.days||a.name.localeCompare(b.name))}
// Your decisions: only what needs a hand now, expired or 7 days or less, three at most (soonest first). The Soon rows (30 days or less) stay in the
// Renewals and deadlines section, which carries the whole list. No Open button: there is no page to open.
function dlNeeds(d){return dlItems(d).filter(x=>x.days<=DL_NOW).slice(0,3).map(x=>({noOpen:true,sev:'high',source:x.src==='paperwork'?'paperwork':'subscriptions',due:x.date,why:x.what,
  text:x.name+' '+(x.src==='paperwork'?(x.days<0?'expired '+(-x.days)+' d ago':x.days===0?'is due today':'is due in '+x.days+' d'):(x.days<0?'renewal passed '+(-x.days)+' d ago':x.days===0?'renews today':'renews in '+x.days+' d'))}))}
function dlRow(x){const sv=dlSev(x.days),date=dlDay(x.date);
 return '<div class="frow need sv-'+sv+'"><span class="fl"><b>'+esc(x.name)+'</b><small>'+esc(x.what+(date?' \u00B7 '+date:''))+'</small></span><span class="fr"><span class="pill sv-'+sv+'">'+SD(sv=='high'?'bad':sv=='med'?'warn':'ok')+SEV[sv]+'</span><b>'+esc(dlWhen(x.days))+'</b></span></div>'}
// each failed source is its own diamond row with its reason; the other source keeps its rows
const dlErrRows=d=>arr(isObj(d)&&d.errors).filter(isObj).slice(0,6).map(e=>{const s=str(e.source,30).toLowerCase();
 return '<div class="frow err"><i class="sd bad"></i><span class="fl"><b>'+esc((DL_SOURCE[s]||friendly(s)||'A source')+' did not report')+'</b><small>'+esc(redact(str(e.reason,120))||'No reason given')+'</small></span></div>'}).join('');
function tDeadlines(d,now){const title='Renewals and deadlines';
 if(state(d)=='bad')return sec(title,d,now,down('Deadlines',d,'today'));
 const items=dlItems(d),errs=dlErrRows(d);
 return sec(title,d,now,(items.length?'<div class="flist">'+items.slice(0,DL_LIST).map(dlRow).join('')+(items.length>DL_LIST?'<div class="frow"><span class="fl"><small>'+(items.length-DL_LIST)+' more in the next '+DL_WINDOW+' days</small></span></div>':'')+'</div>':
  errs?'':none('Nothing due soon','No renewals or deadlines in the next '+DL_WINDOW+' days.'))+(errs?'<div class="flist">'+errs+'</div>':''))}
const TF_BAD=['UNRESOLVED_ISSUES','REJECTED','DEVELOPER_REJECTED'];
const TF_ORDER=['IN_REVIEW','WAITING_FOR_REVIEW','PENDING_DEVELOPER_RELEASE','READY_FOR_REVIEW','PREPARE_FOR_SUBMISSION','READY_FOR_SALE','COMPLETE'];
const upFirst=s=>s.charAt(0).toUpperCase()+s.slice(1);
// the one state word of an app: App Review trouble first, then a build that is not usable, then the furthest version state
function tfState(a){const b=isObj(a&&a.latest_build)?a.latest_build:null,vs=arr(a&&a.versions).filter(isObj).reduce((o,v)=>o.concat(str(v.submission_state,40),str(v.state,40)),[]).filter(Boolean),ps=str(b&&b.processing_state,24);
 const issue=TF_BAD.find(s=>vs.includes(s));
 if(issue)return {k:'bad',word:upFirst(ascWord(issue)),issue};
 if(ps&&ps!=='VALID')return {k:ps==='PROCESSING'?'warn':'bad',word:upFirst(ascWord(ps)),issue:''};
 if(b&&b.expired===true)return {k:'warn',word:'Build expired',issue:''};
 const top=TF_ORDER.find(s=>vs.includes(s));
 return {k:'',word:top?upFirst(ascWord(top)):b?'In testing':'No build',issue:''}}
const tfLink=a=>/^\d{6,12}$/.test(str(a&&a.id,20))?'https://appstoreconnect.apple.com/apps/'+str(a.id,20)+'/testflight/ios':'';
function tfRow(a,now){const b=isObj(a.latest_build)?a.latest_build:null,fb=isObj(a.feedback)?a.feedback:{},st=tfState(a);
 const ver=str(b&&b.version,16),bn=str(b&&b.number,10),up=b&&b.uploaded_at!=null?ago(b.uploaded_at,now):'';
 const l1=b?[ver?'Version '+ver:'',bn?'build '+bn:'',up?'uploaded '+up:''].filter(Boolean).join(' \u00B7 ')||'Build details not reported':'No build uploaded yet';
 const cr=num(fb.crashes_count),sc=num(fb.screenshots_count),
  l2=[cr==null?'crashes not reported':cr+(cr===1?' crash':' crashes'),sc==null?'screenshots not reported':sc+(sc===1?' screenshot':' screenshots'),toEpoch(fb.last_received_at)==null?'no feedback yet':'feedback '+ago(fb.last_received_at,now)].join(' \u00B7 ');
 return row(str(a.name,40)||'App',l1,'<span class="pill'+(st.k?' '+st.k:'')+'">'+(st.k?SD(st.k==='bad'?'bad':'warn'):'')+esc(st.word)+'</span>',st.k==='bad'?'bad':'',tfLink(a),'','','<small>'+esc(l2)+'</small>')}
const tfErrRow=a=>'<div class="frow err"><i class="sd bad"></i><span class="fl"><b>'+esc(str(a.name,40)||'App')+'</b><small>'+esc(redact(str(a.error,120))||'App Store Connect did not answer')+'</small></span></div>';
// Fleet > Dev: one row per app; an app that could not be read is a diamond row with the reason
function appBuilds(f,now){const title='App builds';
 if(state(f)=='bad')return head(title,f,now)+down('App builds',f,'dev');
 const apps=arr(f.apps).filter(isObj).slice(0,24).map((a,i)=>({a,i,k:(()=>{try{return a.error?'bad':tfState(a).k}catch(e){return ''}})()}))
  .sort((x,y)=>(x.k==='bad'?0:x.k==='warn'?1:2)-(y.k==='bad'?0:y.k==='warn'?1:2)||x.i-y.i).map(o=>o.a);
 if(!apps.length)return head(title,f,now)+empty({k:'idle',title:'No apps listed',line:'App Store Connect has not reported an app yet.'})+errRows(f);
 return '<div class="secttl"><span>'+title+'</span><span>'+apps.length+(apps.length===1?' app':' apps')+' \u00B7 '+esc(line(f,now))+'</span></div><div class="flist">'+
  apps.map(a=>{try{return a.error?tfErrRow(a):tfRow(a,now)}catch(e){return tfErrRow({name:a&&a.name,error:'This app could not be shown'})}}).join('')+'</div>'+
  errRows({errors:arr(f.errors).filter(e=>isObj(e)&&!apps.some(a=>a.error&&str(a.name,60)===str(e.source,60)))})}
// App Review trouble is a Now row in Your decisions
function tfNeeds(f){return arr(isObj(f)&&f.apps).filter(isObj).filter(a=>!a.error&&tfState(a).issue).map(a=>{const st=tfState(a),b=isObj(a.latest_build)?a.latest_build:{},v=arr(a.versions).filter(isObj).find(x=>x.submission_state===st.issue||x.state===st.issue)||{};
  return {sev:'high',source:'testflight',url:tfLink(a).replace(/\/testflight\/ios$/,'/distribution'),text:(str(a.name,40)||'App')+(st.issue==='UNRESOLVED_ISSUES'?': App Review has open issues':': App Review rejected it'),
   why:[str(v.version,16)?'Version '+str(v.version,16):'',(str(v.build,10)||str(b.number,10))?'submitted build '+(str(v.build,10)||str(b.number,10)):''].filter(Boolean).join(' \u00B7 ')}})}
const todayExtras=(dl,tf)=>dlNeeds(dl).concat(tfNeeds(tf));
 function tCluster(c,now,pf){if(state(c)=='bad')return sec('Cluster',c,now,down('Cluster',c,'today'));
  const e=isObj(c.engine)?c.engine:{},b=isObj(c.bench)?c.bench:{},p=isObj(c.proxy)?c.proxy:{},st=str(e.status,12)||'unknown',k=state(c);
  return sec('Cluster',c,now,'<div class="mgrid g2">'+mini('Engine',{up:'Running',loading:'Loading',down:'Down'}[st]||'Status unknown',str(e.served_name,40)||'Model unknown',st=='up'?k:st=='loading'?'stale':'bad')+
   (b.stale===true?mini('Speed','Not current',staleBench(b,e),'stale'):mini('Speed',fmt(b.prose_tps,1)+' tok/s','Coding '+fmt(b.code_tps,1)+' \u00B7 6 at once '+fmt(b.conc6_tps,1),b.prose_tps==null?'stale':k))+
   (b.stale===true?mini('Prompt speed','Not current','Last bench '+(str(b.measured_at,12)||'unknown date'),'stale'):mini('Prompt speed',fmt(b.prefill_tps,0)+' tok/s','Measured '+(b.at==null?'at an unknown time':/^\d{4}-\d{2}-\d{2}$/.test(String(b.at))?String(b.at):ago(b.at,now)),b.prefill_tps==null?'stale':k))+
   mini('Proxy',p.pc_desktop_8080_up===true?'Up':p.pc_desktop_8080_up===false?'Down':'--',arr(p.models).length+(arr(p.models).length===1?' model':' models'),p.pc_desktop_8080_up===true?k:p.pc_desktop_8080_up===false?'bad':'stale',['Port 8080 on pc-desktop'])+'</div>'+
   (state(pf)!='bad'?(()=>{if(retiredOn(pf))return '<div class="flist">'+row('Tuning \u00B7 retired','Moved to Cluster Improve','','','')+'</div>';
    const rt=isObj(pf.runs_today)?pf.runs_today:{},lr=isObj(pf.last_result)?pf.last_result:null,ax=isObj(pf.active_experiment)?pf.active_experiment:null;
    return '<div class="flist">'+row('Tuning \u00B7 '+(pf.stop===true?'stopped':pf.enabled===true?'running':'off'),fmt(rt.total)+' runs today \u00B7 '+(ax?'now '+(str(ax.title,50)||'an experiment'):lr?'last '+(sentence(str(lr.outcome,20)).toLowerCase()||'unknown'):'no result yet'),
     '<small>'+esc(ago(pf.last_tick,now))+'</small>','','')+'</div>'})():''))}
 function evTime(e){if(e.all_day===true)return 'All day';const s=toEpoch(e.start),en=toEpoch(e.end),f=t=>new Date(t*1000).toLocaleTimeString([],{hour:'numeric',minute:'2-digit'});
  return s==null?'--':f(s)+(en!=null?' to '+f(en):'')}
 function calSec(a,now){if(state(a)=='bad')return sec('Calendar today',a,now,down('Calendar',a,'today'));
  const ap=isObj(a.apple)?a.apple:{},ev=ap.events_today;
  if(!Array.isArray(ev))return sec('Calendar today',a,now,empty({k:'stale',title:'Calendar is not reporting',line:ap.mini_reachable===false?'The Mac mini is not reachable.':'Events were left out of the last update.',retry:'today'}));
  return sec('Calendar today',a,now,(ev.length?'<div class="flist">'+ev.filter(isObj).map(e=>row(str(e.title,80)||'Event',str(e.calendar,40),'<b>'+esc(evTime(e))+'</b>','','')).join('')+'</div>':none('Nothing scheduled','Your calendar is clear today.')))}
 // Bill names and dates only, from the Finances calendar; the feed strips dollar amounts. Days away come from the
 // phone's own local date so the list stays right across midnight until the next feed refresh.
 function dueWhen(due,now){const m=/^(\d{4})-(\d{2})-(\d{2})$/.exec(String(due));if(!m)return null;
  const d=new Date(+m[1],+m[2]-1,+m[3]),t=new Date(now),days=Math.round((d-new Date(t.getFullYear(),t.getMonth(),t.getDate()))/864e5);
  if(isNaN(days))return null;
  return {days,label:days<0?'Overdue':days===0?'Today':days===1?'Tomorrow':d.toLocaleDateString([],{weekday:'short',month:'short',day:'numeric'})}}
 function dueSec(a,now){if(state(a)=='bad')return '';
  const ap=isObj(a.apple)?a.apple:{},b=ap.bills_due;
  if(!Array.isArray(b))return sec('Due soon',a,now,empty({k:'stale',title:'Bills are not reporting',line:ap.mini_reachable===false?'The Mac mini is not reachable.':'The bills list was left out of the last update.',retry:'today'}));
  const rows=b.filter(isObj).map(x=>({t:str(x.title,80)||'bill',w:dueWhen(x.due,now)})).filter(x=>x.w).sort((p,q)=>p.w.days-q.w.days);
  const more=num(ap.bills_more)>0?'<div class="frow"><span class="fl"><small>'+num(ap.bills_more)+' more in the next 2 weeks</small></span></div>':'';
  return sec('Due soon',a,now,rows.length?'<div class="flist">'+rows.map(x=>row(x.t,x.w.days>1?'In '+x.w.days+' days':'Bill',
   '<b>'+esc(x.w.label)+'</b>',x.w.days<=0?'need sv-high':x.w.days<=2?'need sv-med':'','')).join('')+more+'</div>':none('Nothing due','No bills in the next 2 weeks.'))}
 function tCal(a,now){return calSec(a,now)+dueSec(a,now)}
 // a tile keeps its short line; the full story (why, last seen, next step) rides in hidden detail lines the tap sheet shows
 const withMore=(tileHtml,lines)=>{const i=tileHtml.lastIndexOf('</div>');return i<0?tileHtml+MORE(lines):tileHtml.slice(0,i)+MORE(lines)+tileHtml.slice(i)};
 function tHome(car,ha,cams,watch,now){now=now==null?Date.now():now;
  const e=isObj(ha)&&isObj(ha.entities)&&!ha.error?ha.entities:null,st=id=>e&&isObj(e[id])?e[id]:null;
  const val=s=>{if(!s)return 'No reading';const v=s.state;if(v==null||v==='unavailable'||v==='unknown')return 'No reading';const n=Number(v);
   return isFinite(n)&&v!==''?String(Math.round(n))+(s.unit==='%'?'%':s.unit?' '+s.unit:''):String(v).replace(/[-_]+/g,' ')};
  let carT;
  if(!isObj(car)||car.error)carT=withMore(mini('Car','No reading','Not reporting','bad',[isObj(car)&&str(car.error,60)||'no answer from the deck server']),['Why: the car reading did not reach the deck.','Last seen: no car reading has reached the deck yet.','Next step: sign the car account in again if this keeps happening.']);
  else{const ch=/charg/i.test(car.charging||'')&&!/dis/i.test(car.charging||''),cached=car.fresh===false||car.stale===true,seen=toEpoch(car.seen);
   // the car's own reading time (car.json ageSeconds), never the file time: a cached value says so and says when the car last answered
   carT=withMore(mini(cached?'Car battery \u00B7 cached':'Car battery',fmt(car.battery,0,'%'),fmt(car.range,0,' mi')+' \u00B7 '+(ch?'charging':car.locked===true?'locked':car.locked===false?'unlocked':'lock unknown')+' \u00B7 '+(seen==null?'last seen unknown':'seen '+ago(seen,now)),car.locked===false?'bad':cached?'stale':'ok'),
    [seen==null?'Last seen time unknown':'Last seen '+ago(seen,now),cached?'These values are from the last time the car answered.':'']);}
  const cs=isObj(cams)&&Array.isArray(cams.cams)?cams.cams:null,ready=cs?cs.filter(x=>x&&x.ready).length:null;
  const INK=['sensor.hp_envy_6400_series_black_cartridge','sensor.hp_envy_6400_series_tri_color_cartridge'];
  const ink=INK.map(st).map(s=>s&&s.state!==''&&isFinite(Number(s.state))?Math.round(Number(s.state)):null).filter(x=>x!=null),low=ink.some(x=>x<20);
  const inkSeen=Math.max(0,...INK.map(st).filter(Boolean).map(s=>toEpoch(s.updated)||0));
  const w=st('weather.forecast_home'),bed=st('media_player.main_bedroom'),hk=e?'ok':'bad';
  let watchT;
  if(!isObj(watch)||watch.error){const f=watchFacts(watch,now);
   watchT=withMore(mini('Apple Watch','No reading',isObj(watch)&&watch.error==='file missing'?'No watch file yet. Check the watch bridge.':'Not reporting. Check the watch bridge.',isObj(watch)&&watch.error==='file missing'?'stale':'bad',[isObj(watch)&&str(watch.error,60)||'no watch file']),['Why: '+f.cause,'Last seen: '+f.last,'Next step: '+f.step,WATCH_HOW])}
  else{const hr=num(watch.hr),bat=num(watch.battery),f=watchFacts(watch,now),bare=hr==null&&bat==null;
   watchT=withMore(mini('Apple Watch',watchUnlinked(watch)?'Not linked':watch.connected===true?'Connected':watch.connected===false?'Not connected':'No reading',(hr==null?(watchUnlinked(watch)?'Not linked to the Mac mini, so there are no readings.':bare?'No health readings yet. Open Home Assistant on the iPhone.':'Heart rate not reported'):Math.round(hr)+' bpm')+(bat==null?'':' \u00B7 battery '+Math.round(bat)+'%'),watch.stale?'stale':watch.connected===true?'ok':'stale',[str(watch.reason,80)].filter(Boolean)),
    bare?['Why: '+f.cause,'Last seen: '+f.last,'Next step: '+f.step,WATCH_HOW]:[])}
  const inkOff=INK.map(st).some(s=>s&&s.state==='unavailable');
  const inkT=ink.length?mini('Printer ink',ink.map(x=>x+'%').join(' / '),low?'Low':'Black and color',low?'bad':'ok'):
   withMore(mini('Printer ink',inkOff?'Printer offline':'No reading',inkOff?(inkSeen>0?'Last seen '+ago(inkSeen,now):'Never seen'):'Printer off or asleep. Turn it on to refresh.','stale'),['Why: Home Assistant has no value for the cartridges, usually because the printer is off or asleep.',inkSeen>0?'Last seen: Home Assistant last changed it '+ago(inkSeen,now):'Last seen: never seen','Next step: turn the printer on and wait for the next refresh.']);
  return '<section class="tsec"><div class="secttl"><span>Car and house</span><span>'+(e?'Connected':esc('Home is not reporting'))+'</span></div><div class="mgrid">'+carT+
   mini('Weather',val(w),'Forecast',hk,e?[]:[isObj(ha)&&ha.error?str(ha.error,60):'Home Assistant did not answer'])+mini('Cameras',ready==null?'No reading':ready+' of '+cs.length+' online',ready==null?'Not reporting':ready<cs.length?'Some are offline':'All online',ready==null?'bad':ready<cs.length?'stale':'ok')+
   mini('Bedroom',val(bed),'Speaker',hk)+inkT+
   watchT+'</div></section>'}
 function tSurf(s,now){if(state(s)=='bad')return sec('Surf',s,now,down('Surf feed',s));
  const tide=isObj(s.tide)?s.tide:{},gs=surfGroups(s.spots).slice().sort((a,b)=>(a.x.role==='reference')-(b.x.role==='reference')||(num(b.x.wave_ft_max)||0)-(num(a.x.wave_ft_max)||0)).slice(0,3);
  const nx=arr(tide.next).filter(isObj).find(t=>(toEpoch(t.at)||0)>now/1000);
  const best=gs.map(g=>g.x).find(x=>isObj(x.best_window));
  return sec('Surf',s,now,'<div class="flist">'+gs.map(surfRow).join('')+
   (nx?row('Next '+(nx.type==='H'?'high':'low')+' tide',str(tide.station,30),'<b>'+esc(clock(nx.at).replace(/^\w+ /,''))+'</b><small>'+fmt(nx.ft,1,' ft')+'</small>','',''):'')+'</div>'+
   (best?'<div class="sh-form">'+esc(spotLabel(best))+' '+esc(str(best.best_window.label,32))+' \u00B7 '+esc(str(best.best_window.reason,90))+'</div>':'')+
   (isObj(tide.sun)&&str(tide.sun.sunrise_pt,20)?'<div class="sh-form">Sun '+esc(str(tide.sun.sunrise_pt,20))+' to '+esc(str(tide.sun.sunset_pt,20))+'</div>':''))}
 function tHockey(h,now){if(state(h)=='bad')return sec('Hockey',h,now,down('Hockey feed',h));
  const live=arr(h.live).filter(isObj).map(g=>row('LIVE '+str(g.away,6)+' @ '+str(g.home,6),'P'+fmt(g.period)+' \u00B7 '+str(g.clock,8),'<b>'+esc(str(g.score,12))+'</b><small>'+esc(str(g.home,6))+' first</small>','',hockeyLink(g)));
  const nx=arr(h.teams).filter(t=>isObj(t)&&isObj(t.next_game)).sort((a,b)=>(toEpoch(a.next_game.at)||9e12)-(toEpoch(b.next_game.at)||9e12)).slice(0,3).map(t=>{const n=t.next_game;
   return row((str(t.abbr,6)||str(t.name,20))+(n.home===false?' at ':' vs ')+(str(n.opp,6)||'--'),clock(n.at)+(str(n.time_pt,28)?' \u00B7 '+str(n.time_pt,28):'')+(str(n.tv,24)?' \u00B7 '+str(n.tv,24):''),'<b>'+esc(until(n.at,now))+'</b>'+(n.type==='pre'?'<small>preseason</small>':'')+(str(t.form,24)?'<small>form '+esc(str(t.form,24))+'</small>':''),'',hockeyLink(n))});
  return sec('Hockey',h,now,'<div class="flist">'+(live.join('')+nx.join('')||none('No games scheduled'))+'</div>')}
 function tJobs(j,now){if(state(j)=='bad')return sec('Jobs',j,now,down('Jobs feed',j));
  const ls=jobList(j).slice().sort((a,b)=>(toEpoch(b.posted_at)||0)-(toEpoch(a.posted_at)||0)||(num(b.score)||0)-(num(a.score)||0)).slice(0,4);
  return sec('Jobs \u00B7 newest',j,now,'<div class="flist">'+(ls.length?ls.map(x=>row(str(x.title,90)||'listing',[str(x.company,40),str(x.site,16),x.posted_at!=null?ago(x.posted_at,now):''].filter(Boolean).join(' \u00B7 '),
   '<b>'+fmt(x.score)+'</b><small>score</small>','',x.url,'','',jobCue(x))).join(''):none('No listings'))+'</div>')}
 function tHomes(r,now){if(state(r)=='bad')return sec('Homes',r,now,down('Real estate feed',r));
  const newest=xs=>xs.filter(isObj).map((x,i)=>({x,i})).sort((a,b)=>(toEpoch(b.x.listed_at)||0)-(toEpoch(a.x.listed_at)||0)||a.i-b.i).map(o=>o.x);
  const all=arr(r.homes).filter(isObj),call=arr(r.commercial).filter(isObj),hs=newest(all).slice(0,3),cs=newest(call).slice(0,2),
   // the card says which area it reads and what the five rows are a window on, so a short list never reads as the whole market
   area=(str(isObj(r.market)?r.market.area:'',80)||'').split('/').map(s=>s.trim()).filter(Boolean).join(', '),
   totals=[all.length?all.length+(all.length===1?' home':' homes'):'',call.length?call.length+' commercial':''].filter(Boolean);
  return sec('Homes and commercial',r,now,'<div class="flist">'+hs.map(x=>row(usd(x.price)+' \u00B7 '+(str(x.city,24)||'city unknown'),[fmt(x.beds)+' bd',fmt(x.baths,num(x.baths)%1?1:0)+' ba',fmt(x.sqft)+' sqft'].join(' \u00B7 '),
   '<small>'+esc(str(x.source,16))+(x.listed_at!=null?' \u00B7 '+esc(ago(x.listed_at,now)):'')+'</small>','',x.url)).join('')+
   cs.map(x=>row((str(x.type,20)||'Commercial')+' \u00B7 '+(str(x.city,24)||'city unknown'),[usd(x.price),fmt(x.sqft)+' sqft',x.cap_rate!=null?'cap '+fmt(x.cap_rate,1,'%'):''].filter(Boolean).join(' \u00B7 '),'<small>'+esc(str(x.source,16))+'</small>','',x.url)).join('')+
   (hs.length+cs.length?'':none('No listings'))+'</div>'+(area&&totals.length?'<div class="tnote">'+esc(area)+' \u00B7 '+esc(totals.join(' \u00B7 '))+'</div>':'')+housingSources(r,now,true))}

 const LANES=['CLAUDE','CODEX','NO MODEL','OTHER'];
 const laneOf=j=>{const l=str(j&&j.lane,12);return LANES.includes(l)?l:'OTHER'};
 const lanePill=l=>'<span class="pill lane l-'+l.toLowerCase().replace(/ /g,'')+'">'+esc(l)+'</span>';
 function cronRow(j,now,active){
  const lane=laneOf(j),ls=str(j&&j.last_status,24),last=j&&j.last_run_at,next=j&&j.next_run_at;
  const failed=ls!==''&&ls.toLowerCase()!=='ok',nextT=toEpoch(next);
  const lastTxt=last?(failed?'Last run failed ':'Last run OK ')+ago(last,now):'Never run';
  const nextTxt=active?(nextT==null?'Not scheduled':'Next '+until(next,now)):(nextT==null?'':'Was due '+clock(next));
  const model=[str(j&&j.provider,40),str(j&&j.model,60)].filter(Boolean).join(' / ')||'none pinned';
  const id8=cronId(j);
  return '<div'+(id8?dattr('cron',id8):'')+' class="frow cronrow'+(failed?' bad':'')+'"><span class="fl"><b>'+(failed?SD('bad'):'')+esc(str(j&&j.name,80)||'Unnamed job')+'</b><small>'+esc(schedule(j&&j.schedule_display))+'</small>'+
   '<small>'+esc(lastTxt+(nextTxt?' \u00B7 '+nextTxt:''))+'</small></span><span class="fr">'+lanePill(lane)+'</span>'+
   diagHtml([id8&&'ID '+id8,'Schedule '+(str(j&&j.schedule_display,48)||'unknown'),'Model '+model,ls&&'Last status '+ls].filter(Boolean))+'</div>'}
 function cronHead(title,n,f,now){const t=isObj(f)?(toEpoch(f.file_t)!=null?f.file_t:f.t):null;return '<div class="secttl"><span>'+esc(title)+' <b class="cnt">'+(n==null?'--':n)+'</b></span><span>'+esc(isObj(f)&&!f.error?'Updated '+ago(t,now):'Not reporting')+'</span></div>'}
 function crons(f,now){
  if(!isObj(f)||f.error)return [cronHead('Hermes crons',null,f,now)+down('Cron jobs',f,'crons'),'',''];
  const act=arr(f.active).filter(isObj),pau=arr(f.paused).filter(isObj),c=isObj(f.counts)?f.counts:{};
  // Every job parked by the owner is not a fault: name the stop and the mix, never "nothing is running".
  const ht=isObj(f.halt)&&f.halt.all_paused===true?f.halt:null,hc=ht&&isObj(ht.counts)?ht.counts:{},hwhen=ht&&toEpoch(ht.since)!=null?' on '+clock(ht.since):'';
  const hmix=[num(hc.removed)?hc.removed+' removed':'',num(hc.merged)?hc.merged+' merged':'',num(hc.stopped)?hc.stopped+' stopped':'',(num(hc.other)||num(hc.unknown))?(num(hc.other)+num(hc.unknown))+' other':''].filter(Boolean).join(', ');
  const haltLine=ht?'<div class="tnote halt">Everything is paused because you stopped it'+esc(hwhen)+'.'+(hmix?' '+esc(hmix)+'.':'')+' Turn one back on from its card when you want it running again.</div>':'';
  const lanes=LANES.map(l=>[l,act.filter(j=>laneOf(j)===l).length]).filter(x=>x[1]>0).map(x=>sentence(x[0])+' '+x[1]).join(' \u00B7 ');
  const sum=tile('Active jobs',fmt(c.active)+' of '+fmt(c.total),(lanes||(ht?'Stopped by you'+hwhen:'No active jobs'))+(num(c.last_failed)>0?' \u00B7 '+c.last_failed+' failed last time':''),num(c.last_failed)>0?'bad':'ok');
  const half=Math.ceil(pau.length/2);
  return ['<div class="secttl"><span>Hermes crons</span><span>Hermes jobs only, not every scheduler</span></div>'+cronHead('Active',num(c.active),f,now)+sum+(act.length?'<div class="flist">'+act.map(j=>cronRow(j,now,true)).join('')+'</div>':haltLine||none('No active jobs','Jobs you schedule show up here.')),
   cronHead('Paused',num(c.paused),f,now)+(pau.length?'<div class="flist">'+pau.slice(0,half).map(j=>cronRow(j,now,false)).join('')+'</div>':none('No paused jobs','Everything is running.')),
   pau.length>1?'<div class="secttl"><span>Paused (continued)</span><span>Tap a job for details</span></div><div class="flist">'+pau.slice(half).map(j=>cronRow(j,now,false)).join('')+'</div>':'']}

 // ---- v8: Fleet board (GET /api/fleet-board). Every card says how fresh it is; missing data says so and is never shown as zero ----
 const gbs=v=>{const n=num(v);if(n==null)return '--';return n>=1000?(n/1000).toFixed(2)+' TB':Math.round(n)+' GB'};
 const bsrc=(f,now)=>{if(!isObj(f)||f.error)return 'Not reporting';return (f.stale?'Out of date \u00B7 ':'')+(toEpoch(f.t)==null?'Update time unknown':'Updated '+ago(f.t,now))};
 const bhead=(title,f,now)=>'<div class="secttl"><span>'+esc(title)+'</span><span>'+esc(bsrc(f,now))+'</span></div>';
 const bdown=(title,f,retry)=>down(title,f,retry||'fleet');
 const bstate=f=>!isObj(f)||f.error?'bad':f.stale?'stale':'ok';
 function bMachines(f,now){
  if(state(f)=='bad')return bhead('Machines',f,now)+bdown('Machines',f);
  const k=bstate(f);
  return bhead('Machines',f,now)+'<div class="mach">'+arr(f.items).filter(isObj).map(m=>{
   const up=m.reachable;if(up==null)return '<div class="tile node stale"><div class="h">'+SD('warn')+esc(str(m.name,20))+'</div><div class="v">No data</div><div class="t">This machine was left out of the last snapshot.</div></div>';
   const mk=up===false?'bad':k;
   const drv=arr(m.drives).filter(isObj).map(d=>{const p=num(d.pct);return '<div class="bar'+(p!=null&&p>=90?' hot':'')+'"><i style="width:'+(p==null?0:Math.min(100,p))+'%"></i></div><div class="t">'+esc(str(d.label,20)||'Disk')+' \u00B7 '+gbs(d.used_gb)+' used \u00B7 '+gbs(d.free_gb)+' free'+(p==null?'':' \u00B7 '+p+'%')+'</div>'}).join('');
   return '<div class="tile node'+(mk=='bad'?' bad':mk=='stale'?' stale':'')+'"><div class="h">'+SD(mk=='stale'?'warn':mk)+esc(str(m.name,20))+'</div><div class="v">'+(up===true?'Reachable':'Not reachable')+'</div>'+
    (up===true?(drv||'<div class="t">No disks listed</div>'):'<div class="t">Could not be reached, so disk sizes are unknown.</div>')+'</div>'}).join('')+'</div>'}
 function bCluster(c,now){
  if(!isObj(c))return bhead('Cluster',c,now)+bdown('Cluster',c);
  const bn=isObj(c.bench)?c.bench:null,k=c.ok===true?'ok':'bad';
  const kv=num(c.kv_cache_pct);
  const live=c.ok===true?tile('Model \u00B7 '+(str(c.model,60)||'unknown'),'Running '+(num(c.running)==null?'unknown':fmt(c.running))+' \u00B7 waiting '+(num(c.waiting)==null?'unknown':fmt(c.waiting)),
   'Cache '+(kv==null?'unknown':fmt(kv,1,'%')+' full'),k,'wrap',[str(c.src,60)]):empty({k:'bad',title:'Cluster is not reachable',line:'Check that the machines are on, then try again.',retry:'fleet',diag:['No answer from the local proxy on port 8080']});
  let bt;
  if(!bn||bn.error)bt=empty({k:'stale',title:'No benchmark yet',line:'Results show up after the next benchmark run.',diag:[bn&&bn.error?str(bn.error,60):'no bench data',str(bn&&bn.src,60)].filter(Boolean)});
  else{const fs=arr(bn.fields).filter(isObj).filter(x=>typeof x.v==='number').slice(0,5).map(x=>str(x.k,32).replace(/_median$/,'').replace(/_/g,' ')+' '+(typeof x.v==='number'?fmt(x.v,Number.isInteger(x.v)?0:1):str(String(x.v),24))).join(' \u00B7 ');
   bt=tile('Latest benchmark \u00B7 '+(str(bn.date,12)||'date unknown'),fs||'No numbers recorded','Measured '+(toEpoch(bn.t)==null?'at an unknown time':ago(bn.t,now)),bn.stale?'stale':'ok','wrap',[str(bn.file,60)].filter(Boolean))}
  return '<div class="secttl"><span>Cluster</span><span>'+esc(c.ok===true?'Checked '+ago(c.t,now):'Not reachable')+'</span></div>'+live+bt}
 function bModels(m,now){
  if(!isObj(m)||m.error){const p=problem(m);return bhead('Models by device',m,now)+empty({k:'stale',title:'Models by device are not reporting',line:p.line,retry:'fleet',diag:p.diag})}
  const ds=arr(m.devices).filter(isObj);
  if(!ds.length)return bhead('Models by device',m,now)+empty({title:'No devices listed',line:'Models show up here once a device reports in.'});
  return bhead('Models by device',m,now)+'<div class="flist">'+ds.map(d=>{const ms=arr(d.models).map(x=>str(x,60)).filter(Boolean);
   return row(str(d.device,24)||'Device',ms.length?ms.join(', '):'No models reported','<small>'+ms.length+'</small>',ms.length?'':'stale')}).join('')+'</div>'}
 // ---- Code backup: ~/.meshvault/status/deck/gitsync.json, one row per host. Counts of OUR repos only; a null count reads "unknown", never 0. ----
 const syncN=(n,w)=>fmt(n)+' '+w+(n===1?'':'s');
 const syncHosts=b=>isObj(b)&&!b.error?arr(b.hosts).filter(h=>isObj(h)&&str(h.host,40)):[];
const syncName=h=>redact(str(h.label,30)||str(h.host,30));
 // Counts describe local refs, never a verified remote backup.
 function syncLine(h){const r=num(h.own_repos),u=num(h.unpushed);
  if(r==null&&u==null)return 'Not checked yet';
  if(u==null)return 'Local commits ahead: unknown';
  return u===0?'No local commits ahead':syncN(u,'repo')+(u===1?' has':' have')+' local commits ahead'}
const syncKind=(h,b)=>b.stale||h.error||num(h.stale_s)==null||num(h.stale_s)>2*(num(b.refresh)||1800)||num(h.unknown)!==0||num(h.no_remote)!==0||num(h.unpushed)==null?'unknown':num(h.unpushed)>0?'ahead':'local';
const syncOld=(h,b)=>!!b.stale||num(h.stale_s)==null||num(h.stale_s)>2*(num(b.refresh)||1800);
// age since the last good scan; under a minute it reads "just now" (lapse() alone returns '' there)
function syncFresh(h,now){const s=num(h.stale_s),e=redact(str(h.error,30));
  return [e,s!=null&&s>0?'checked '+ago(now/1000-s,now):''].filter(Boolean).join(' \u00B7 ')}
// the row is ONE human line (counts, no-remote and unknown numbers live in the sheet); the pill says whether to trust it
function syncRowLine(h,k,b,now){const e=redact(str(h.error,30)),s=num(h.stale_s);
  const main=num(h.unpushed)===0&&k==='unknown'?(syncOld(h,b)?'Not checked recently':'Not every repo was checked'):syncLine(h);
  return [main,e,syncOld(h,b)&&s!=null&&s>0?'checked '+ago(now/1000-s,now):''].filter(Boolean).join(' \u00B7 ')}
 function bBackup(b,now){
  const hs=syncHosts(b);
  if(!hs.length)return '<div class="secttl"><span>Code backup</span></div>'+empty({title:'Backup status not reported yet',line:'Each machine shows up here after its first check.',diag:[isObj(b)&&str(b.error,60),isObj(b)&&str(b.src,80)].filter(Boolean)});
  return bhead('Code backup',b,now)+'<p class="muted">Local refs only. Remote backup is not verified.</p><div class="flist">'+hs.map(h=>{const k=syncKind(h,b);
   const pill=k==='local'?'<span class="pill">'+SD('ok')+'No commits ahead</span>':k==='ahead'?'<span class="pill warn">'+SD('warn')+'Ahead</span>':'<span class="pill warn">'+SD('warn')+'Unknown</span>';
   return row(syncName(h),syncRowLine(h,k,b,now),pill,'','',dattr('sync',str(h.host,40)))}).join('')+'</div>'}
 // the sheet a backup row opens: local tracking information, not remote verification
 function syncSheet(b,host,now){const hs=syncHosts(b),h=hs.find(x=>str(x.host,40)===host);
  if(!h)return {kind:'card',title:'Code backup',sub:'Not reported yet',lines:['Backup status is not reported yet.'],log:[],logTitle:'',actions:[]};
  const c=(l,v)=>l+': '+(num(v)==null?'unknown':fmt(v)),list=arr(isObj(b)&&b.unpushed).filter(x=>isObj(x)&&str(x.host,40)===host).slice(0,40);
  const fresh=syncFresh(h,now);
  return {kind:'card',title:syncName(h),sub:'Local tracking refs only'+(fresh?' \u00b7 '+fresh:''),
   lines:[syncLine(h),c('Checkouts',h.checkouts),c('Unique repos',h.repos),c('Owner repos',h.own_repos),c('Repos with local commits ahead',h.unpushed),c('No remote',h.no_remote),c('Uncommitted changes',h.dirty),c('Third-party clones',h.third_party),c('Unknown',h.unknown)],
   log:list.map(x=>redact(str(x.repo,90))+' \u00b7 '+(redact(str(x.branch,40))||'branch unknown')+' \u00b7 '+(num(x.ahead)==null?'commits ahead unknown':fmt(x.ahead)+' ahead')),
   logTitle:list.length?(list.length===1?'Repo with local commits ahead':'Repos with local commits ahead'):(num(h.unpushed)===0?'No local commits ahead':''),actions:[]}}
 // systemd escapes (\x2d) and the .service suffix are plumbing, not names
 const unitLabel=n=>str(n,96).replace(/\\x([0-9a-f]{2})/gi,(m,x)=>String.fromCharCode(parseInt(x,16))).replace(/\.service$/,'');
 function bUnits(u,now){
  if(!isObj(u)||u.error){const p=problem(u),first=isObj(u)&&/missing/i.test(str(u.error,60));
   return bhead('Background services',u,now)+empty({k:'stale',title:'Background services are not reporting',line:first?'The first snapshot has not been taken yet.':p.line,retry:'fleet',diag:(first?['Run ~/ops/bin/deck-fleet-snapshot to take one']:[]).concat(p.diag)})}
  if(u.writer_ok===false)return bhead('Background services',u,now)+empty({k:'bad',title:'The snapshot could not check services',line:'Try again after the next snapshot.',retry:'fleet',diag:['The snapshot writer could not run systemctl']});
  const ns=arr(u.failed_units).map(x=>str(x,96)).filter(Boolean),fresh=bsrc(u,now);
  // one calm row per failing unit: a mark and a word. The header carries the count; nothing here is filled red.
  return '<div class="secttl"><span>Background services</span><span>'+esc((ns.length?ns.length+' need attention \u00B7 ':'')+fresh)+'</span></div>'+
   '<div class="flist">'+(ns.length?ns.map(x=>row(unitLabel(x),'','<span class="pill">'+SD('bad')+'Failed</span>','','',UNIT_RE.test(x)?dattr('unit',x):'')).join(''):row('All services are running','Nothing is failing','<span class="pill">'+SD(u.stale?'warn':'ok')+(u.stale?'Out of date':'OK')+'</span>'))+'</div>'}
 const renderFail=t=>empty({k:'bad',title:'Could not show '+str(t,40),line:'Try again. If it keeps happening, reload the deck.',retry:'fleet'});
 // [machines, cluster, models, backup, units]; app.js fleet() places them in the three Fleet columns
 function board(b,now){
  if(!isObj(b))return ['<div class="secttl"><span>Fleet board</span><span>Not reporting</span></div>'+down('Fleet board',null,'fleet'),'','','',''];
  const part=(fn,k)=>{try{return fn(b[k],now)}catch(e){return renderFail(k)}};
  return [part(bMachines,'machines'),part(bCluster,'cluster'),part(bModels,'models'),part(bBackup,'backup'),part(bUnits,'units')]}
 // Optional fleet signals share one compact section; no configured source is never a zero reading.
 function fleetSignals(f,now){
  const title=bhead('Fleet signals',f,now);
  if(!isObj(f)||f.error)return title+bdown('Fleet signals',f);
  const thermal=isObj(f.thermal)?f.thermal:{},hosts=isObj(thermal.hosts)?thermal.hosts:{};
  const total=Object.keys(hosts).length,measured=Object.values(hosts).filter(h=>num(h&&h.cpu_c)!=null||num(h&&h.soc_c)!=null||num(h&&h.skin_c)!=null||num(h&&h.gpu_c)!=null).length;
  const temp=Object.entries(hosts).slice(0,8).map(([name,h])=>{
   const label=num(h&&h.cpu_c)!=null?'CPU':num(h&&h.soc_c)!=null?'SoC':num(h&&h.skin_c)!=null?'Skin':'CPU';
   const value=num(h&&h.cpu_c)??num(h&&h.soc_c)??num(h&&h.skin_c),gpu=num(h&&h.gpu_c),sensor=str(h&&(h.cpu_sensor||h.soc_sensor),24);
   return row(str(name,24)||'Device',label+' '+fmt(value,0,'\u00B0C')+' \u00B7 GPU '+fmt(gpu,0,'\u00B0C'),'',value==null&&gpu==null?'stale':'','','',sensor?['Sensor '+sensor]:[])}).join('');
  const o=isObj(f.outbound)?f.outbound:{},h=isObj(f.hydra)?f.hydra:{},fl=isObj(f.flightradar)?f.flightradar:{},n=isObj(f.neighbors)?f.neighbors:{};
  const queue=x=>num(x&&x.files)==null?'unknown':fmt(x.files);
  const count=x=>num(x)==null?'unknown':fmt(x);
  return title+tile('Temperatures',thermal.error||!total?'Not reporting':measured+' of '+total+' machines reporting',
    thermal.error?'The sensors did not answer':'Updated '+ago(thermal.t,now),thermal.error?'bad':!total||thermal.stale||measured<total?'stale':'ok','',[thermal.error&&str(thermal.error,80),str(thermal.src,40)].filter(Boolean))+
   (temp?'<div class="flist">'+temp+'</div>':'')+
   tile('Outbound mail',queue(o.legacy_queue)+' waiting \u00B7 '+queue(o.quote_followup_queue)+' follow-ups',
    'Drafts '+count(o.drafts)+' \u00B7 agents '+count(o.outbound_agents),o.error?'bad':'stale','',[str(o.src,60)].filter(Boolean))+
   '<div class="flist">'+row('Hydra',h.installed===true?'Installed (not checked whether it is running)':h.installed===false?'Not installed':'Status unknown','','','','',[str(h.src,40)].filter(Boolean))+
    row('Flight radar',fl.installed===true?'Installed (live aircraft not checked)':fl.installed===false?'Not installed':'Status unknown','','','','',[str(fl.src,40)].filter(Boolean))+
    row('Network neighbors',num(n.cached_reachable_count)==null?'Status unknown':fmt(n.cached_reachable_count)+' known devices \u00B7 no new scan','','','','',[str(n.src,40)].filter(Boolean))+'</div>'}

 // ---- v8: Launch run window: safe markdown, one row per tool, human status line (all pure) ----
 const RUN_STATES=['queued','running','done','failed'];
 // The Run again button, without touching the DOM: no saved run and no item both mean disabled, never a crash.
 function againState(r,armed){const ok=!!(isObj(r)&&str(r.id,100)),on=ok&&armed===r.run_id;
  return {disabled:!ok,armed:on,text:!ok?'No item':on?'Tap again':'Run again',
   aria:on?'Tap again to run '+str(r.name,60):ok?'Run '+str(r.name,60)+' again':'Run again'}}
 function runClock(s){const n=num(s);if(n==null)return '--:--';const t=Math.max(0,Math.floor(n)),h=Math.floor(t/3600),m=Math.floor(t%3600/60),x=t%60,p=v=>String(v).padStart(2,'0');return h?h+':'+p(m)+':'+p(x):m+':'+p(x)}
// $HOME is never shown: see homeTilde and scanSecrets (top of this block)
// tool arguments are redacted by default: scanSecrets (url userinfo and query strings, credential names and shapes) plus long token-like strings
const LONG_TOKEN_RE=/(?=[A-Za-z0-9+\/_=-]*\d)[A-Za-z0-9+\/_=-]{32,}/g;
function scrubArg(s,n){let t=scanSecrets(s,{mark:'\u2026',query:true}).replace(LONG_TOKEN_RE,'\u2026');
  t=homeTilde(t).replace(/[\u0000-\u001F\u007F]/g,' ').replace(/\s+/g,' ').trim();const cap=n||48,c=Array.from(t);return c.length>cap?c.slice(0,cap-1).join('').trimEnd()+'\u2026':t}
// agent prose, line by line: credentials scrubbed, home folders read ~ (the server scrubs too; this is the same rule, never a different one)
const proseText=t=>String(t==null?'':t).split('\n').map(l=>homeTilde(scanSecrets(l))).join('\n');
 // a value that may arrive as plain text or as (possibly cut off) JSON: take the first of keys
 function jsonArg(v,keys){const t=String(v==null?'':v).trim();if(t[0]!=='{')return t;
  const m=new RegExp('"(?:'+keys.join('|')+')"\\s*:\\s*"((?:[^"\\\\]|\\\\.)*)').exec(t);return m?m[1].replace(/\\(.)/g,'$1'):''}
 function argFile(v){let t=jsonArg(v,['path','file_path','file','filename','target']).replace(/^\s*(?:path|file)\s*[=:]\s*/i,'').trim();
  if(/^["'`]/.test(t)){const q=t[0],j=t.indexOf(q,1);t=j>0?t.slice(1,j):t.slice(1)}else t=t.split(/\s+/)[0]||'';
  t=homeTilde(t);if(t==='~'||t==='~/')return '~';
  t=t.replace(/[?#].*$/,'').replace(/:\d+(?:[-,]\d+)?$/,'').replace(/\/+$/,'');const i=t.lastIndexOf('/');return scrubArg(i>=0?t.slice(i+1):t,40)}
 // a command shows its program only, never its arguments
 function argCmd(v){let t=jsonArg(v,['command','cmd']).trim().replace(/^cd\s+\S+\s*(?:&&|;)\s*/,'');
  const w=t.split(/\s+/);let k=0;while(k<w.length&&(/^[A-Za-z_][A-Za-z0-9_]*=/.test(w[k])||/^(?:sudo|env|nice|time|nohup|timeout)$/.test(w[k])))k++;
  const p=String(w[k]||'').replace(/^\.\//,'').split('/').pop();return /^[A-Za-z0-9._+-]{1,32}$/.test(p)?p:''}
 function argUrl(v){const t=jsonArg(v,['url','uri','href']),m=/^\s*[a-z][a-z0-9+.-]*:\/\/(?:[^\/?#@\s]*@)?([^\/?#:\s]+)/i.exec(t);return m?m[1].replace(/^www\./i,'').slice(0,60):scrubArg(t,40)}
 const argText=v=>scrubArg(jsonArg(v,['query','q','text','prompt','name','input']),40);
 // [pattern, argument kind, status-line phrase, verb while running, verb when finished, whole label with no argument (running, finished)]
 const TOOL_SPECS=[
  [/^(?:read|read_file|view|view_file|cat|open_file)$/,'file','reading files','Reading','Read','Reading a file','Read a file'],
  [/^(?:write|write_file|create_file)$/,'file','writing files','Writing','Wrote','Writing a file','Wrote a file'],
  [/^(?:patch|edit|edit_file|replace|str_replace|apply_patch|multi_edit)$/,'file','editing files','Editing','Edited','Editing a file','Edited a file'],
  [/^(?:search_files|grep|glob|find|find_files|ripgrep|search_code)$/,'text','searching files','Searching for','Searched for','Searching files','Searched files'],
  [/^(?:terminal|bash|shell|process|execute|run_command|exec)$/,'cmd','running commands','Running','Ran','Running a command','Ran a command'],
  [/^(?:execute_code|python|run_code)$/,'','running code','Running code','Ran code','Running code','Ran code'],
  [/^web_search$/,'text','searching the web','Searching the web for','Searched the web for','Searching the web','Searched the web'],
  [/^(?:web_extract|web_fetch|fetch|http|browser_navigate)$/,'url','reading web pages','Reading','Read','Reading a web page','Read a web page'],
  [/^browser(?:_.*)?$/,'','browsing','Browsing the web','Browsed the web','Browsing the web','Browsed the web'],
  [/^(?:skill_view|skills_list|skill|skill_manage)$/,'text','loading a skill','Loading skill','Loaded skill','Loading a skill','Loaded a skill'],
  [/^(?:todo|todo_write|plan)$/,'','planning','Updating the plan','Updated the plan','Updating the plan','Updated the plan'],
  [/^memory$/,'','updating memory','Updating memory','Updated memory','Updating memory','Updated memory'],
  [/^delegate_task$/,'','delegating','Delegating a task','Delegated a task','Delegating a task','Delegated a task'],
  [/^session_search$/,'text','searching past chats','Searching past chats for','Searched past chats for','Searching past chats','Searched past chats'],
  [/^send_message$/,'','sending a message','Sending a message','Sent a message','Sending a message','Sent a message'],
  [/^cronjob$/,'','managing a scheduled job','Managing a scheduled job','Managed a scheduled job','Managing a scheduled job','Managed a scheduled job'],
  [/^(?:vision_analyze|image_analyze)$/,'','looking at an image','Looking at an image','Looked at an image','Looking at an image','Looked at an image'],
  [/^clarify$/,'','asking a question','Asking a question','Asked a question','Asking a question','Asked a question']];
 function toolSpec(tool){const n=String(tool==null?'':tool).toLowerCase().replace(/^mcp[_-]+/,'');
  for(const s of TOOL_SPECS)if(s[0].test(n))return {kind:s[1],say:s[2],run:s[3],done:s[4],bareRun:s[5],bareDone:s[6]};
  const h=n.split(/__|\./).pop().replace(/[_-]+/g,' ').replace(/[^a-z0-9 ]/g,'').trim().slice(0,28)||'a tool';
  return {kind:'',say:'using '+h,run:'Using '+h,done:'Used '+h,bareRun:'Using '+h,bareDone:'Used '+h}}
 // st: run (still going), ok, bad (the tool reported a failure), stop (the run ended before the tool reported back)
 function toolLabel(tool,preview,st){const sp=toolSpec(tool),fin=st==='ok'||st==='bad';let arg='';
  if(sp.kind==='file')arg=argFile(preview);else if(sp.kind==='cmd')arg=argCmd(preview);else if(sp.kind==='url')arg=argUrl(preview);else if(sp.kind==='text')arg=argText(preview);
  const t=arg?(fin?sp.done:sp.run)+' '+arg:(fin?sp.bareDone:sp.bareRun);
  return st==='bad'?t+' failed':st==='stop'?t+' stopped':t}
 // gateway lines -> items: "tool X: preview" and "tool X finished|failed" collapse into ONE row per tool call; other lines are prose
 const TOOL_DONE_RE=/^tool (\S+) (finished|failed)$/,TOOL_START_RE=/^tool ([^\s:]+):(?:\s+(.*))?$/,LINE_ERR_RE=/^(error|failed|cancelled|interrupted):\s*(.*)$/i;
 const ERR_WORD={error:'Error',failed:'Failed',cancelled:'Cancelled',interrupted:'Interrupted'};
 function runItems(lines,state){const items=[],pending=[],term=state==='done'||state==='failed';
  for(const raw of arr(lines)){const l=String(raw==null?'':raw);let m;
   if((m=TOOL_DONE_RE.exec(l))){const p=pending.findIndex(r=>r.tool===m[1]),st=m[2]==='failed'?'bad':'ok';
    if(p>=0){pending[p].st=st;pending.splice(p,1)}else items.push({k:'tool',tool:m[1],arg:'',st,n:1});continue}
   if((m=TOOL_START_RE.exec(l))){const r={k:'tool',tool:m[1],arg:m[2]||'',st:'run',n:1};items.push(r);pending.push(r);continue}
   if(state==='failed'&&(m=LINE_ERR_RE.exec(l))){items.push({k:'err',text:ERR_WORD[m[1].toLowerCase()]+(m[2]?': '+scrubArg(m[2],200):'')});continue}
   const last=items[items.length-1];if(last&&last.k==='md')last.text+='\n'+l;else items.push({k:'md',text:l})}
  if(term)for(const r of pending)r.st=state==='failed'?'stop':'ok';
  const out=[];for(const it of items){const p=out[out.length-1];
   if(p&&it.k==='tool'&&p.k==='tool'&&p.st!=='run'&&p.st===it.st&&p.tool===it.tool&&p.arg===it.arg)p.n+=it.n;else out.push(it)}
  return out}
 const GLYPH={ok:'<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3.5 8.5l3 3 6-7"/></svg>',
  bad:'<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M4 4l8 8M12 4l-8 8"/></svg>',run:'<i class="tspin"></i>'};
 const ST_WORD={run:'In progress',ok:'Done',bad:'Failed',stop:'Stopped'};
 function itemsHtml(items){let h='',open=false;
  for(const it of items){
   if(it.k==='tool'){if(!open){h+='<div class="rtools" role="list">';open=true}
    h+='<div class="rt '+it.st+'" role="listitem"><span class="tg" aria-hidden="true">'+(GLYPH[it.st]||GLYPH.bad)+'</span><span class="sr">'+ST_WORD[it.st]+'. </span><span class="tx">'+esc(toolLabel(it.tool,it.arg,it.st))+'</span>'+(it.n>1?'<span class="tn">\u00D7'+it.n+'</span>':'')+'</div>';continue}
   if(open){h+='</div>';open=false}
   h+=it.k==='err'?'<div class="rerr"><span class="tg" aria-hidden="true">'+GLYPH.bad+'</span><span>'+esc(it.text)+'</span></div>':'<div class="rmd">'+mdHtml(proseText(it.text))+'</div>'}
  return h+(open?'</div>':'')}
 // Markdown that cannot inject: nothing is ever passed through as HTML. Every literal piece goes through esc(); the only tags written are
 // the ones below; link targets must pass safeUrl (http or https, no quotes, angle brackets or spaces) or the link text stays as plain text.
 const MD_INLINE_RE=/`([^`\n]+)`|\*\*([^*\n]+?)\*\*|\[([^\]\n]{1,200})\]\((\S{1,500}?)\)|(^|[\s(])\*([^\s*](?:[^*\n]*?[^\s*])?)\*(?=[\s).,;:!?]|$)/g;
 function mdInline(s,d){let out='',i=0,m;const re=new RegExp(MD_INLINE_RE.source,'g');
  while((m=re.exec(s))){out+=esc(s.slice(i,m.index));i=m.index+m[0].length;
   if(m[1]!=null)out+='<code>'+esc(m[1])+'</code>';
   else if(m[2]!=null)out+='<strong>'+(d<2?mdInline(m[2],d+1):esc(m[2]))+'</strong>';
   else if(m[3]!=null){const u=safeUrl(m[4]),t=d<2?mdInline(m[3],d+1):esc(m[3]);out+=u?'<a href="'+esc(u)+'" target="_blank" rel="noopener noreferrer">'+t+'</a>':t}
   else out+=esc(m[5])+'<em>'+esc(m[6])+'</em>'}
  return out+esc(s.slice(i))}
 function mdHtml(text){const L=String(text==null?'':text).replace(/\r\n?/g,'\n').split('\n').slice(0,400),out=[];let i=0,list=null;
  const flush=()=>{if(list){out.push('<'+list.t+'>'+list.items.map(x=>'<li>'+mdInline(x,0)+'</li>').join('')+'</'+list.t+'>');list=null}};
  const item=(t,x)=>{if(!list||list.t!==t){flush();list={t,items:[]}}list.items.push(x)};
  while(i<L.length){const l=L[i];let m;
   if((m=/^\s*(```|~~~)[A-Za-z0-9_+-]*\s*$/.exec(l))){flush();const f=m[1],buf=[];i++;while(i<L.length&&!L[i].trim().startsWith(f)){buf.push(L[i]);i++}
    out.push('<pre class="rcode"><code>'+esc(buf.join('\n'))+'</code></pre>')}
   else if(/^\s*([-*_])(?:\s*\1){2,}\s*$/.test(l)){flush();out.push('<hr>')}
   else if((m=/^(#{1,6})\s+(.+?)\s*#*\s*$/.exec(l))){flush();out.push('<div class="rh rh'+Math.min(m[1].length,3)+'" role="heading" aria-level="3">'+mdInline(m[2],0)+'</div>')}
   else if((m=/^\s*[-*+]\s+(.+)$/.exec(l)))item('ul',m[1]);
   else if((m=/^\s*\d{1,3}[.)]\s+(.+)$/.exec(l)))item('ol',m[1]);
   else if((m=/^\s*>\s?(.*)$/.exec(l))){flush();out.push('<blockquote>'+mdInline(m[1],0)+'</blockquote>')}
   else if(l.trim()==='')flush();
   else{flush();out.push('<p>'+mdInline(l.trim(),0)+'</p>')}
   i++}
  flush();return out.join('')}
 // run titles come from launch ids like "skill:morning-brief": show the name part, never the id syntax
 function runTitle(name){const s=cleanText(name,80).replace(/\s+/g,' '),m=/^[a-z]{3,8}:([A-Za-z0-9._\/-]{1,70})$/.exec(s),t=(m?m[1].replace(/[-_.]+/g,' ').trim():s);return str(t.charAt(0).toUpperCase()+t.slice(1),60)}
 // the model Hermes actually served (/api/run `route.served`, "openai-codex/gpt-6-luna"); a mismatch is shown by the run itself as a failure line
 function routeNote(m){const rt=isObj(m)&&isObj(m.route)?m.route:null,s=rt&&rt.ok!==false&&typeof rt.served==='string'?rt.served:'';return /^[A-Za-z0-9][A-Za-z0-9._:\/-]{0,79}$/.test(s)?'Model '+s:''}
 // r: {run_id,name,opened,model,got,err,fails,offline,beat}  model = last good /api/run answer, got = Date.now() when it arrived
 // Not finished + (gateway silent for RUN_OFFLINE_FAILS polls, or queued past RUN_QUEUE_TIMEOUT_S) reads offline with its reason.
 // A run that is not finished always prints a "last gateway heartbeat" line, so it never sits silent on "Working".
 const RUN_QUEUE_TIMEOUT_S=45,RUN_GIVEUP=20,RUN_OFFLINE_FAILS=2;
 function runView(r,now){const m=isObj(r&&r.model)?r.model:null,raw=m&&RUN_STATES.includes(m.state)?m.state:'queued',term=raw==='done'||raw==='failed';
  let el=null;
  if(m&&num(m.elapsed_s)!=null)el=term?m.elapsed_s:m.elapsed_s+Math.max(0,(now-(r.got||now))/1000);
  else if(num(r&&r.opened)!=null)el=Math.max(0,now/1000-r.opened);
  const fails=num(r&&r.fails)||0,gaveUp=!term&&fails>=RUN_GIVEUP,
   gwSilent=!term&&(fails>=RUN_OFFLINE_FAILS||(!!(r&&r.offline)&&fails>0)),
   deckSilent=gwSilent&&!(r&&r.offline),
   stalled=!term&&raw==='queued'&&(!!(m&&m.stalled)||(el!=null&&el>=RUN_QUEUE_TIMEOUT_S)),
   state=gwSilent||stalled?'offline':raw,
   reason=state!=='offline'?'':deckSilent?'Deck server not answering':gwSilent||!m?'Hermes offline':'Stuck in queue',
   beat=m&&num(m.t)!=null?m.t:m&&num(m.heartbeat)!=null?m.heartbeat:m&&num(r.got)?r.got/1000:num(r&&r.beat),
   hb=term?'':'<div class="rl dim hb">'+(beat!=null?'Last word from Hermes '+ago(beat,now):'No word from Hermes yet')+'</div>',
   give=gaveUp?'<div class="rl dim">Stopped retrying after '+fails+' failed polls. Tap Last run to try again.</div>':'';
  const lines=m?arr(m.lines).map(x=>str(x,240)).filter(Boolean):[];
  const wait=raw==='running'&&!!m&&m.detail==='waiting_for_approval';
  const empty=state==='offline'?reason+'. '+(!m?'Hermes has not answered yet':raw==='queued'?'Queued '+runClock(el)+(gwSilent?' and Hermes never started it':', Hermes answers but has not started it'):'Hermes stopped answering')
   :!m?'Waiting for Hermes to start':wait?'Hermes is waiting for your approval. Approve it in Hermes; this deck cannot approve':raw==='queued'?'Queued. No output yet':raw==='running'?'Running. Waiting for output':raw==='done'?'Finished with no output':'Failed with no output';
  const more=m&&num(m.more)>0?num(m.more):0,items=runItems(lines,raw),last=items[items.length-1];
  const say=!last?'getting started':last.k==='md'?'writing a reply':last.k==='tool'&&last.st==='run'?toolSpec(last.tool).say:'thinking';
  const note=state==='offline'?reason+(r&&r.err?' \u00B7 '+str(r.err,60):'')+(gaveUp?' \u00B7 stopped retrying':' \u00B7 retrying'):r&&r.err?(term?'Could not refresh this run':'Connection lost, trying again'):routeNote(m);
  return {state,label:state==='offline'?reason:wait?'Waiting for your approval':raw==='queued'?'Queued':raw==='running'?'Working: '+say:raw==='done'?'Done':'Failed',terminal:term,mark:raw==='done'?'ok':raw==='failed'||state==='offline'?'bad':'warn',elapsed:runClock(el),reason,gaveUp,
   title:runTitle(r&&r.name)||runTitle(m&&m.item)||'Hermes run',
   html:(more?'<div class="rl dim">'+more+' earlier line'+(more>1?'s':'')+' not shown</div>':'')+(items.length?itemsHtml(items):'<div class="rl dim">'+esc(empty)+'</div>')+hb+give,
   note,stale:!!(r&&r.err)||state==='offline'}}

 // ---- feedback release: detail sheet, cron and unit actions, Ask Hermes drafts, run thread, link rules (all pure) ----
 const UNIT_RE=/^[A-Za-z0-9@._-]{1,96}\.(service|timer)$/;
 const ID8_RE=/^[0-9a-f]{8}$/;
 const RUN_ID_RE=/^[A-Za-z0-9._-]{1,80}$/;
 // the browser only ever knows the first 8 hex chars of a job id; the server resolves the full id
 const cronId=j=>{const v=str(j&&j.id,8);return ID8_RE.test(v)?v:''};
// plain text for the API: printable characters plus newline and tab, trimmed, at most n code points (default 2000; Infinity keeps all). The server counts
// code points; a cut UTF-16 pair or a lone surrogate would make the JSON body invalid, so lone halves are dropped. Every Unicode space the server refuses
// (no-break, en/em/thin/ideographic and the rest of category Zs) becomes a plain U+0020, as the server (actions.rs clean_text, deck-launch send_text) does too.
const cleanText=(s,n)=>Array.from(String(s==null?'':s).replace(/\r\n?/g,'\n').replace(/[\u00A0\u1680\u2000-\u200A\u202F\u205F\u3000]/g,' ').replace(/[\uD800-\uDBFF](?![\uDC00-\uDFFF])/g,'').replace(/(^|[^\uD800-\uDBFF])[\uDC00-\uDFFF]/g,'$1').replace(/[^\n\t\x20-\x7E\u00A0-\u2027\u202A-\uFFFF]/g,'').trim()).slice(0,n||2000).join('').trim();
 // tap-to-open: chain = [{tag,cls}] from the tapped element up to (not including) the page. Returns the index of the
 // card to open, or -1 when the tap belongs to a link, button, input, camera, Launch row or filter chip.
const SHEET_PAGES=['crons','fleet','today','cluster','dev','life','house','keys','home','shop','commerce','money'];
const SHEET_OPEN=['tile','frow','mt','chip','node','dk','cronrow','hl','es','trow','tagg','wc'];
 const SHEET_BLOCK_TAG=['A','BUTTON','INPUT','TEXTAREA','SELECT','LABEL','SUMMARY','VIDEO','CANVAS'];
 const SHEET_BLOCK_CLS=['jchip','lnk','lnt','lnw','lnb','lnrow','cam','vb','key'];
 function sheetPick(page,chain){
  if(!SHEET_PAGES.includes(page)||!Array.isArray(chain))return -1;
  let hit=-1;
  for(let i=0;i<chain.length;i++){const n=chain[i]||{},tag=String(n.tag||'').toUpperCase(),cls=String(n.cls||'').split(/\s+/).filter(Boolean);
   if(SHEET_BLOCK_TAG.includes(tag)||cls.some(c=>SHEET_BLOCK_CLS.includes(c)))return -1;
   if(hit<0&&cls.some(c=>SHEET_OPEN.includes(c)))hit=i}
  return hit}
 // the card's own markup turned into plain lines; tags are dropped before entities are decoded, so decoded text is never markup
 const ENT={'&amp;':'&','&lt;':'<','&gt;':'>','&quot;':'"','&#39;':"'",'&nbsp;':' '};
 function htmlLines(html,max){
  return String(html==null?'':html).replace(/<[^>]*>/g,'\n').replace(/&(?:amp|lt|gt|quot|#39|nbsp);/g,m=>ENT[m])
   .split('\n').map(l=>l.replace(/[\u0000-\u001F\u007F]/g,' ').replace(/\s+/g,' ').trim()).filter(Boolean).map(l=>l.slice(0,400)).slice(0,max||40)}
 // diagnostics (.diag spans) leave the card text and show under "Details"; the card's own buttons are not text
 function cardSheet(html,label){const dg=[];
  const main=String(html==null?'':html).replace(/<button[\s\S]*?<\/button>/g,'').replace(/<span class="diag">([\s\S]*?)<\/span>/g,(m,t)=>{dg.push(t);return ''});
  const ls=htmlLines(main),log=htmlLines(dg.join('<i></i>'),30);
  return {kind:'card',title:ls[0]||'Details',sub:str(label,40),lines:ls.length>1?ls.slice(1):['No more text on this card'],log,logTitle:log.length?'Details':'',actions:[]}}
 const cronList=f=>isObj(f)?arr(f.active).filter(isObj).map(j=>({j,paused:false})).concat(arr(f.paused).filter(isObj).map(j=>({j,paused:true}))):[];
 const findCron=(f,id8)=>cronList(f).find(x=>cronId(x.j)===id8)||null;
 const cronActions=(paused,hasId)=>(hasId?[{id:'run',label:'Run now',confirm:true},paused?{id:'resume',label:'Resume',confirm:true}:{id:'pause',label:'Pause',confirm:true}]:[]).concat([{id:'ask',label:'Ask Hermes'}]);
 function cronDraft(j,paused,now){const ls=str(j&&j.last_status,24),last=j&&j.last_run_at;
  return cleanText('Cron job "'+(str(j&&j.name,80)||'unnamed')+'" (id '+(cronId(j)||str(j&&j.id,8)||'unknown')+')\nSchedule: '+(str(j&&j.schedule_display,60)||'unknown')+(paused?' (paused)':'')+
   '\nLast run: '+(last?(ls||'status unknown')+', '+ago(last,now):'never run')+'\n\nWhy did this fail, or what should I do about it?',1500)}
 function cronSheet(j,paused,now){const id8=cronId(j),ls=str(j&&j.last_status,24),last=j&&j.last_run_at,next=j&&j.next_run_at,nextT=toEpoch(next),failed=ls!==''&&ls.toLowerCase()!=='ok';
  const model=[str(j&&j.provider,40),str(j&&j.model,60)].filter(Boolean).join(' / ');
  return {kind:'cron',id:id8,title:str(j&&j.name,80)||'Unnamed job',sub:'Scheduled job',
   lines:['Schedule: '+schedule(j&&j.schedule_display),'Lane: '+laneOf(j),'State: '+(paused?'Paused':'Active'),
    'Last run: '+(last?(failed?'Failed':'OK')+' \u00B7 '+ago(last,now)+' \u00B7 '+clock(last):'Never run'),
    'Next run: '+(nextT==null?(paused?'None, paused':'Not scheduled'):paused?'Was due '+clock(next):until(next,now)+' \u00B7 '+clock(next))],
   log:[id8&&'ID '+id8,'Schedule text '+(str(j&&j.schedule_display,60)||'unknown'),str(j&&j.state,20)&&'State '+str(j.state,20),ls&&'Last status '+ls,'Provider and model '+(model||'none pinned')].filter(Boolean),logTitle:'Details',
   actions:cronActions(paused,!!id8),draft:cronDraft(j,paused,now)}}
 const unitOk=name=>typeof name==='string'&&UNIT_RE.test(name);
 function unitDraft(name,j){const ok=isObj(j)&&j.ok===true;
  return cleanText('Systemd user unit '+str(name,96)+' is failing.'+(ok?'\nState: '+(str(j.active,20)||'unknown')+(str(j.sub,20)?' ('+str(j.sub,20)+')':'')+'\nResult: '+(str(j.result,30)||'unknown')+(num(j.exit)==null?'':'\nExit status: '+j.exit):'')+
   '\n\nWhy is it failing, and what should I do about it?',1500)}
 const unitSheet=name=>({kind:'unit',id:str(name,96),title:str(name,96),sub:'Failing background service \u00B7 read only',lines:['Reading state and log'],actions:[{id:'ask',label:'Ask Hermes'}],draft:unitDraft(name,null)});
 // /api/unit reply -> sheet lines plus mono journal lines; any other answer is said out loud, never blank
 function unitView(j){
  if(!isObj(j)||j.ok!==true)return {lines:['Could not read this service. Check your connection, then open it again.'],log:[],logTitle:''};
  const log=arr(j.lines).map(x=>redact(String(x==null?'':x).slice(0,240))).filter(x=>x.trim()).slice(0,25);
  return {lines:['State: '+(str(j.active,20)||'unknown')+(str(j.sub,20)?' ('+str(j.sub,20)+')':''),'Result: '+(str(j.result,30)||'unknown'),'Exit status: '+(num(j.exit)==null?'unknown':j.exit),'Since: '+(str(j.since,60)||'unknown')],
   log,logTitle:log.length?'Log, last '+log.length+' line'+(log.length>1?'s':''):'The log is empty'}}
 function sheetBody(spec){const s=isObj(spec)?spec:{};
  let h=arr(s.lines).map(l=>'<div class="sl">'+esc(l)+'</div>').join('');
  const log=arr(s.log);
  if(log.length||s.logTitle)h+='<div class="sh">'+esc(s.logTitle||'Log')+'</div>'+log.map(l=>'<div class="sl mono">'+esc(l)+'</div>').join('');
  return h||'<div class="sl dim">No details</div>'}
 const sheetLink=url=>{const u=safeUrl(url);return u?'<a class="b sact" href="'+esc(u)+'" target="_blank" rel="noopener noreferrer">Open link'+LK+'</a>':''};
 // two-tap rule: a confirm action arms on the first tap and runs on a second tap on the same action within ARM_MS
 const ARM_MS=3000;
 const armedNow=(armed,id,now)=>!!(armed&&armed.id===id&&now-armed.t>=0&&now-armed.t<=ARM_MS);
 function tapAction(armed,id,now,confirm){
  if(!confirm)return {armed:null,run:true};
  if(armedNow(armed,id,now))return {armed:null,run:true};
  return {armed:{id,t:now},run:false}}
 const sheetActions=(actions,armed,now,busy)=>arr(actions).filter(isObj).map(a=>{const on=!!a.confirm&&armedNow(armed,a.id,now),label=str(a.label,30);
  return '<button type="button" class="b sact'+(a.danger?' danger':'')+(on?' armed':'')+'" data-act="'+esc(a.id)+'"'+(on?' aria-label="'+esc(label)+', tap again to confirm"':'')+(busy?' disabled':'')+'>'+esc(on?'Tap again':label)+'</button>'}).join('');
 const ACT_DONE={run:'Run started',pause:'Paused',resume:'Resumed'};
 function actResult(j,status,act){
  if(isObj(j)&&j.ok===true)return {k:'ok',text:(ACT_DONE[act]||'Done')+(str(j.name,60)?' \u00B7 '+str(j.name,60):'')};
  return {k:'bad',text:humanErr(j,status)}}
 // ---- run window thread: your messages, each agent turn's output under its message, at most 8 turns ----
 const THREAD_MAX=8,TURN_MODES=['new','reply','steer','launch'],SEND_MODES=['new','reply','steer'];
 function threadAdd(th,t){const turn={run_id:str(t&&t.run_id,80),text:cleanText(t&&t.text,2000),mode:TURN_MODES.includes(t&&t.mode)?t.mode:'new'};
  return RUN_ID_RE.test(turn.run_id)?arr(th).concat([turn]).slice(-THREAD_MAX):arr(th).slice(-THREAD_MAX)}
 const threadSave=th=>JSON.stringify({v:1,turns:arr(th).slice(-THREAD_MAX)});
 function threadLoad(raw){let o=null;try{o=JSON.parse(raw||'null')}catch(e){}
  return (isObj(o)?arr(o.turns):[]).filter(t=>isObj(t)&&typeof t.run_id==='string'&&RUN_ID_RE.test(t.run_id)).map(t=>({run_id:t.run_id,text:cleanText(typeof t.text==='string'?t.text:'',2000),mode:TURN_MODES.includes(t.mode)?t.mode:'new'})).slice(-THREAD_MAX)}
 // the thread always ends with the run that is open, so its output is never missing
 function threadFor(th,run){const t=arr(th),id=run&&typeof run.run_id==='string'?run.run_id:'';
  if(!id||(t.length&&t[t.length-1].run_id===id))return t;
  return t.concat([{run_id:id,text:'',mode:'launch'}]).slice(-THREAD_MAX)}
 // your message is a right-aligned bubble; a steer shares its run with the turn before it, so the agent's output sits under the last message of each run
 function threadHtml(turns,outHtml){return arr(turns).map((t,i,a)=>{const last=!a[i+1]||a[i+1].run_id!==t.run_id;
  return (t.text?'<div class="rb m-'+esc(t.mode)+'">'+esc(t.text)+'</div>':'')+
   (last?'<div class="rout" data-run="'+esc(t.run_id)+'">'+(typeof outHtml==='function'?outHtml(t.run_id):'')+'</div>':'')}).join('')}
 const sendLabel=state=>state==='running'||state==='queued'?'Add instruction':'Send';
// The text that would be sent, whole: a message is never cut. Over SEND_MAX the composer says so and Send stays off (sendState.tooLong).
const SEND_MAX=2000;
const sendText=raw=>cleanText(raw,Infinity);
const sendState=raw=>{const text=sendText(raw),n=Array.from(text).length;return {text,n,max:SEND_MAX,empty:n===0,tooLong:n>SEND_MAX,ok:n>0&&n<=SEND_MAX}};
const tooLongText=s=>'Too long: '+s.n+' of '+s.max;
const canSend=(raw,sending)=>!sending&&sendState(raw).ok;
const sendBody=(text,run)=>{const b={text:sendText(text)};if(run&&typeof run.run_id==='string'&&RUN_ID_RE.test(run.run_id))b.run_id=run.run_id;return b};
 // server words and statuses become one calm sentence; retry_s adds the wait
const SEND_ERR={'bad text':'That message cannot be sent','unknown run':'That run is gone. Start a new chat','too large':'That message is too long','rate limited':'Too many messages in a row','hermes gateway unreachable':'Hermes is not reachable right now','already active':'That run just ended',
 'gate blocked':'Jev did not approve that message. Nothing was sent','gate unsure':'Jev was not sure about that message. Nothing was sent. Reword it and try again','gate unavailable':'Jev and Clef did not answer. Nothing was sent','route invalid':'The run model setting is not valid. Nothing was sent'};
 function sendErr(j,status){const w=str(isObj(j)&&j.error,60),r=isObj(j)&&num(j.retry_s)!=null?'. Try again in '+Math.ceil(j.retry_s)+' s':'';
  if(SEND_ERR[w])return SEND_ERR[w]+r;
  if(status===429)return 'Too many messages in a row'+r;if(status===413)return SEND_ERR['too large'];
  if(status>=500||(status===0&&!w))return status?'Hermes is not reachable right now':'The deck did not answer';
  return w?w.charAt(0).toUpperCase()+w.slice(1)+r:'The deck did not answer'}
 function sendResult(j,status){
  if(isObj(j)&&j.ok===true&&SEND_MODES.includes(j.mode)&&typeof j.run_id==='string'&&RUN_ID_RE.test(j.run_id))return {ok:true,mode:j.mode,run_id:j.run_id};
  return {ok:false,err:sendErr(j,status)}}
 // Cmd or Ctrl+Enter always sends; on a touch keyboard plain Enter sends too (Shift+Enter is a newline)
 function enterSends(e,coarse){if(!isObj(e)||e.key!=='Enter'||e.isComposing)return false;if(e.ctrlKey||e.metaKey)return true;return !!coarse&&!e.shiftKey&&!e.altKey}
 // the composer grows with its text up to maxRows lines (scrollH includes the vertical padding)
 const growHeight=(scrollH,lineH,padV,maxRows)=>{const cap=lineH*(maxRows||4)+padV;return Math.round(Math.max(lineH+padV,Math.min(num(scrollH)==null?0:scrollH,cap)))};
// The iOS shell (user agent OmarchyDeck/) does not cancel target=_blank: it loads a same-origin _blank link in place and sends an off-origin _blank link to Safari (DeckModel.swift). The deck still drops the attribute on click in the shell, so every link there behaves as a plain one.
 const isDeckShell=ua=>/OmarchyDeck\//.test(String(ua==null?'':ua));
 // iPhone soft keyboard: the layout viewport keeps its full height while the keyboard covers the bottom of it. When the visual
 // viewport is shorter or scrolled, the run window is pinned to it (height and vertical offset); null means it fills the screen.
 const vvFit=(innerH,vvH,vvTop)=>{const ih=num(innerH),h=num(vvH),t=num(vvTop);if(ih==null||h==null||h<=0)return null;
 const top=Math.max(0,Math.round(t==null?0:t));return h>=ih-1&&top===0?null:{height:Math.round(h),top}};
 const dropsTarget=(ua,tag,target)=>isDeckShell(ua)&&String(tag||'').toUpperCase()==='A'&&String(target||'').toLowerCase()==='_blank';
 // ---- v9: Shop tab (GET /api/ecom, written by `python -m shoptrends feed`) ----
 // Summary first. A card shows the headline figure, the change that matters and the best price. Everything else (per-site prices, range, supply,
 // shipping, condition, season, age) is plain lines in a hidden .moreinfo block that the detail sheet shows when the card is tapped. Source ids, table
 // names and raw error text ride in .diag spans, which only the sheet's Details list shows. Unknown is a dash with the reason beside it, never 0.
 const DASH='\u2014',MON=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
 const SITE_STATUS=['ok','blocked','stale','never'];
 const SITE_WORD={ok:'OK',blocked:'Blocked',stale:'Out of date',never:'Never',unknown:'Unknown'};
 const money=v=>{const n=num(v);return n==null?DASH:(n<0?'\u2212$':'$')+Math.abs(n).toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2})};
 const cnt=v=>{const n=num(v);return n==null?DASH:Math.round(n).toLocaleString('en-US')};
 const share=v=>{const n=num(v);return n==null?DASH:Math.round(n*100)+'%'};
 // signed percent from a fraction; the sign follows the rounded figure so "+0.0%" never prints
 const pct=(v,d)=>{const n=num(v);if(n==null)return DASH;const s=(n*100).toFixed(d==null?1:d),z=+s===0;return (z?'':n>0?'+':'\u2212')+s.replace('-','')+'%'};
 const arrow=v=>{const n=num(v);return n==null?'':n>=0.005?'\u25B2':n<=-0.005?'\u25BC':'\u2192'};
 const eAge=(t,now)=>toEpoch(t)==null?'no time':ago(t,now);
 const eStale=(f,now)=>isObj(f)&&!f.error&&(f.stale===true||(genAt(f)!=null&&num(f.refresh)>0&&now/1000-genAt(f)>2*f.refresh));
// ONE timestamp per feed: `generated_at` (FEEDS.md, 2026-10-21), else `t` for an older file. `as_of` is when the data was true: it is named in the same
// line only when it is clearly older than the file, so a panel never says "Updated 1 min ago" over a 23 day old snapshot. A number `as_of` is read as is;
// an object `as_of` ({quotes}, {positions, crypto, prices}, {balances, inventory}) is read at `key`.
const genAt=f=>{const g=isObj(f)?toEpoch(f.generated_at):null;return g!=null?g:isObj(f)?toEpoch(f.t):null};
const asOfAt=(f,key)=>{const a=isObj(f)?f.as_of:null;return toEpoch(isObj(a)?(key?a[key]:null):a)};
// the section freshness line reads like every other panel: Updated 5 min ago, Out of date \u00B7 Updated 2 h ago when the feed is past twice its refresh
const eFresh=(f,now,key)=>{if(!isObj(f)||f.error)return 'Not reporting';
 const g=genAt(f),o=asOfAt(f,key),r=num(f.refresh)>0?f.refresh:3600,lag=g!=null&&o!=null&&g-o>Math.max(900,r)?' \u00B7 data from '+ago(o,now):'';
 return (eStale(f,now)?'Out of date \u00B7 ':'')+(g==null?'Update time unknown':'Updated '+ago(g,now))+lag};
const eHead=(title,f,now,key)=>'<div class="secttl"><span>'+esc(title)+'</span><span>'+esc(eFresh(f,now,key))+'</span></div>';
 // a card that throws is replaced by one error state whose Try again reloads its own page
 const vfail=(t,r)=>empty({k:'bad',title:'Could not show '+str(t,40),line:'Try again. If it keeps happening, reload the deck.',retry:r});
 const eSrc=f=>str(arr(isObj(f)&&f.sources)[0],80).replace(/\s*\(.*$/,'')||'shoptrends';
 const histNote=d=>num(d)==null?'history length unknown':num(d)+' day'+(d==1?'':'s')+' of history so far';
 const siteLabel=s=>str(s&&s.label,24)||str(s&&s.site,24)||'site';
 // text cut at a word with a visible ellipsis, never mid-word (feed titles run to 200 chars)
 const clip=(v,n)=>{const s=typeof v==='string'?v.replace(/[\u0000-\u001f]/g,' ').replace(/\s+/g,' ').trim():'';if(s.length<=n)return s;
  const cut=s.slice(0,n-1),sp=cut.lastIndexOf(' ');return (sp>n*.5?cut.slice(0,sp):cut).replace(/[\s,;:.\-\u2013\u2014]+$/,'')+'\u2026'};
 // short names for the per-site bars (the bar column is narrow); every other site uses the feed's own label
 const SHORT_SITE={'facebook-marketplace':'FB Marketplace'};
 const LOCAL_SITES=['craigslist','offerup','facebook-marketplace'];
 // ctx = {label:{site:label}, kind:{site:kind}} built from coverage.sites; missing entries fall back to the raw site key
 const siteCtx=f=>{const label={},kind={};arr(isObj(f)&&isObj(f.coverage)&&f.coverage.sites).filter(isObj).forEach(s=>{const k=str(s.site,30);if(k){label[k]=str(s.label,24);kind[k]=str(s.kind,16)}});return {label,kind}};
 const shortSite=(k,ctx)=>SHORT_SITE[k]||(ctx&&ctx.label&&ctx.label[k])||k;
 const isLocal=(k,ctx)=>LOCAL_SITES.includes(k)||(ctx&&ctx.kind&&ctx.kind[k]==='local');
 // measured index values (about 1.04) keep two decimals; large series print whole numbers
 const mval=v=>{const n=num(v);return n==null?DASH:Math.abs(n)<100?n.toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2}):cnt(n)};
 const periodWord=p=>{const m=/^(\d{4})-(\d{2})$/.exec(p||'');return m&&MON[+m[2]-1]?MON[+m[2]-1]+' '+m[1]:p||''};
 // the lines the detail sheet shows under a card: one short sentence each, hidden on the card itself
 const MORE=ls=>{const l=ls.filter(Boolean);return l.length?'<span class="moreinfo">'+l.map(x=>'<span>'+esc(x)+'</span>').join('')+'</span>':''};
 const OUTPILL='<span class="pill warn"><i class="sd warn"></i>Out of date</span>';
// ---- Shop facts (2026-10-22). Every figure names its sample size n, site count, age and method (asking or sold). Error cards show a status
// code and the last OK time; file paths and setting names never reach the screen (the collector log has them).
 const ageS=(t,now)=>{const x=toEpoch(t);if(x==null)return 'age unknown';const s=Math.max(0,Math.round(now/1000-x));return s<60?'<1m':s<5400?Math.max(1,Math.round(s/60))+'m':s<172800?Math.round(s/3600)+'h':Math.round(s/86400)+'d'};
 // a figure is stale once it is older than twice its feed's refresh (one hour by default)
 const staleAfter=r=>2*(num(r)>0?r:3600);
 const isOld=(t,now,r)=>{const x=toEpoch(t);return x!=null&&now/1000-x>staleAfter(r)};
 const staleBadge=(t,now,r)=>isOld(t,now,r)?'<span class="pill warn sbadge" data-stale="1"><i class="sd warn"></i>Stale, '+esc(ageS(t,now))+'</span>':'';
 // the method of a watch's prices: the trends database holds asking prices only until a sold source writes `sold`
 const soldN=w=>isObj(w.sold)&&num(w.sold.n)!=null?w.sold.n:0;
 const wMethod=w=>{const m=str(w.method,10);return m==='sold'||m==='mixed'||m==='asking'?m:soldN(w)>0?'mixed':'asking'};
 const METHOD_WORD={asking:'asking',sold:'sold',mixed:'asking and sold'};
 const MIN_N=10;
 // a short status code for a failing source: HTTP status, a Node module error, a timeout. Never the raw reason, which can carry a path.
 function errCode(r){const s=String(r==null?'':r),h=/\b(?:HTTP|status)[ :]*([1-5]\d\d)\b/i.exec(s)||/(?:^|[\s(])([45]\d\d)(?=$|[\s),.])/.exec(s);
  if(h)return 'HTTP '+h[1];
  if(/did not self-register|NODE_MODULE_VERSION|dlopen/i.test(s))return 'ERR_DLOPEN_FAILED';
  if(/time(?:d)?[ _-]?out|too long|no answer in/i.test(s))return 'Timeout';
  if(/missing|no such file|not written/i.test(s))return 'No file';
  if(/bad json|parse error|unexpected token/i.test(s))return 'Bad JSON';
  if(/captcha|bot[- ]?wall|challenge/i.test(s))return 'Bot wall';
  if(/soft block|without a results container/i.test(s))return 'Soft block';
  if(/blocked|\bblock\b|forbidden|access denied|turned us away/i.test(s))return 'Blocked';
  if(/layout|blocks not found|selector/i.test(s))return 'Parse error';
  if(/connector|unavailable/i.test(s))return 'Connector error';
  return s?'Error':'No answer'}
 // the reason for the detail sheet with paths and setting names taken out
 const noPath=r=>String(r==null?'':r).replace(/(?:~|\.{1,2})?\/[\w.@+\-]+(?:\/[\w.@+\-]*)+/g,'[path in log]').replace(/\b[A-Z][A-Z0-9]*_[A-Z0-9_]{2,}\b/g,'[setting]');
 const lastOk=(t,now)=>toEpoch(t)==null?'Last OK: none recorded':'Last OK '+ago(t,now);
 // an empty Shop section: the status code and when the source last answered, never "try again in a moment"
 const shopDown=(title,f,retry,now)=>{const raw=isObj(f)?str(f.error,120):'',lt=isObj(f)?(toEpoch(f.last_ok)!=null?f.last_ok:f.t):null;
  return empty({k:'bad',title:str(title,50)+': '+(isObj(f)?errCode(raw||'error'):'No answer'),line:lastOk(lt,now==null?Date.now():now),retry,diag:[noPath(raw)]})};
 // deal score: a price against the watch's own p25, p50 and p75. low = under p25, mid = p25 to p75, high = over p75.
 function dealScore(price,w){const p=num(price),m=num(w&&w.median);if(p==null||m==null||m<=0)return null;
  const q1=num(w.p25),q3=num(w.p75),vs=(p-m)/m,quart=q1!=null&&q3!=null&&q3>=q1;
  return {vs,quart,band:quart?(p<q1?'low':p>q3?'high':'mid'):(vs<=-0.1?'low':vs>=0.1?'high':'mid')}}
 const BAND_WORD={low:'under p25',mid:'p25 to p75',high:'over p75'};
 // #55: one chip per fact, so a 128 px right cell never cuts a label with an ellipsis (DESIGN 'whole words'). The band chip is a second line.
 const dealChip=d=>d?'<small class="dchip d-'+d.band+'">'+pct(d.vs,0)+' vs p50</small>'+(d.quart?'<small class="dchip q">'+BAND_WORD[d.band]+'</small>':''):'';
 // the lowest offer for a watch across the producer's best (new, shipped) and every listing group (used and local included).
 // A price under 0.3 x the median is a part or a case, not this product (shoptrends price sanity), and is skipped.
 const USED=['used','refurbished','open box','open_box','for parts'];
 function bestAny(w){const c=[],m=num(w&&w.median),sane=p=>m==null||p>=0.3*m;const be=isObj(w&&w.best)?w.best:null;
  if(be&&num(be.price)!=null&&sane(be.price))c.push({price:be.price,site:str(be.site,30),url:be.url,cond:str(be.condition,20).toLowerCase(),from:'best'});
  arr(w&&w.groups).filter(isObj).forEach(g=>{const p=num(g.best_price)!=null?g.best_price:num(g.price);const its=arr(g.items).filter(isObj),lead=its.find(x=>num(x.price)===p)||{};
   if(p!=null&&sane(p))c.push({price:p,site:str(lead.source,30)||str(lead.site,30)||str(g.source,30)||str(g.site,30),url:lead.url||g.url,cond:str(lead.condition,20).toLowerCase()||str(g.condition,20).toLowerCase(),from:'group'})});
  return c.length?c.reduce((a,b)=>b.price<a.price?b:a):null}
 const offerWords=(o,ctx,noSite)=>[noSite?'':shortSite(o.site,ctx)||'site',isLocal(o.site,ctx)?'local pickup':'',USED.includes(o.cond)?o.cond.replace('_',' '):o.cond==='new'?'new':'condition not stated'].filter(Boolean).join(' \u00B7 ');
 // flip = sold p50 - buy price - fees - shipping. Until a sold source has n >= 10 the asking p50 stands in and the figure says so.
 const FEE_RATE=0.1325;
 function flipScore(w,buy){const b=num(buy);if(isObj(w.flip)&&num(w.flip.score)!=null)return {score:w.flip.score,basis:str(w.flip.basis,10)==='sold'?'sold':'asking',n:num(w.flip.n)};
  const sold=isObj(w.sold)&&num(w.sold.median)!=null&&soldN(w)>=MIN_N?w.sold.median:null,ref=sold!=null?sold:num(w.median);if(ref==null||b==null)return null;
  const ship=isObj(w.shipping)&&num(w.shipping.median_cost)!=null?w.shipping.median_cost:0;
  return {score:ref-b-ref*FEE_RATE-ship,basis:sold!=null?'sold':'asking',n:sold!=null?soldN(w):num(w.n),fee:ref*FEE_RATE,ship}}
 const flipWords=f=>f.basis==='sold'?'sold-based, n '+cnt(f.n):'asking-based, low confidence';

// ---- failing sources (FEEDS.md, 2026-10-21): why, when it last worked, when it is tried next, and a copyable retry command only while a manual retry is allowed.
// A site or source without any retry field (an older writer) keeps the earlier wording everywhere below.
const hasRetry=s=>isObj(s)&&(ownKey(s,'next_retry')||ownKey(s,'can_retry'));
const lastWord=(t,now)=>toEpoch(t)==null?'Never worked':'Last worked '+ago(t,now);
const nextWord=(s,now)=>{const n=toEpoch(s&&s.next_retry);
 return n==null?(s&&s.can_retry===true?'Can be retried now':'No retry is scheduled'):n*1000<=now?'Next try on the next collector pass':'Next try '+until(n,now)};
// the deck never runs a collector: when the feed allows a manual retry it hands the owner the exact command to copy (a bot wall is never retried early)
const shq=a=>/^[\w@%+=:,./-]+$/.test(a)?a:"'"+a.replace(/'/g,"'\\''")+"'";
const retryCmd=(can,cmd)=>can===true&&Array.isArray(cmd)&&cmd.length>0&&cmd.length<=8&&cmd.every(x=>typeof x==='string'&&x!=='')?cmd.map(shq).join(' '):'';
const retryBtn=(can,cmd,who)=>{const c=retryCmd(can,cmd);return c?'<span class="rtry"><code class="rcmd">'+esc(c)+'</code><button type="button" class="b cpy" data-cmd="'+esc(c)+'" aria-label="'+esc('Copy the retry command for '+who)+'">Copy retry command</button></span>':''};
// one line per source only the owner can enable (eBay API keys): not a failure, not counted as one. `setup[]` (ecom, listings), else a coverage site's or a source status's own `setup`.
function setupLines(f){const out=[],seen=new Set(),add=(k,l)=>{if(l&&!seen.has(k)){seen.add(k);out.push({src:k,line:l})}};
 arr(isObj(f)&&f.setup).filter(isObj).forEach(x=>add(str(x.source,30),str(x.line,220)));
 arr(isObj(f)&&isObj(f.coverage)&&f.coverage.sites).filter(isObj).forEach(s=>add(str(s.site,30),str(s.setup,220)));
 if(isObj(f)&&isObj(f.source_status))Object.keys(f.source_status).slice(0,24).forEach(k=>{const s=f.source_status[k];if(isObj(s))add(str(k,30),str(s.setup,220))});
 return out}
// "eBay is not set up: it needs the owner's EBAY_CLIENT_ID and EBAY_CLIENT_SECRET (owner step)..." reads "eBay: Needs EBAY_CLIENT_ID and EBAY_CLIENT_SECRET"
const SETUP_LABEL={ebay:'eBay'};
// setting names stay off the screen (2026-10-22): "eBay: API keys not set, owner step"; the names are in the detail sheet's log line only
function setupText(x){const vars=String(x.line).match(/\b[A-Z][A-Z0-9]*_[A-Z0-9_]{2,}\b/g)||[];
 const n=Object.prototype.hasOwnProperty.call(SETUP_LABEL,x.src)?SETUP_LABEL[x.src]:x.src;
 return vars.length||/key/i.test(x.line)?n+': API keys not set, owner step':noPath(x.line)}
const setupNote=(ls,skip)=>ls.filter(x=>!(skip&&skip.has(x.src))).map(x=>'<div class="tnote setup" data-setup="'+esc(x.src)+'">'+esc(setupText(x))+'</div>').join('');
// a site that refuses every automated search (HTTP 403, no manual retry) and has no official API is skipped, not failing: it is
// named once in a muted line and never counted in "N of M answering". A parser break or a stale site is still a real failure.
const SKIP_WORDS='Site blocks automated search, skipped, no official API';
// eBay has an official API (owner keys), so it is a setup step, never "skipped"
const HAS_API=['ebay'];
const isSkipped=s=>isObj(s)&&s.status==='blocked'&&s.can_retry===false&&!HAS_API.includes(str(s.site,30))&&/\b403\b|blocks automated|forbidden|access denied/i.test(str(s.reason,200));
// ecom errors the coverage chips already carry (an error with retry facts for a listed site) are not repeated in the one-line summary
const otherErrors=f=>{const ks=new Set(arr(isObj(f)&&isObj(f.coverage)&&f.coverage.sites).filter(isObj).map(s=>str(s.site,30)));
 return arr(isObj(f)&&f.errors).filter(isObj).filter(e=>!(hasRetry(e)&&ks.has(str(e.source,30))))};

// coverage: four counters, one summary row (tap it for every site), then a chip for each site that needs a look
function siteLine(s,now,isSetup){
 const st=SITE_STATUS.includes(s&&s.status)?s.status:'unknown',n=siteLabel(s),last=s&&s.last_ok;
 if(isSetup)return n+': needs setup, an owner step';
 if(isSkipped(s))return n+': skipped. '+SKIP_WORDS.replace(/, skipped/,'')+'. '+lastWord(last,now);
 if(hasRetry(s)&&(st==='blocked'||st==='stale'))return n+': '+(st==='blocked'?'blocked':'out of date')+', '+errCode(s.reason)+'. '+lastOk(last,now)+'. '+nextWord(s,now);
 return n+': '+(st==='ok'?'answered '+eAge(last,now)+(num(s.n_24h)==null?'':', '+cnt(s.n_24h)+' prices in 24 h'):st==='stale'?'out of date'+(toEpoch(last)==null?'':', last answered '+ago(last,now)):st==='blocked'?'blocked, the site turned us away':st==='never'?'not collected yet':'status not reported')}
// the code beside a Blocked pill never repeats the pill word
const chipCode=(s,st)=>{const c=errCode(s&&s.reason||(st==='blocked'?'blocked':'timeout'));return c==='Blocked'&&st==='blocked'?'No status code':c};
function siteChip(s,now){
 const st=SITE_STATUS.includes(s&&s.status)?s.status:'unknown',reason=str(s&&s.reason,90),last=s&&s.last_ok;
 const cls=st==='blocked'?' bad':st==='never'?' never':st==='ok'?'':' stale';
 const mark=st==='ok'?SD('ok'):st==='blocked'?SD('bad'):st==='never'?'<i class="sd nv"></i>':SD('warn');
 const pc=st==='blocked'?' bad':st==='stale'||st==='unknown'?' warn':'';
 const dg=diagHtml([reason&&('reason: '+noPath(reason)),toEpoch(last)==null?'':'last ok '+ago(last,now),hasRetry(s)?nextWord(s,now):'']),open='<div class="chip cv'+cls+'" data-site="'+esc(str(s&&s.site,30))+'"><b>'+esc(siteLabel(s))+'</b>';
 if(hasRetry(s)&&(st==='blocked'||st==='stale')){
  return open+'<small><span class="pill'+pc+'">'+mark+SITE_WORD[st]+'</span><span class="why">'+esc(chipCode(s,st))+'</span><span>'+esc(lastOk(last,now))+'</span></small>'+retryBtn(s.can_retry,s.retry_cmd,siteLabel(s))+dg+'</div>'}
 const why=st==='ok'?eAge(last,now)+(num(s.n_24h)==null?'':' \u00B7 '+cnt(s.n_24h)+' prices in 24 h'):st==='stale'||st==='blocked'?chipCode(s,st)+' \u00B7 '+lastOk(last,now):st==='never'?'Not collected yet':'Status not reported';
 return open+'<small><span class="pill'+pc+'">'+mark+SITE_WORD[st]+'</span> '+esc(why)+'</small>'+dg+'</div>'}
// {total, ok, failing, waiting, setup, skipped}, counted from the site list (the feed's own summary only when it has no list, since it
// counts skipped sites as failing). `total` is the sites we can actually ask: skipped and setup sites are left out of it.
function covCounts(c,sites,setupSet){
 const s=isObj(c.summary)?c.summary:null,skipped=sites.filter(isSkipped).length;
 if(!sites.length&&s&&num(s.total)!=null&&num(s.ok)!=null)return {total:num(s.total),ok:num(s.ok),failing:num(s.failing)||0,waiting:num(s.waiting)||0,setup:num(s.setup)||0,skipped:0};
 const key=x=>str(x.site,30),isSet=x=>setupSet.has(key(x))&&x.status==='never',live=sites.filter(x=>!isSet(x)&&!isSkipped(x));
 return {total:live.length,ok:live.filter(x=>x.status==='ok').length,failing:live.filter(x=>x.status!=='ok'&&x.status!=='never').length,waiting:live.filter(x=>x.status==='never').length,setup:sites.filter(isSet).length,skipped}}
// skipped sites: one muted line naming them (the summary row's tap sheet carries when each last worked). Never a red tile, never a failure.
function skippedNote(sites){const sk=sites.filter(isSkipped);if(!sk.length)return '';
 return '<div class="tnote skip" data-skipped="'+sk.length+'"><b>'+esc(sk.map(siteLabel).join(', '))+':</b> '+esc(SKIP_WORDS)+'.</div>'}
function coverage(f,now){
 const c=isObj(f.coverage)?f.coverage:null;
 if(!c)return eHead('Coverage',f,now)+tile('Coverage','Unavailable','The feed has no coverage section.','bad');
 const sites=arr(c.sites).filter(isObj),setups=setupLines(f),setupSet=new Set(setups.map(x=>x.src)),isSet=x=>setupSet.has(str(x.site,30))&&x.status==='never';
 const odd=sites.filter(s=>s.status!=='ok'&&!isSet(s)&&!isSkipped(s)),cc=covCounts(c,sites,setupSet);
 const no=(v,why)=>num(v)==null?why:'';
 const k=eStale(f,now)?'stale':'';
 const need=n=>n+(n>1?' need':' needs');
 const look=[cc.failing?need(cc.failing)+' a look':'',cc.waiting?cc.waiting+' not collected yet':'',cc.setup?need(cc.setup)+' setup':'',cc.skipped?cc.skipped+' skipped':''].filter(Boolean).join(' \u00B7 ');
 const sum=sites.length?'<div class="flist ecl"><div class="frow"><span class="fl"><b>'+(cc.total?cc.ok+' of '+cc.total+' sites answering':'No site can be searched')+'</b><small>'+esc(look||'Every site answered')+'</small></span>'+
   MORE(sites.map(s=>siteLine(s,now,isSet(s))).concat(['History: '+(num(c.days)==null?'not reported':cnt(c.days)+(c.days==1?' day':' days'))+(toEpoch(c.since)==null?'':', first prices '+ago(c.since,now))]))+'</div></div>'
  :'<div class="tnote">The feed has no site list.</div>';
 return eHead('Coverage',f,now)+'<div class="mgrid g2">'+
  mini('Sellers',cnt(c.shops),no(c.shops,'none seen yet'),k)+
  mini('Listings',cnt(c.listings),no(c.listings,'nothing collected yet'),k)+
  mini('Prices stored',cnt(c.observations),no(c.observations,'nothing collected yet'),k)+
  mini('History',num(c.days)==null?DASH:num(c.days)+(c.days==1?' day':' days'),num(c.days)==null?'no data yet':'',k)+'</div>'+
  sum+setupNote(setups)+(odd.length?'<div class="fchips cvg">'+odd.map(s=>siteChip(s,now)).join('')+'</div>':'')+skippedNote(sites)}

 // 30 daily medians, oldest first. A null day breaks the line; the returned markup is '' when fewer than two days have a value.
 function spark(a){
  const v=arr(a).slice(-30).map(num),pts=v.filter(x=>x!=null);if(pts.length<2)return '';
  const lo=Math.min(...pts),hi=Math.max(...pts),span=hi-lo,W=120,H=32,P=3,n=v.length;
  const X=i=>(P+(W-2*P)*i/Math.max(1,n-1)).toFixed(1),Y=x=>(span?H-P-(H-2*P)*(x-lo)/span:H/2).toFixed(1);
  let d='',run=0,last=null;
  v.forEach((x,i)=>{if(x==null){run=0;return}d+=(run?'L':'M')+X(i)+' '+Y(x);run++;last=[X(i),Y(x)]});
  // a day whose neighbours are both empty is drawn as a dot, since a one-point line has no length
  v.forEach((x,i)=>{if(x!=null&&(i===0||v[i-1]==null)&&(i===n-1||v[i+1]==null))d+='M'+X(i)+' '+Y(x)+'h0'});
  return '<svg class="spk" viewBox="0 0 '+W+' '+H+'" preserveAspectRatio="none" role="img" aria-label="Daily median price, last '+n+' days"><path d="'+d+'" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round" stroke-linecap="round" vector-effect="non-scaling-stroke"/>'+
   '<path d="M'+last[0]+' '+last[1]+'h0" fill="none" stroke="currentColor" stroke-width="6" stroke-linecap="round" vector-effect="non-scaling-stroke"/></svg>'}
 // season: which month is busiest and which is quietest, from 12 month bars (index mean 1.0): peak solid, low dashed. Recomputed when the feed's own pick is out of range.
 function seasonPick(o){
  const bm=isObj(o)?arr(o.by_month):[],v=bm.map(num);
  if(bm.length!==12||v.every(x=>x==null))return null;
  const vals=v.filter(x=>x!=null),mx=Math.max(...vals),mn=Math.min(...vals);
  const idx=(m,f)=>Number.isInteger(m)&&m>=1&&m<=12&&v[m-1]!=null?m-1:v.indexOf(f);
  return {v,mx,pk:idx(o.peak,mx),lw:idx(o.low,mn)}}
 const seasonWords=o=>{const p=seasonPick(o);return p?'Busiest in '+MON[p.pk]+', quietest in '+MON[p.lw]:''};
 function season(o){
  const p=seasonPick(o);
  if(!p)return '<div class="ssn"><small class="ssc">No seasonal pattern yet</small></div>';
  const H=34,bars=p.v.map((x,i)=>{if(x==null)return '';const h=Math.max(1,x/p.mx*H);
   return '<rect x="'+(i*10+1.5)+'" y="'+(38-h).toFixed(1)+'" width="7" height="'+h.toFixed(1)+'" rx="1" class="sb'+(i===p.pk?' pk':i===p.lw?' lw':'')+'"/>'}).join('');
  const one=(38-1/p.mx*H).toFixed(1);
  return '<div class="ssn"><svg class="ssv" viewBox="0 0 120 38" preserveAspectRatio="none" role="img" aria-label="Typical month, the yearly mean is the dashed line"><path d="M0 '+one+'H120" class="sm" vector-effect="non-scaling-stroke"/>'+bars+'</svg>'+
   '<small class="ssc">'+esc(seasonWords(o))+'</small></div>'}
 const basisWord=b=>/^wikipedia/i.test(b||'')?'Wikipedia pageviews':/^fred/i.test(b||'')?'a FRED economic series':'';

 // one pill per change that exists; when none does, one quiet line says when it will
 function chgs(list,quiet){const ok=list.filter(x=>num(x[1])!=null);
  return ok.length?ok.map(x=>'<span class="chg"><span class="cl">'+esc(x[0])+' '+arrow(x[1])+' '+pct(x[1])+'</span></span>').join(''):'<span class="chg na"><span class="cl">'+esc(quiet)+'</span></span>'}
 // every site with a price, cheapest first, as sentences for the sheet
 function siteLines(w,now,ctx){
  const bs=arr(w.by_site).filter(isObj).slice().sort((a,b)=>(num(a.median)==null)-(num(b.median)==null)||(a.median-b.median)),rows=bs.slice(0,8);
  const out=rows.map(b=>{const k=str(b.site,30),loc=isLocal(k,ctx),m=num(b.median);
   return (shortSite(k,ctx)||'site')+': '+(m==null?'no price':money(m)+' median')+', '+cnt(b.n)+' seen, '+(num(b.free_ship)==null?(loc?'local pickup':'shipping not reported'):share(b.free_ship)+' ship free')+', '+eAge(b.t,now)});
  if(bs.length>rows.length)out.push('and '+(bs.length-rows.length)+' more site'+(bs.length-rows.length>1?'s':''));
  return out}
 function watchCard(w,now,fstale,src,refresh,ctx){
  const q=str(w.query,80)||str(w.slug,60)||'item',hd=num(w.history_days);
  const stale=fstale||(toEpoch(w.t)!=null&&num(refresh)>0&&now/1000-toEpoch(w.t)>2*refresh);
  const sp=spark(w.spark),pts=arr(w.spark).slice(-30).filter(x=>num(x)!=null),days=arr(w.spark).slice(-30).length;
  const sup=isObj(w.supply)?w.supply:null,shp=isObj(w.shipping)?w.shipping:null,cd=isObj(w.condition)?w.condition:null,be=isObj(w.best)?w.best:null;
  const bu=be&&safeUrl(be.url),site=be?shortSite(str(be.site,30),ctx)||'a site':'';
  // Lowest, used and local included (FB Marketplace, OfferUp groups), then the producer's own best when it is a different offer. The vs p50
  // figure is computed from the price and the median when the feed leaves vs_median out, so it never prints a bare dash.
  const lo=bestAny(w),offer=(main,o,lbl,noSite)=>{let r=row(main,offerWords(o,ctx,noSite),'<b>'+money(o.price)+'</b>'+dealChip(dealScore(o.price,w)),'',o.url);
   return safeUrl(o.url)?r.replace(/^<a /,'<a aria-label="'+esc(lbl)+'" '):r};
  let bestRow=lo?offer('Lowest, used and local included',lo,'Open the lowest price, at '+(shortSite(lo.site,ctx)||'a site')+', in a new tab'):'';
  if(be&&num(be.price)!=null&&lo&&lo.from!=='best')bestRow+=offer('Lowest at '+site,{price:be.price,site:str(be.site,30),url:be.url,cond:str(be.condition,20).toLowerCase()},'Open the best price from '+site+' in a new tab',true);
  const fl=flipScore(w,lo?lo.price:null),nn=num(w.n),qv=(k,v)=>num(v)==null?'':k+' '+money(v);
  const cd2=isObj(w.condition)?w.condition:null,usedN=cd2?['used','refurbished','open_box'].reduce((a,k)=>a+(num(cd2[k])||0),0):null;
  const facts='<div class="wc-q" data-facts="1">'+esc(['n '+cnt(nn),qv('p25',w.p25),qv('p50',w.median),qv('p75',w.p75)].filter(Boolean).join(' \u00B7 '))+'</div>'+
   '<div class="wc-q">'+esc(['Asking '+cnt(num(w.asking&&w.asking.n)!=null?w.asking.n:nn),'Sold '+(soldN(w)?cnt(soldN(w)):'0')].concat(cd2?['New '+cnt(cd2.new),'Used '+cnt(usedN)]:[]).join(' \u00B7 '))+'</div>'+
   '<div class="wc-q flip" data-flip="'+(fl?fl.basis:'none')+'">'+esc(fl?'Flip '+money(fl.score)+' \u00B7 '+flipWords(fl):'Flip: needs a p50 and a buy price')+'</div>';
  // near-duplicate listings of this watch (FEEDS.md, 2026-10-21): the three biggest groups; a watch without `groups` shows none
  const grp=groupRows(w,now,k=>shortSite(k,ctx),3);
  const quiet=hd==null?'Trend needs more days of history':hd<8?'Trend after 8 days of history ('+hd+' so far)':'No trend yet';
  const cap=num(w.median)==null?'No priced listings in the newest run':'Median of '+(num(w.n)!=null?cnt(w.n):'n unknown')+' '+METHOD_WORD[wMethod(w)]+(num(w.sites_ok)!=null?', '+cnt(w.sites_ok)+' site'+(w.sites_ok===1?'':'s'):'')+', '+ageS(w.t,now);
  const lowN=num(w.n)!=null&&w.n<MIN_N;
  const young=hd!=null&&hd<2,okSup=x=>!young&&num(x)!=null;
  const L=[];
  if(str(w.category,20))L.push('Category: '+str(w.category,20));
  L.push(num(w.min)!=null&&num(w.max)!=null&&w.max>w.min?'Range '+money(w.min)+' to '+money(w.max)+(num(w.p25)!=null&&num(w.p75)!=null?', middle half '+money(w.p25)+' to '+money(w.p75):''):'Range needs a spread between the lowest and highest price');
  if(pts.length>=2)L.push('30-day trend: low '+money(Math.min(...pts))+', high '+money(Math.max(...pts))+' ('+pts.length+' of '+days+' days priced)');
  L.push(num(w.chg7)==null?'7-day change needs 8 days of history':'7-day change '+pct(w.chg7),num(w.chg30)==null?'30-day change needs 31 days of history':'30-day change '+pct(w.chg30));
  siteLines(w,now,ctx).forEach(x=>L.push(x));
  if(sup)L.push('Supply: '+(num(sup.listings)==null?'size not reported':cnt(sup.listings)+' listings in the sample')+(okSup(sup.new_24h)?', '+cnt(sup.new_24h)+' new in 24 h':'')+(okSup(sup.price_drops_7d)?', '+cnt(sup.price_drops_7d)+' price drops in 7 days':'')+(okSup(sup.new_24h)&&okSup(sup.price_drops_7d)?'':' (new and dropped counts need 2 days of history)'));
  if(shp)L.push('Shipping: '+(num(shp.free_share)==null?'free share not reported':share(shp.free_share)+' ship free')+(num(shp.median_cost)==null?'':', median cost '+money(shp.median_cost))+(num(shp.pickup_only)==null?'':', '+cnt(shp.pickup_only)+' pickup only'));
  if(cd)L.push('Condition: '+[['new',cd.new],['used',cd.used],['refurbished',cd.refurbished],['open box',cd.open_box],['unknown',cd.unknown]].filter(x=>num(x[1])!=null).map(x=>cnt(x[1])+' '+x[0]).join(', '));
  if(be)L.push('Best listing: '+clip(be.title,90)+(str(be.condition,20)?', '+str(be.condition,20):'')+(bu?'':' (no link)'));else L.push('No priced listing in the newest run');
  if(seasonWords(w.season))L.push(seasonWords(w.season)+(basisWord(str(w.season&&w.season.basis,60))?', from '+basisWord(str(w.season.basis,60)):'')+(str(w.season&&w.season.years,16)?', '+str(w.season.years,16):''));
  L.push('Updated '+eAge(w.t,now)+'. '+histNote(hd).replace(/^./,c=>c.toUpperCase())+'.');
  return '<div class="wc'+(stale?' stale':'')+'" data-slug="'+esc(str(w.slug,60))+'">'+
   '<div class="wc-h"><b>'+esc(str(w.query,80)||str(w.slug,60)||'item')+'</b>'+(staleBadge(w.t,now,refresh)||(stale?OUTPILL:''))+'</div>'+
   '<div class="wc-m"><span class="wc-v'+(num(w.median)==null?' na':'')+'">'+money(w.median)+'</span><span class="wc-s">'+esc(cap)+'</span></div>'+
   '<div class="wc-c">'+(lowN?'<span class="chg na"><span class="cl">low n ('+cnt(w.n)+'), change needs '+MIN_N+'</span></span>':chgs([['7 days',w.chg7],['30 days',w.chg30]],quiet))+'</div>'+
   (sp?'<div class="wc-sp">'+sp+'</div>':'')+facts+
   (bestRow?'<div class="flist wcb">'+bestRow+'</div>':'')+(grp?'<div class="flist wcb wcg">'+grp+'</div>':'')+MORE(L)+diagHtml(['source: '+src,str(w.season&&w.season.basis,60)&&'season basis: '+str(w.season.basis,60)])+'</div>'}
 function movers(f,now){
  // the 7-day change shows only with n >= 10 (the mover's own n, else its watch's); a stale watch is greyed and says how old it is
  const ms=arr(f.movers).filter(isObj),by={};arr(f.watch).filter(isObj).forEach(w=>{by[str(w.slug,60)]=w});
  return eHead('Movers',f,now)+'<div class="flist ecl">'+(ms.length?ms.map(m=>{const c=num(m.chg7),w=by[str(m.slug,60)]||{},n=num(m.n)!=null?m.n:num(w.n),ok=n!=null&&n>=MIN_N;
   const old=eStale(f,now)||isOld(w.t,now,f.refresh);
   return row(str(m.query,80)||str(m.slug,60)||'item',old?'Stale, '+ageS(w.t!=null?w.t:genAt(f),now):'n '+cnt(n)+', '+ageS(w.t!=null?w.t:genAt(f),now),
    ok?'<b>'+arrow(c)+' '+pct(c)+'</b><small>7 days</small>':'<b>low n</b><small>needs n '+MIN_N+'</small>',old?'stl':'')}).join('')
   :'<div class="frow"><span class="fl"><b>No movers yet</b><small>Prices need 8 days of history to compare.</small></span></div>')+'</div>'}
 function deals(f,now){
  const ds=arr(f.deals).filter(isObj),ctx=siteCtx(f);
  return eHead('Deals',f,now)+'<div class="flist ecl">'+(ds.length?ds.map(d=>
   row(money(d.price)+' at '+(shortSite(str(d.site,30),ctx)||'a site'),clip(d.title,56),'<b>'+pct(d.vs_median,0)+'</b><small>vs median</small>','',d.url)).join('')
   :'<div class="frow"><span class="fl"><b>No deals yet</b><small>A deal is a new listing priced well under its median.</small></span></div>')+'</div>'}
 // ---- Amazon (GET /api/amazon, read from the shop database, never written): the best Amazon price per watched search, its 7 and 30
 // day change, the 30 day line of the lowest Amazon price per day, price drops and the deal list. A link opens the public product page
 // on www.amazon.com in a new tab and nothing else; nothing here signs in, buys or adds to a cart.
 const amzUrl=u=>typeof u==='string'&&/^https:\/\/www\.amazon\.com\/[^\s"'<>\\]*$/.test(u)&&u.length<=300?u:'';
 const amzDrop=i=>i.dropped===true||num(i.below_avg)!=null;
 function amzRow(i,now,q){const u=amzUrl(i.url),t=clip(i.title,70)||'Amazon item',bits=[];
  if(i.dropped===true&&num(i.prev)!=null)bits.push('was '+money(i.prev));
  if(num(i.below_avg)!=null)bits.push(pct(-i.below_avg,0)+' vs 7 day average');
  if(i.low30===true)bits.push('30 day low');
  const range=num(i.min30)!=null&&num(i.max30)!=null&&i.max30>i.min30?'30 days '+money(i.min30)+' to '+money(i.max30):'';
  const sub=[q||'',bits.join(' \u00B7 ')||range,toEpoch(i.seen)==null?'':'seen '+ago(i.seen,now)].filter(Boolean).join(' \u00B7 ');
  return row(t,sub,'<b>'+money(i.price)+'</b>'+(amzDrop(i)?'<small class="amzd">Price drop</small>':'<small>Amazon</small>'),'',u,u?' aria-label="'+esc('Open '+t+' on Amazon in a new tab')+'"':'')}
 function amzCard(w,now,fstale){
  const q=str(w.query,80)||str(w.slug,60)||'item',b=isObj(w.best)?w.best:null,items=arr(w.items).filter(isObj),sp=spark(w.line),dd=num(w.days),n=num(w.offers)||0,dr=num(w.drops)||0;
  const cap=b?'Best of '+cnt(n)+' Amazon offer'+(n===1?'':'s'):'No current Amazon offer';
  const quiet=dd==null||dd<8?'Change after 8 days of Amazon prices'+(dd?' ('+dd+' so far)':''):'No change yet';
  return '<div class="wc amz'+(fstale?' stale':'')+'" data-amz="'+esc(str(w.slug,60))+'"><div class="wc-h"><b>'+esc(q)+'</b>'+(dr?'<span class="pill">'+SD('ok')+cnt(dr)+(dr===1?' drop':' drops')+'</span>':'')+(fstale?OUTPILL:'')+'</div>'+
   '<div class="wc-m"><span class="wc-v'+(b?'':' na')+'">'+(b?money(b.price):DASH)+'</span><span class="wc-s">'+esc(cap)+'</span></div>'+
   '<div class="wc-c">'+chgs([['7 days',w.chg7],['30 days',w.chg30]],quiet)+'</div>'+(sp?'<div class="wc-sp">'+sp+'</div>':'')+
   (items.length?'<div class="flist wcb">'+items.map(i=>amzRow(i,now)).join('')+'</div>':'')+
   MORE([num(w.low30)!=null?'Lowest Amazon price in 30 days: '+money(w.low30):'',dd!=null?cnt(dd)+(dd===1?' day':' days')+' of Amazon prices':'','Links open the product page on Amazon. Nothing here buys or adds to a cart.'])+'</div>'}
 // limit = how many Amazon search cards open (Show more adds SHOP_STEP); no limit shows every card
 function amazon(a,now,limit){
  if(!isObj(a)||a.error)return eHead('Amazon',a,now)+shopDown('Amazon prices',a,'shop',now);
  const ws=arr(a.watch).filter(isObj),ds=arr(a.deals).filter(isObj),st=eStale(a,now),drops=ws.reduce((s,w)=>s+(num(w.drops)||0),0),shown=limit==null?ws:ws.slice(0,limit);
  const lead=ws.length?(drops?cnt(drops)+' price drop'+(drops===1?'':'s'):'No price drops right now')+' across '+cnt(ws.length)+' watched searches':'';
  const deal='<div class="flist ecl amzdeals">'+(ds.length?ds.map(d=>amzRow(d,now,str(d.query,40))).join('')
   :'<div class="frow"><span class="fl"><b>No Amazon price drops right now</b><small>'+esc(str(a.drop_rule,160)||'A drop is a price well under its own 7 day average.')+'</small></span></div>')+'</div>';
  return eHead('Amazon',a,now)+(lead?'<div class="tnote">'+esc(lead)+'</div>':'')+deal+
   (ws.length?shown.map(w=>{try{return amzCard(w,now,st)}catch(e){return vfail(str(w.query,30)||'Amazon','shop')}}).join(''):tile('Amazon','No prices yet','No Amazon price has been collected for a watched search yet.','stale'))+
   (limit!=null&&ws.length>shown.length?moreBtn('shop-amz','Show '+Math.min(SHOP_STEP,ws.length-shown.length)+' more Amazon searches'):'')+(limit!=null&&shown.length>SHOP_AMZ?fewerBtn('shop-amz'):'')}
 function macroCard(m,now,fstale){
  const l=isObj(m.latest)?m.latest:null,have=!!l&&num(l.value)!=null;
  return '<div class="wc mc'+(fstale?' stale':'')+'"><div class="wc-h"><b>'+esc(str(m.label,100)||'Series')+'</b>'+(fstale?OUTPILL:'')+'</div>'+
   '<div class="wc-m"><span class="wc-v'+(have?'':' na')+'">'+(have?mval(l.value):DASH)+'</span><span class="wc-s">'+esc([str(m.unit,30),l?periodWord(str(l.period,12)):''].filter(Boolean).join(' \u00B7 ')||'No reading yet')+'</span></div>'+
   '<div class="wc-c">'+chgs([['vs last year',m.yoy]],'Needs a full year of history')+'</div>'+
   season({by_month:m.by_month,peak:m.peak,low:m.low})+
   MORE(['Updated '+eAge(m.t,now),basisWord(str(m.src,60))?'From '+basisWord(str(m.src,60))+(str(m.years,16)?', '+str(m.years,16):''):str(m.years,16)?'Years: '+str(m.years,16):''])+diagHtml([str(m.src,60)&&'source: '+str(m.src,60)])+'</div>'}
const LISTING_LABEL={'facebook-marketplace':'Facebook Marketplace',offerup:'OfferUp',ebay:'eBay',amazon:'Amazon',walmart:'Walmart'};
// a failed source never shows a count: its own line says why. "Last worked" is the source's own last good search (feed sources[].last_ok_at), never the feed's write time;
// older feeds without sources fall back to the feed age. Plain words for two known causes: eBay needs the owner's keys; "blocked by the site" only when the reason itself
// says so (blocked, captcha, bot wall, challenge, forbidden, 403). A generic connector error is never called a block: it reads "search failed".
// A source the feed lists under `setup` (or whose status carries a `setup` line) is not a failure: it is the one setup line, never a failing row.
function listingFails(f,setupSrc){const ss=isObj(f.source_status)?f.source_status:{};
 return arr(f.errors).filter(isObj).slice(0,8).filter(e=>!(setupSrc&&setupSrc.has(str(e.source,40)))).map(e=>{const src=str(e.source,40),reason=str(e.reason,120),label=Object.prototype.hasOwnProperty.call(LISTING_LABEL,src)?LISTING_LABEL[src]:'Source',k=/needs (.+?) API keys/i.exec(reason),blocked=/\b(blocked|captcha|bot[- ]?wall|challenge|forbidden|403|access denied)\b/i.test(reason);
 return {src,reason,label,blocked,st:Object.prototype.hasOwnProperty.call(ss,src)&&isObj(ss[src])?ss[src]:null,line:label+': '+(k?'needs '+k[1]+' API keys (owner)':blocked?'blocked by the site, retried hourly':'search failed, retried hourly')}})}
const listingSrc=(f,k)=>isObj(f.source_status)&&Object.prototype.hasOwnProperty.call(f.source_status,k)&&isObj(f.source_status[k])?f.source_status[k]:null;
function listingFailRows(fails,f,now){return fails.length?'<div class="flist">'+fails.map(x=>{const s=listingSrc(f,x.src);
  if(hasRetry(s)){const code=errCode(x.reason||(x.blocked?'blocked':''));
   return '<div class="frow err fail" data-source="'+esc(x.src)+'"><span class="fl"><b>'+esc(x.label+': '+(x.blocked?'blocked by the site':'search failed'))+'</b><small>'+esc(code+' \u00B7 '+lastOk(s.last_ok_at,now))+'</small></span>'+
    retryBtn(s.can_retry,s.retry_cmd,x.label)+diagHtml([noPath(x.reason),nextWord(s,now)])+'</div>'}
  const sub=s?(toEpoch(s.last_ok_at)!=null?'Last worked '+ago(s.last_ok_at,now):'Never worked'):'Checked '+ago(f.t,now);
  return '<div class="frow err"><span class="fl"><b>'+esc(x.line)+'</b><small>'+esc(sub)+'</small></span>'+diagHtml([noPath(x.reason)])+'</div>'}).join('')+'</div>':''}
// Posted = the seller's own post time (can be weeks old). Seen = the last search that returned the link: it is search presence, not proof the item is still for sale.
function listingWhen(x,now){const p=toEpoch(x.posted_at)!=null?'Posted '+ago(x.posted_at,now):'',s=toEpoch(x.last_seen)!=null?x.last_seen:x.first_seen,
  seen=toEpoch(s)!=null?(x.seen_this_run===false?'last seen ':'seen ')+ago(s,now):'';
 return p&&seen?p+' \u00B7 '+seen:p||(seen?seen.charAt(0).toUpperCase()+seen.slice(1):'Age unknown')}
// near-duplicate listings as ONE row (FEEDS.md, 2026-10-21): the lowest priced member leads, a count badge says how many, the range runs from the best to the highest
// price. A group of one is a plain row; a bigger one is a native disclosure (no script) that opens to its members, each with its own link.
// Prices in a group are the writer's own: a row in another currency never reaches the file with a price.
const groupRange=g=>{const lo=num(g.best_price)!=null?g.best_price:g.price,hi=g.max_price;return num(lo)==null?DASH:num(hi)!=null&&hi>lo?money(lo)+' \u2013 '+money(hi):money(lo)};
function groupRow(g,now,label){
 const gl=k=>label(str(k,30))||str(k,30)||'a shop',n=Math.max(1,Math.round(num(g.count)||1)),site=str(g.source,30)||str(g.site,30),
  its=arr(g.items).filter(isObj).slice(0,5),sites=arr(g.sites).map(x=>str(x,30)).filter(Boolean),title=clip(g.title,75)||'Listing';
 if(n<2)return row(title,gl(site),'<b>'+groupRange(g)+'</b>','',g.url);
 const left=n-its.length,where=(sites.length?sites:[site]).filter(Boolean).map(gl).join(', ');
 return '<details class="lgrp" data-count="'+n+'"><summary class="frow"><span class="fl"><b>'+esc(title)+'</b><small>'+esc(n+' listings'+(where?' \u00B7 '+where:''))+'</small></span><span class="fr"><span class="pill gct" aria-label="'+n+' listings">\u00D7'+n+'</span></span>'+
  '<span class="fr"><b>'+groupRange(g)+'</b><small>lowest to highest</small></span></summary><div class="flist lgi">'+
  its.map(x=>row(clip(x.title,70)||'Listing',gl(str(x.source,30)||str(x.site,30)),'<b>'+money(x.price)+'</b>','',x.url)).join('')+
  (left>0?'<div class="frow err"><span>and '+left+' more not shown</span></div>':'')+'</div></details>'}
function groupRows(f,now,label,max){
 const gs=arr(f.groups).filter(isObj),total=num(f.groups_total);if(!gs.length)return '';
 return gs.slice(0,max).map(g=>groupRow(g,now,label)).join('')+(total!=null&&total>Math.min(gs.length,max)?'<div class="frow err"><span>Showing the '+Math.min(gs.length,max)+' biggest of '+total+' groups</span></div>':'')}
// limit = how many listing rows open (Show more adds SHOP_STEP); no limit keeps the plain 24
function listings(f,now,skipSetup,limit){
  if(!isObj(f)||f.error)return eHead('Listings',f,now)+shopDown('Listings',f,'shop',now);
  const cap=num(limit)==null?24:Math.max(4,Math.min(24,Math.round(limit))),all=arr(f.listings).filter(isObj);
  const counts=isObj(f.counts)?f.counts:{},items=all.slice(0,cap);
  const setups=setupLines(f),setupSrc=new Set(setups.map(x=>x.src));
  const fails=listingFails(f,setupSrc),failed=new Set(fails.map(x=>x.src).concat([...setupSrc])),latest=isObj(f.counts_this_run)?f.counts_this_run:null;
  const line=(c,mask)=>Object.keys(LISTING_LABEL).map(k=>LISTING_LABEL[k]+' '+((mask&&failed.has(k))||num(c[k])==null?DASH:cnt(c[k]))).join(' \u00B7 ');
  const totals=latest?'Latest search: '+line(latest,true):line(counts,true),kept=latest?'<div class="tnote">Kept 24 h, earlier searches included: '+esc(line(counts,false))+'</div>':'';
  const grouped=arr(f.groups).some(isObj),total=grouped?(num(f.groups_total)!=null?f.groups_total:arr(f.groups).filter(isObj).length):all.length;
  const rows=grouped?groupRows(f,now,k=>Object.prototype.hasOwnProperty.call(LISTING_LABEL,k)?LISTING_LABEL[k]:'',cap):items.map(x=>{
   const src=str(x.source,40),site=Object.prototype.hasOwnProperty.call(LISTING_LABEL,src)?LISTING_LABEL[src]:'Shop';
   const cost=x.currency==='USD'?money(x.price):DASH;
   return row(clip(x.title,75),site+' \u00B7 '+listingWhen(x,now),'<b>'+cost+'</b>','',x.url);
  }).join('');
  return eHead('Listings',f,now)+'<div class="tnote">'+esc(totals)+'</div>'+kept+listingFailRows(fails,f,now)+setupNote(setups,skipSetup)+'<div class="flist ecl">'+
   (rows||'<div class="frow"><span class="fl"><b>No listings yet</b><small>Public searches have not returned listings.</small></span></div>')+'</div>'+
   (limit!=null&&total>cap?moreBtn('shop-lst','Show '+Math.min(SHOP_STEP,total-cap)+' more listings'):'')+(limit!=null&&cap>SHOP_LIST?fewerBtn('shop-lst'):'');
 }
// [coverage + movers + deals + listings + macro, watch cards (first half), Amazon + watch cards (second half)]. app markup: #sh1 #sh2 #sh3.
// Macro closes column 1 on the Pixel (it is the shortest column); portrait keeps Watchlist before Macro with CSS order (see #shop in index.html).
// `a` is /api/amazon; a caller that passes none gets no Amazon section.
// view = {watch, amz} (the page glue) opens the long lists short: SHOP_WATCH watch cards (split over the two columns) and SHOP_AMZ Amazon cards; Show more adds SHOP_STEP.
// No view (older callers, tests) shows every card.
const SHOP_WATCH=4,SHOP_AMZ=3,SHOP_LIST=6,SHOP_STEP=6;
function shop(f,now,l,a,view){
 const vw=isObj(view)?{watch:Math.max(SHOP_WATCH,num(view.watch)==null?SHOP_WATCH:Math.round(view.watch)),amz:Math.max(SHOP_AMZ,num(view.amz)==null?SHOP_AMZ:Math.round(view.amz)),lst:Math.max(SHOP_LIST,num(view.lst)==null?SHOP_LIST:Math.round(view.lst))}:null;
 const amz=a===undefined?'':'<div class="shamz">'+(()=>{try{return amazon(a,now,vw?vw.amz:undefined)}catch(e){return vfail('Amazon','shop')}})()+'</div>';
 if(!isObj(f)||f.error)return [eHead('Shop trends',f,now)+shopDown('Shop trends',f,'shop',now)+listings(l,now),amz,''];
  const part=(fn,t)=>{try{return fn()}catch(e){return vfail(t,'shop')}};
  const fs=eStale(f,now),src=eSrc(f),all=arr(f.watch).filter(isObj),ws=vw?all.slice(0,vw.watch):all,half=Math.ceil(ws.length/2),mac=arr(f.macro).filter(isObj);
  const ctx=siteCtx(f);
  const cards=list=>list.map(w=>part(()=>watchCard(w,now,fs,src,f.refresh,ctx),str(w.query,30)||'watch')).join('');
  const macro=eHead('Macro',f,now)+(mac.length?mac.map(m=>part(()=>macroCard(m,now,fs),'Macro')).join(''):tile('Macro','None','The feed has no macro series.','stale'));
  const col1='<div class="shg">'+part(()=>coverage(f,now),'Coverage')+(otherErrors(f).length?'<div class="ecerr">'+errRows({errors:otherErrors(f)})+'</div>':'')+part(()=>movers(f,now),'Movers')+part(()=>deals(f,now),'Deals')+part(()=>listings(l,now,new Set(setupLines(f).map(x=>x.src)),vw?vw.lst:undefined),'Listings')+'</div><div class="shmac">'+macro+'</div>';
  const col2=eHead('Watchlist',f,now)+(ws.length?cards(ws.slice(0,half)):tile('Watchlist','None','The feed has no watch entries.','stale'));
  const col3=amz+(ws.length>half?'<div class="shcont">'+eHead('Watchlist (continued)',f,now)+'</div>'+cards(ws.slice(half)):'')+
   (vw&&all.length>ws.length?moreBtn('shop-watch','Show '+Math.min(SHOP_STEP,all.length-ws.length)+' more watched items'):'')+(vw&&ws.length>SHOP_WATCH?fewerBtn('shop-watch'):'');
  return [col1,col2,col3]}

 // ---- Commerce tab. GET /api/commerce = Amazon rows of the purchases ledger (title, date, return_by, amount) and the mail-check state.
 // Tiles open read-only pages on the chosen computer (POST /api/launch?v=<name>); the deck never orders, returns or changes an account.
 // Commerce Ink is an Amazon agency client (unpaid pilot). Tanner has no Seller Central access, so there is no seller tile.
 const CM_TILES={amazon:[['amazon-orders','Your orders','Amazon web app'],['amazon-returns','Returns','Return or replace items']],
  ink:[['commerce-ink-dashboard','Operator dashboard','Local build, pc-desktop only'],['commerce-ink','commerceink.com','Their public site']]};
 const CM_PHONE=[['https://www.amazon.com/your-orders/orders','Orders'],['https://www.amazon.com/gp/css/returns/homepage.html','Returns']];
 const cmTile=t=>'<button type="button" class="b cmt" data-cm="'+esc(t[0])+'"><b>'+esc(t[1])+'</b><small>'+esc(t[2])+'</small></button>';
 const cmDay=d=>{const x=new Date(d+'T00:00:00Z');return isFinite(x)?x.toLocaleDateString('en-US',{weekday:'short',month:'short',day:'numeric',timeZone:'UTC'}):d};
 // whole days from today in Pacific time to the return date; negative once the window has closed
 function daysLeft(d,now){if(typeof d!=='string'||!/^\d{4}-\d{2}-\d{2}$/.test(d))return null;
  const today=new Date(now).toLocaleDateString('en-CA',{timeZone:DUE_TZ}),a=Date.parse(today+'T00:00:00Z'),b=Date.parse(d+'T00:00:00Z');
  return isFinite(a)&&isFinite(b)?Math.round((b-a)/86400000):null}
 function returnWord(n){return n==null?{w:'Date unknown',k:'stale'}:n<0?{w:'Window closed',k:'bad'}:n===0?{w:'Last day today',k:'bad'}:{w:n+(n===1?' day':' days')+' left',k:n<=7?'stale':''}}
 function orderRow(o,now,rev){const t=clip(str(o.title,100),70)||'Amazon order',when=o.date?'Delivered '+cmDay(o.date):'Date not recorded';
  if(o.return_by){const r=returnWord(daysLeft(o.return_by,now));
   return row(t,when+' \u00B7 return by '+cmDay(o.return_by),'<span class="pill'+(r.k==='bad'?' bad':r.k?' warn':'')+'">'+esc(r.w)+'</span>',r.k==='bad'?'err':'')}
  // an amount shows only while the owner has tapped Reveal (`rev`); otherwise a grey mask, the same as the Money tab
  return row(t,when+' \u00B7 return window not recorded',num(o.amount)==null?'':rev?'<b>'+money(o.amount)+'</b>':'<span class="fmk" role="img" aria-label="amount hidden"></span>')}
 // Reveal / Hide control for the order amounts; absent when no listed order carries one
 function cmReveal(os,rev){if(!os.some(o=>!o.return_by&&num(o.amount)!=null))return '';
  return rev?'<button type="button" class="b cmr" data-rev="0" aria-label="Hide order amounts">Hide</button>':'<button type="button" class="b cmr" data-rev="1" aria-label="Reveal order amounts">Reveal</button>'}
 // c = GET /api/commerce (owner cookie, same-origin only); rev = true only for FIN_HIDE_MS after a Reveal tap
 function commerce(c,now,host,rev){
  const on=host==='Dell'?'Dell':'PC';
  const col1='<div class="secttl"><span>Amazon</span><span>Opens on '+esc(on)+'</span></div><div class="cmg">'+CM_TILES.amazon.map(cmTile).join('')+'</div>'+
   '<div class="cmph"><small>On this phone</small>'+CM_PHONE.map(p=>'<a class="b open" href="'+esc(p[0])+'" target="_blank" rel="noopener noreferrer">'+esc(p[1])+'</a>').join('')+'</div>'+
   '<div class="tnote">Read-only. The deck opens pages. It never orders, returns or changes the account.</div>';
  const col3='<div class="secttl"><span>Commerce Ink</span><span>Opens on '+esc(on)+'</span></div><div class="cmg">'+CM_TILES.ink.map(cmTile).join('')+'</div>'+
   '<div class="tnote">Commerce Ink is an Amazon agency client on an unpaid pilot. Their Seller Central stays theirs; this deck has no seller access.</div>';
  if(!isObj(c)||c.error)return [col1,'<div class="secttl"><span>Returns and orders</span><span>Not reporting</span></div>'+down('Amazon orders',c,'commerce'),col3];
  const os=arr(c.orders).filter(isObj),open=os.filter(o=>o.return_by),rest=os.filter(o=>!o.return_by);
  const mon=isObj(c.monitor)?c.monitor:null,paused=!!mon&&mon.state==='paused',ranAt=toEpoch(mon&&mon.last_run_at);
  const checked=toEpoch(c.checked),head='<div class="secttl"><span>Return deadlines</span><span>'+(paused?'<span class="pill warn">'+SD('warn')+'Paused by you</span> \u00B7 '+esc(ranAt==null?'never ran':'last ran '+ago(ranAt,now)):esc((c.stale?'Out of date \u00B7 ':'')+(checked==null?'Mail never checked':'Mail checked '+ago(checked,now))))+'</span></div>'+
   (paused?'<div class="tnote">The purchase monitor is paused in Hermes crons.</div>':'');
  const bad=arr(c.pulls).filter(p=>isObj(p)&&p.ok!==true);
  const pullNote=bad.length?'<div class="ecerr"><div class="frow err"><span>Mail check failed for '+esc(bad.map(p=>str(p.account,30)||'a mailbox').join(', '))+': '+esc(str(bad[0].error,80)||'no reason given')+'. New orders will not show until it works.</span></div></div>':'';
  const list=(rs,none)=>'<div class="flist">'+(rs.length?rs.map(o=>orderRow(o,now,!!rev)).join(''):'<div class="frow"><span class="fl"><b>'+esc(none)+'</b></span></div>')+'</div>';
  const more=num(c.total)>os.length?'<div class="tnote">'+esc((c.total-os.length)+' older Amazon orders not shown')+'</div>':'';
  const col2=head+pullNote+list(open,'No open return windows')+'<div class="secttl"><span>Other Amazon orders</span><span>'+esc(String(rest.length))+cmReveal(rest,!!rev)+'</span></div>'+list(rest,'None recorded')+more;
  return [col1,col2,col3]}

 // ---- v9: Money tab. GET /api/finance = ids, kinds, routes, statuses, ages and counts (no amounts, ever).
 // GET /api/finance-values = the amounts, requested only when the owner taps Reveal. `fin` never reads apps[].values or totals from the
 // sanitised feed (a feed that carries them anyway is ignored); amounts are drawn only from `rev`, the view of `finCtl`, which is the
 // one place that holds them. Hidden by default, 30 s auto-hide, dropped from state on hide. Nothing here touches a URL or storage.
 const FIN_KINDS=['bank','brokerage','crypto','payments','wallet','networth','tax','shopping','receipts','other'];
 const FIN_LABEL={bank:'Bank',brokerage:'Brokerage',crypto:'Crypto',payments:'Payments',wallet:'Wallet',networth:'Net worth',tax:'Tax',shopping:'Shopping',receipts:'Receipts',other:'Other'};
 const FIN_ROUTES=['iphone_screen','api','none'];
 const FIN_ROUTE={iphone_screen:'iPhone screen',api:'API',none:'no route'};
 const FIN_STATUS=['never','ok','stale','needs_owner','needs_unlock','blocked'];
 const FIN_WORD={never:'Never',ok:'OK',stale:'Out of date',needs_owner:'Needs you',needs_unlock:'Needs unlock',blocked:'Blocked',unknown:'Unknown'};
const FIN_WHY={never:'Not captured yet',stale:'Capture is old',needs_owner:'Needs you at the phone',needs_unlock:'The phone is locked',blocked:'The app blocked the read',unknown:'Status not reported'};
 const FIN_HIDE_MS=30000,FIN_FOLD_MIN=20;
 const ownKey=(o,k)=>o!=null&&typeof o==='object'&&Object.prototype.hasOwnProperty.call(o,k);
 const finKind=a=>FIN_KINDS.includes(a&&a.kind)?a.kind:'other';
 const finLabel=a=>{try{return str(a.name,30)||'app'}catch(e){return 'app'}};
 const fHead=eHead;
 const finMark=st=>st==='ok'?SD('ok'):st==='blocked'?SD('bad'):st==='never'?'<i class="sd nv"></i>':SD('warn');
 const fcdText=(exp,now)=>'hides in '+Math.max(0,Math.ceil((exp-now)/1000))+' s';
 const fcd=(rev,key,now)=>rev&&ownKey(rev.exp,key)&&num(rev.exp[key])!=null?'<div class="fcd" data-exp="'+Math.round(rev.exp[key])+'">'+fcdText(rev.exp[key],now)+'</div>':'';
// one app of the sanitised feed: status as the writer reported it, out of date when the last good capture is older than 2x refresh.
// `why` is the writer's own reason an app is not ok (apps[].reason, 2026-10-21); an older file has none and the card keeps FIN_WHY.
function finApp(a,f,now){
 const id=str(a.id,40),t=toEpoch(a.last_ok);
 let st=FIN_STATUS.includes(a.status)?a.status:'unknown',down=false;
 if(st==='ok'&&t!=null&&num(f.refresh)>0&&now/1000-t>2*f.refresh){st='stale';down=true}
 return {id,name:str(a.name,48)||id||'app',kind:finKind(a),route:FIN_ROUTES.includes(a.route)?a.route:'none',st,t,has:a.has_values===true,why:str(a.reason,160),down}}
 // the amounts of one revealed app: balance, as-of time and up to six labelled items
 function finVals(v,now,stale){
  const bal=num(v.balance_usd),it=arr(v.items).filter(isObj),shown=it.slice(0,6);
  return '<span class="fva'+(bal==null?' na':'')+'">'+money(bal)+'</span><small>'+(stale?'Out of date \u00B7 ':'')+(bal==null?'balance not captured \u00B7 ':'')+'as of '+(toEpoch(v.as_of)==null?'no time':ago(v.as_of,now))+'</small>'+
   (shown.length?'<div class="fai">'+shown.map(i=>'<span>'+esc(str(i.label,24)||'item')+'</span><b>'+money(i.usd)+'</b>').join('')+(it.length>6?'<span class="fax">+'+(it.length-6)+' more not shown</span>':'')+'</div>':'')}
function finCard(a,f,now,rev,fstale){
  const m=finApp(a,f,now),shown=!!rev&&ownKey(rev.apps,m.id),vals=shown&&isObj(rev.apps[m.id])?rev.apps[m.id]:null;
  const cls=(m.st==='ok'?'':m.st==='never'?' never':m.st==='blocked'?' bad':' stale')+(fstale?' fs':'');
  const pc=m.st==='blocked'?' bad':m.st==='ok'||m.st==='never'?'':' warn';
  const line=m.st==='ok'?[eAge(m.t,now),FIN_ROUTE[m.route]].join(' \u00B7 ')+(m.has?'':' \u00B7 nothing to reveal'):m.st==='never'?(m.why||FIN_WHY.never):(m.why||FIN_WHY[m.st])+' \u00B7 '+(m.t==null?'never captured':'last ok '+eAge(m.t,now));
  const nm=esc(m.name);
  let v='';
  if(shown)v='<div class="fa-r"><div class="fa-rv">'+(vals?finVals(vals,now,fstale):'<span class="fva na">\u2014</span><small>The amounts are no longer in the file</small>')+'</div>'+
   '<button class="b fh" data-app="'+esc(m.id)+'" aria-label="Hide '+nm+'">Hide</button></div>'+fcd(rev,m.id,now);
  else if(m.has)v='<div class="fa-v"><span class="fmk" role="img" aria-label="value hidden"></span><button class="b fr" data-app="'+esc(m.id)+'" aria-label="Reveal '+nm+'"'+(rev&&rev.busy?' disabled':'')+'>Reveal</button></div>';
  // the group heading above already names the kind and the status line names the route once: the card carries neither a kind pill nor a route pill.
  // No sheet lines here: revealed amounts must never be copied into a detail sheet that outlives the 30 s hide.
  return '<div class="fa'+cls+'" data-app="'+esc(m.id)+'"><div class="fa-h"><b>'+nm+'</b><span class="pill st'+pc+'">'+finMark(m.st)+FIN_WORD[m.st]+'</span></div>'+
   '<div class="fa-s"><small>'+esc(line)+'</small></div>'+v+'</div>'}
function finTotal(f,now,rev,ms){
  const have=ms.filter(m=>m.has).length,shown=!!rev&&rev.totals!==undefined,t=shown&&isObj(rev.totals)?rev.totals:null,any=!!rev&&isObj(rev.exp)&&Object.keys(rev.exp).length>0;
  let val,sub;
  if(shown){val=t&&num(t.net_usd)!=null?'<span class="fva">'+money(t.net_usd)+'</span>':'<span class="fva na">\u2014</span>';sub=t?(num(t.net_usd)==null?'The file has no net figure.':''):'The file has no total.'}
  else if(f.has_totals===true){val='<span class="fmk big" role="img" aria-label="total hidden"></span>';sub=''}
  else{val='<span class="fva na">\u2014</span>';sub='Nothing captured yet, so there is no total.'}
  const can=have>0||f.has_totals===true;
  return '<div class="ftot"><div class="h">Total, net across apps</div><div class="fv">'+val+'</div>'+
   '<div class="fctl">'+(can?'<button class="b fr" data-all="1"'+(rev&&rev.busy?' disabled':'')+'>'+(rev&&rev.busy?'Revealing\u2026':'Reveal all')+'</button>':'')+(any?'<button class="b fh">Hide all</button>':'')+'</div>'+
   (shown?fcd(rev,'*totals',now):'')+
   '<div class="t">'+(can?(sub?esc(sub)+' ':'')+have+' of '+ms.length+' apps have amounts. They hide again after 30 s.':esc(sub||'Nothing to reveal yet.'))+'</div></div>'}
function finInv(f,now){
  const inv=isObj(f.inventory)?f.inventory:null,k=eStale(f,now)?'stale':'';
  if(!inv)return tile('Inventory','\u2014','The feed has no inventory section.','stale');
  const no=(v,why)=>num(v)==null?why:'',ex=isObj(f.explain)?f.explain:{},scan=asOfAt(f,'inventory'),chk=scan!=null?scan:inv.t;
  return '<div class="mgrid g2">'+
   mini('On the iPhone',cnt(inv.installed),no(inv.installed,'not reported'),k)+
   mini('Look financial',cnt(inv.finance_related),no(inv.finance_related,'not reported'),k)+
   mini('Captured',cnt(inv.covered),no(inv.covered,'not reported'),k)+
   mini('Last checked',toEpoch(chk)==null?'no time':ago(chk,now),str(ex.last_checked,160),k)+'</div>'}
// status counts: the feed's own `status_counts` when they add up to the app list and no app was downgraded here, else counted from the list
const FIN_ORDER=['ok','stale','needs_owner','needs_unlock','blocked','never'];
function finTally(f,ms){
 if(!ms.length)return 'No apps listed';
 const sc=isObj(f.status_counts)?f.status_counts:null,fed={};let sum=0;
 if(sc)FIN_ORDER.forEach(s=>{const n=num(sc[s]);if(n!=null&&n>0){fed[s]=Math.round(n);sum+=fed[s]}});
 const use=sc&&sum===ms.length&&!ms.some(m=>m.down)?fed:null,c=use||FIN_ORDER.reduce((o,s)=>(o[s]=ms.filter(m=>m.st===s).length,o),{});
 return FIN_ORDER.filter(s=>c[s]>0).map(s=>c[s]+' '+FIN_WORD[s].toLowerCase()).join(' \u00B7 ')}
// when the data was true, one line: balances (the newest capture of any balance) and the iPhone app list scan, never the file's write time
function finAsOf(f,now){const a=isObj(f.as_of)?f.as_of:null;if(!a)return '';
 const b=toEpoch(a.balances),i=toEpoch(a.inventory);
 return '<div class="tnote asof">'+esc((b==null?'No balance captured yet':'Balances as of '+ago(b,now))+' \u00B7 '+(i==null?'app list not scanned yet':'app list scanned '+ago(i,now)))+'</div>'}
// [header, inventory, total and controls, errors, empty state | apps A | apps B]. app markup: #mn1 #mn2 #mn3. rev = finCtl.view() or null.
function fin(f,now,rev){
  if(!isObj(f)||f.error){const missing=isObj(f)&&/missing|not found|no such file|not written/i.test(str(f.error,120));
   if(missing)return ['<div class="secttl"><span>Money</span></div>'+empty({k:'idle',title:'Not set up',line:'Money needs a finance feed. Not set up yet.'}),'',''];
   return [fHead('Money',f,now)+down('Money',f,'money'),'','']}
  const part=(fn,t)=>{try{return fn()}catch(e){return vfail(t,'money')}};
  const fs=eStale(f,now),list=arr(f.apps).filter(isObj).slice(0,120);
  const ms=[];list.forEach(a=>{try{ms.push(finApp(a,f,now))}catch(e){}});
  const tally=finTally(f,ms),ex=isObj(f.explain)?f.explain:{},neverLine=ms.some(m=>m.st==='never')&&str(ex.never,200)?'<div class="tnote">'+esc(str(ex.never,200))+'</div>':'';
  const allNever=ms.length===0||ms.every(m=>m.st==='never');
  const err=rev&&rev.err?'<div class="ecerr"><div class="frow err">'+SD('bad')+'<span>'+esc(str(rev.err,80))+'</span></div></div>':'';
  // a sample feed says so once, in one line; no figure or source on the page repeats it
  const col1=fHead('Money',f,now)+finAsOf(f,now)+(f.sample===true?'<div class="fsample">Sample data. Made-up numbers, not real money.</div>':'')+
   (allNever?empty({k:'idle',title:'Nothing captured yet',line:'Each app stays at Never until you approve a pass on your phone.'}):'')+
   // with nothing captured the empty state above already says so: no second card repeats it as a masked total
   (allNever&&f.has_totals!==true?'':part(()=>finTotal(f,now,rev,ms),'Total'))+err+part(()=>finInv(f,now),'Inventory')+'<div class="tnote">'+esc(tally)+'</div>'+neverLine+
   (arr(f.errors).length?'<div class="ecerr">'+errRows(f)+'</div>':'');
  // W6: FIN_FOLD_MIN or more identical "never captured" cards fold into ONE row whose tap sheet lists them by kind (a handful of cards stays cards). The grouping below runs on the rest.
  const isFold=a=>{try{const m=finApp(a,f,now);return m.st==='never'&&!m.has&&!(rev&&ownKey(rev.apps,m.id))}catch(e){return false}};
  const never=list.filter(isFold),fold=never.length>=FIN_FOLD_MIN,rest=fold?list.filter(a=>!never.includes(a)):list;
  // apps grouped by kind, split at half the apps; a group that straddles the cut continues under "(continued)"
  const groups=FIN_KINDS.map(k=>[k,rest.filter(a=>finKind(a)===k)]).filter(g=>g[1].length),half=Math.ceil(rest.length/2),cols=['',''];
  let n=0;
  for(const [k,as] of groups){
   let i=0;
   while(i<as.length){
    const c=n<half?0:1,take=as.slice(i,c===0?i+(half-n):as.length);
    const sub=rev&&isObj(rev.totals)&&isObj(rev.totals.by_kind)&&ownKey(rev.totals.by_kind,k)&&num(rev.totals.by_kind[k])!=null?' \u00B7 '+money(rev.totals.by_kind[k]):'';
    cols[c]+='<div class="secttl"><span>'+esc(FIN_LABEL[k])+(i>0?' (continued)':'')+'</span><span>'+(take.length<as.length?take.length+' of '+as.length:as.length)+' app'+(as.length>1?'s':'')+sub+'</span></div>'+
     take.map(a=>part(()=>finCard(a,f,now,rev,fs),finLabel(a))).join('');
    n+=take.length;i+=take.length}}
  if(fold)cols[0]='<div class="secttl"><span>Never captured</span><span>'+never.length+' apps</span></div><div class="flist"><div class="frow"><span class="fl"><b>'+never.length+' apps never captured</b><small>Each needs a pass on your phone</small>'+
   MORE(FIN_KINDS.map(k=>{const ns=never.filter(a=>finKind(a)===k).map(finLabel);return ns.length?FIN_LABEL[k]+': '+ns.join(', '):''}))+'</span></div></div>'+cols[0];
  if(!list.length)cols[0]=fHead('Apps',f,now)+tile('Apps','None','The feed lists no apps.','stale');
  return [col1,cols[0],cols[1]]}

 // Reveal controller. Holds the only copy of revealed amounts. env = {get(path)->Promise<json>, setT, clearT, now()->ms, onChange()}.
 // reveal('*') shows every app that has values plus the total; reveal(id) shows one app. Each reveal expires 30 s after it lands.
 // hide() / drop(key) / expiry remove the amounts from this object, then onChange() repaints from the masked feed.
 function finCtl(env,ms){
  const HIDE=ms||FIN_HIDE_MS;
  let apps=Object.create(null),totals,exp=Object.create(null),timer=null,gen=0,err='',busy=false;
  const keys=()=>Object.keys(exp);
  const clearTimer=()=>{if(timer!=null){env.clearT(timer);timer=null}};
  function arm(){clearTimer();const ks=keys();if(!ks.length)return;timer=env.setT(sweep,Math.max(0,Math.min(...ks.map(k=>exp[k]))-env.now()))}
  function sweep(){timer=null;const n=env.now();let changed=false;
   for(const k of keys())if(exp[k]<=n+25){if(k==='*totals')totals=undefined;else delete apps[k];delete exp[k];changed=true}
   arm();if(changed)env.onChange();return changed}
  function hide(){const was=busy||keys().length>0||err!=='';gen++;busy=false;err='';apps=Object.create(null);totals=undefined;exp=Object.create(null);clearTimer();if(was)env.onChange()}
  function drop(key){if(!ownKey(exp,key))return;if(key==='*totals')totals=undefined;else delete apps[key];delete exp[key];arm();env.onChange()}
  async function reveal(which){
   if(busy||typeof which!=='string'||!which)return;
   busy=true;err='';const g=gen;env.onChange();
   let r=null;try{r=await env.get('/api/finance-values')}catch(e){r=null}
   if(g!==gen)return; // hidden while the request was in flight: the answer is dropped unread
   busy=false;
   if(!isObj(r)||r.error){err=isObj(r)&&r.error?'Could not load the amounts. Try again.':'The deck did not answer. Try again.';env.onChange();return}
   const at=env.now()+HIDE,av=isObj(r.apps)?r.apps:{};
   if(which==='*'){for(const id of Object.keys(av)){apps[id]=isObj(av[id])?av[id]:null;exp[id]=at}totals=isObj(r.totals)?r.totals:null;exp['*totals']=at}
   else{apps[which]=ownKey(av,which)&&isObj(av[which])?av[which]:null;exp[which]=at}
   arm();env.onChange()}
  return {reveal,hide,drop,sweep,view:()=>({apps,totals,exp,err,busy})}}

 // ---- Fleet page: a blank body always says why ----
 // s: {f,nd,dk,st,mc,bd,err} = the /api/fleet, nodes, disks, sites, mcp, fleet-board answers (null or {error} when a read failed);
 // err = the message of a thrown read. blank=true when no part has anything to draw; reasons lists every part that failed or is empty.
 function fleetNotice(s){s=isObj(s)?s:{};const why=[],add=(k,o,key,none)=>{if(!isObj(o))why.push(k+': deck server did not answer');else if(o.error)why.push(k+': '+str(o.error,80));else if(!arr(o[key]).length)why.push(k+': '+none)};
  const f=isObj(s.f)?s.f:null,sv=f&&isObj(f.services)?f.services:null,rc=f&&isObj(f.reach)?f.reach:null;
  if(s.err)why.push('Fleet read failed: '+str(String(s.err),80));
  if(!f)why.push('Fleet facts: deck server did not answer');else if(f.error)why.push('Fleet facts: '+str(f.error,80));else if(f.empty_reason)why.push(str(f.empty_reason,100));
  add('GB10 nodes',s.nd,'nodes','none reported');add('Disks',s.dk,'drives','none reported');add('Sites',s.st,'items','none reported');
  if(isObj(s.mc)&&s.mc.error)why.push('MCP: '+str(s.mc.error,80));
  const bd=isObj(s.bd)?s.bd:null,okParts=bd?['machines','cluster','models','backup','units'].filter(k=>isObj(bd[k])&&!bd[k].error):[];
  if(!bd)why.push('Fleet board: deck server did not answer');else if(!okParts.length)why.push('Fleet board: every source is unavailable');
  const has=(o,k)=>isObj(o)&&!o.error&&arr(o[k]).length>0;
  const live=has(f,'items')||has(sv,'items')||has(rc,'items')||has(s.nd,'nodes')||has(s.dk,'drives')||has(s.st,'items')||okParts.length>0||!!(f&&isObj(f.cluster)&&f.cluster.ok===true);
  const reasons=why.slice(0,6),blank=!live;
  return {blank,reasons,html:'<div class="tile bad why" role="status"><div class="h"><i class="sd bad"></i>Fleet</div><div class="v">'+(blank?'Nothing to show':'Some sources are missing')+'</div>'+
   (reasons.length?reasons.map(x=>'<div class="t">'+esc(x)+'</div>').join(''):'<div class="t">No source reported anything</div>')+'</div>'}}
 // Life: the Almanac (20-year history) through the deck's own /almanac/ proxy, owner cookie only (guests never see Life)
 const almanacTile=()=>'<a class="b cmt alm" href="/almanac/" target="_blank" rel="noopener"><b>Almanac</b><small>Your history, 2006 to now</small></a>';
 return {esc,redact,errCode,noPath,shopDown,dealScore,bestAny,flipScore,ageS,humanErr,problem,empty,down,diagHtml,schedule,dur,repoLabels,midCut,uniq,surfGroups,friendly,sentence,fmt,toEpoch,hm,ago,until,usd,compass,safeUrl,state,line,cluster,JOB_SHORT,JOB_STEP,launchItems,launchCounts,launchAreas,launchFacets,launchFilter,launchList,launchRow,launchResult,dev,conn,
  products,needRows,maintenanceRows,appTile,ascWord,perf,tNeeds,tMaintenance,tCluster,tCal,tHome,tSurf,tHockey,tJobs,tHomes,jobSites,jobs,jobTax,jobCat,jobSub,jobFacets,jobFilter,jobPay,jobRow,jobStrip,jobSheet,jobStateOf,jobChipGroups,jobFilterSummary,jobFilters,jobSrcLine,jobProfileNote,JMETRO,JMETRO_CHIP,JMETRO_ORDER,JMODE,markets,surf,hockey,homes,housingMatches,crons,attention,launchFavorites,launchFavs,againState,cronRow,laneOf,board,fleetSignals,bMachines,bCluster,bModels,bBackup,bUnits,syncLine,syncSheet,unitLabel,runView,runClock,fleetNotice,RUN_GIVEUP,RUN_QUEUE_TIMEOUT_S,KIND_ORDER,KIND_LABEL,TIER_ORDER,TIER_LABEL,WHERE_LABEL,errNames,
  sheetPick,htmlLines,cardSheet,cronId,cronList,findCron,cronActions,cronDraft,cronSheet,unitOk,unitDraft,unitSheet,unitView,sheetBody,sheetLink,tapAction,armedNow,sheetActions,actResult,ARM_MS,
  threadAdd,threadSave,threadLoad,threadFor,threadHtml,sendLabel,sendText,sendState,tooLongText,canSend,sendBody,sendResult,enterSends,growHeight,isDeckShell,dropsTarget,cleanText,vvFit,THREAD_MAX,SEND_MAX,
  mdHtml,homeTilde,scanSecrets,scrubArg,toolLabel,runItems,runTitle,routeNote,
  emptyFacts,carCard,watchEmpty,inkTile,dueTag,decisionRow,jobCue,shop,listings,coverage,siteChip,siteLine,watchCard,siteCtx,shortSite,clip,mval,spark,season,seasonWords,movers,deals,amazon,amzCard,amzRow,macroCard,money,pct,eStale,eFresh,genAt,asOfAt,groupRow,groupRows,setupLines,retryCmd,fin,finCtl,finApp,finCard,finTotal,finTally,finAsOf,fcdText,FIN_HIDE_MS,fixRow,FIX_KINDS,
  commerce,cmReveal,orderRow,daysLeft,returnWord,CM_TILES,almanacTile,onThisDay,yearsInPhotos,replyBlock,rankWatch,gmailUrl,
  vercelEmpty,dlItems,dlNeeds,dlRow,tDeadlines,tfState,tfRow,appBuilds,tfNeeds,todayExtras,watchUnlinked,FIN_FOLD_MIN,SHOP_WATCH,SHOP_AMZ,SHOP_LIST,SHOP_STEP}
})();
// ==== DECK V6 UI HELPERS END ====
// ---- page glue (DOM + fetch) ----
const V6={busy:{},t:{},jobs:null,jobInsight:null,profile:null,job:jobState(),jobsN:DeckUI.JOB_SHORT,site:localStorage.getItem('job-site')||'all',launch:null,favs:[],armed:'',armT:0,launchErr:null,items:[],launchT:0,kind:'all',q:'',armed:'',armT:0,sending:false,results:[],
 tier:localStorage.getItem('launch-tier')||'all',area:localStorage.getItem('launch-area')||'all',where:(w=>!w||w==='omp'?'all':w)(localStorage.getItem('launch-where'))};
// Life jobs filter state: category, sub-category, metro and site, remembered in this browser.
function jobState(){const d={cat:'all',sub:'all',metro:'all',site:'all'},ok=v=>typeof v==='string'&&/^[A-Za-z0-9_-]{1,40}$/.test(v)&&v!=='';
 try{const s=JSON.parse(localStorage.getItem('job-filter')||'null');if(s&&typeof s==='object')for(const k of ['cat','sub','metro','site'])if(ok(s[k]))d[k]=s[k]}catch(e){}
 if(d.site==='all'&&ok(localStorage.getItem('job-site')))d.site=localStorage.getItem('job-site');
 return d}
const JOBSTATE=jobState;
const feedGet=p=>jget('/api/'+p).catch(()=>null);
const renderFail=t=>DeckUI.empty({k:'bad',title:'Could not show '+t,line:'Try again. If it keeps happening, reload the deck.',retry:'page'});
// a light tick on tab and chip taps and on every action result; window.haptic (app.js) is a no-op outside the iOS shell
const buzz=s=>{try{if(typeof haptic==='function')haptic(s)}catch(e){}};
function fillCols(ids,html,title){ids.forEach((id,i)=>{const el=$('#'+id);if(el)el.innerHTML=html[i]||''});if(!html[0]&&title)$('#'+ids[0]).innerHTML=renderFail(title)}
async function once(name,fn){if(V6.busy[name])return;V6.busy[name]=true;V6.t[name]=Date.now();try{await fn()}finally{V6.busy[name]=false}}
const v6Cluster=()=>once('cluster',async()=>{const [f,pf]=await Promise.all([feedGet('cluster'),feedGet('perfloop')]),now=Date.now();
 try{const h=DeckUI.cluster(f,now);h[0]+=DeckUI.perf(pf,now);fillCols(['cl1','cl2','cl3'],h,'Cluster')}catch(e){$('#cl1').innerHTML=renderFail('Cluster')}});
const v6Dev=()=>once('dev',async()=>{const [d,tf]=await Promise.all([feedGet('dev'),feedGet('testflight')]);
 try{fillCols(['dv1','dv2','dv3'],DeckUI.dev(d,Date.now(),tf),'Dev')}catch(e){$('#dv1').innerHTML=renderFail('Dev')}});
// ---- v7: Keys connections, Home products, Today sections ----
const v7Keys=()=>once('keys',async()=>{const a=await feedGet('accounts');
 try{fillCols(['conn1','conn2'],DeckUI.conn(a,Date.now()),'Connections')}catch(e){$('#conn1').innerHTML=renderFail('Connections')}});
const v7Home=()=>once('home',async()=>{const p=await feedGet('products');
 try{const r=DeckUI.products(p,Date.now());$('#prodg').innerHTML=r.grid;$('#needl').innerHTML=(r.needs||renderFail('Needs you'))+(r.maintenance||'');$('#prodt').textContent=r.src;$('#needt').textContent=r.count==='--'?'':r.count}
 catch(e){$('#prodg').innerHTML=renderFail('Products')}});
const PUT_NAME={tneeds:'your decisions',tdead:'renewals and deadlines',tmaint:'maintenance',tclu:'the cluster',tcal:'the calendar',thome:'car and house',tsurf:'surf',thockey:'hockey',tjobs:'jobs',thomes:'homes'};
function put(id,fn){const el=$('#'+id);if(!el)return;try{el.innerHTML=fn()}catch(e){el.innerHTML=renderFail(PUT_NAME[id]||'this section')}}
// the Renewals and deadlines section sits right after Your decisions; app.js ensureToday() builds the page once, so the block is added here, once
function ensureDead(){if($('#tdead'))return;const n=$('#tneeds');if(n)n.insertAdjacentHTML('afterend','<div id="tdead"></div>')}
const v7Today=()=>once('today',async()=>{if(typeof ensureToday=='function')ensureToday();ensureDead();
 const [p,c,pf,a,j,s,h,r,car,ha,cams,watch,dl,tf]=await Promise.all(['products','cluster','perfloop','accounts','jobs','surf','hockey','realestate','car','ha','cams','watch','deadlines','testflight'].map(feedGet)),now=Date.now();
 put('tneeds',()=>DeckUI.tNeeds(p,now,DeckUI.todayExtras(dl,tf)));put('tdead',()=>DeckUI.tDeadlines(dl,now));put('tmaint',()=>DeckUI.tMaintenance(p,now));put('tclu',()=>DeckUI.tCluster(c,now,pf));put('tcal',()=>DeckUI.tCal(a,now));put('thome',()=>DeckUI.tHome(car,ha,cams,watch));
 put('tsurf',()=>DeckUI.tSurf(s,now));put('thockey',()=>DeckUI.tHockey(h,now));put('tjobs',()=>DeckUI.tJobs(j,now));put('thomes',()=>DeckUI.tHomes(r,now))});
const HOUSING={feed:null,state:'all',zip:'',scope:localStorage.getItem('home-scope')||'markets',page:'short'};
function paintHousing(){try{$('#lf3').innerHTML=DeckUI.homes(HOUSING.feed,Date.now(),{state:HOUSING.state,zip:HOUSING.zip,scope:HOUSING.scope,page:HOUSING.page})}catch(e){$('#lf3').innerHTML=renderFail('Homes')}}
$('#lf3').addEventListener('click',e=>{const s=e.target.closest('[data-housing-scope]');
 if(s){HOUSING.scope=s.dataset.housingScope==='us'?'us':'markets';localStorage.setItem('home-scope',HOUSING.scope);paintHousing();return}
 const m=e.target.closest('[data-more="homes"]');
 if(m){HOUSING.page=HOUSING.page==='short'?'all':'short';paintHousing();return}
 if(!e.target.closest('[data-housing-apply]'))return;
 const state=$('#lf3').querySelector('[data-housing-state]'),zip=$('#lf3').querySelector('[data-housing-zip]');
 HOUSING.state=state?state.value:'all';HOUSING.zip=zip&&/^\d{5}$/.test(zip.value.trim())?zip.value.trim():'';paintHousing()});
const JOBSHEET=typeof document!=='undefined'?$('#jsh'):null;
function jobOpen(i){if(!JOBSHEET)return;
 try{const x=DeckUI.jobFilter(V6.jobs,V6.job)[i];if(!x)return;
  JOBSHEET.innerHTML=DeckUI.jobSheet(x,V6.jobs,{insight:V6.jobInsight,profile:V6.profile},Date.now());
  JOBSHEET.classList.add('on');const b=$('#jshx');if(b)b.focus()}
 catch(e){JOBSHEET.innerHTML=renderFail('Job detail');JOBSHEET.classList.add('on')}}
function jobClose(){if(!JOBSHEET)return;JOBSHEET.classList.remove('on');JOBSHEET.innerHTML=''}
// the jobs column keeps every filter inline on a tall screen; a phone held sideways gets one
// filter bar that opens the same chips in a sheet, so the list keeps the first screen
const jobOpt=()=>({insight:V6.jobInsight,profile:V6.profile,compact:innerHeight<560,page:V6.jobsN});
function paintJobs(){try{$('#lf1').innerHTML=DeckUI.jobs(V6.jobs,V6.job,Date.now(),jobOpt())}catch(e){$('#lf1').innerHTML=renderFail('Jobs')}
 try{const f=$('#jfl');if(f&&f.classList.contains('on'))f.innerHTML=DeckUI.jobFilters(V6.jobs,V6.job,Date.now(),{profile:V6.profile})}catch(e){}}
const otdHtml=(od,now)=>{try{return DeckUI.onThisDay(od,now)}catch(e){return renderFail('On this day')}};
const pyHtml=(py,now)=>{try{return DeckUI.yearsInPhotos(py,now)}catch(e){return renderFail('Years in photos')}};
const rbHtml=(rb,now)=>{try{return DeckUI.replyBlock(rb,now)}catch(e){return renderFail('Reply block')}};
const rwHtml=(rw,now)=>{try{return DeckUI.rankWatch(rw,now)}catch(e){return renderFail('Rank watch')}};
const v6Life=()=>once('life',async()=>{const [j,s,h,r,t,ji,ip,od,py,rb,rw]=await Promise.all(['jobs','surf','hockey','realestate','today','jobs-insight','interest-profile','onthisday','photoyears','replyblock','rankwatch'].map(feedGet));
 V6.jobs=j;V6.jobInsight=ji&&!ji.error?ji:null;V6.profile=ip&&!ip.error?ip:null;paintJobs();const now=Date.now(),tf=!t||t.error;
 try{$('#lf2').innerHTML=DeckUI.almanacTile()+rbHtml(rb,now)+rwHtml(rw,now)+otdHtml(od,now)+pyHtml(py,now)+DeckUI.markets(tf?todayLast:t,now,tf)+DeckUI.surf(s,now)+DeckUI.hockey(h,now)}catch(e){$('#lf2').innerHTML=renderFail('Markets, surf, hockey')}
 HOUSING.feed=r;paintHousing()});
function chipsClick(e){
 const b=e.target.closest('[data-cat],[data-sub],[data-metro],[data-site]');if(!b)return;
 const d=b.dataset;
 if(d.cat!=null){V6.job.cat=d.cat;V6.job.sub='all'}
 else if(d.sub!=null)V6.job.sub=d.sub;
 else if(d.metro!=null)V6.job.metro=d.metro;
 else if(d.site!=null)V6.job.site=d.site;
 else return;
 try{localStorage.setItem('job-filter',JSON.stringify(V6.job))}catch(err){}
 paintJobs()}
$('#lf1').addEventListener('click',e=>{
 const m=e.target.closest('[data-more="jobs"]');
 if(m){if(m.dataset.less)V6.jobsN=DeckUI.JOB_SHORT;else V6.jobsN=Math.min(V6.jobsN+DeckUI.JOB_STEP,DeckUI.JOB_CAP);paintJobs();return}
 const r=e.target.closest('.jrow');if(r){jobOpen(+r.dataset.j);return}
 if(e.target.closest('[data-filter="open"]')){jobFiltersOpen();return}
 chipsClick(e)});
const JOBFILTERS=typeof document!=='undefined'?$('#jfl'):null;
function jobFiltersOpen(){if(!JOBFILTERS)return;
 try{JOBFILTERS.innerHTML=DeckUI.jobFilters(V6.jobs,V6.job,Date.now(),{profile:V6.profile});JOBFILTERS.classList.add('on');const b=$('#jfx');if(b)b.focus()}catch(e){}}
function jobFiltersClose(){if(JOBFILTERS)JOBFILTERS.classList.remove('on')}
if(JOBSHEET){JOBSHEET.addEventListener('click',e=>{if(e.target.closest('#jshx'))jobClose()});
 addEventListener('keydown',e=>{if(e.key!=='Escape')return;if(JOBSHEET.classList.contains('on'))jobClose();else if(JOBFILTERS&&JOBFILTERS.classList.contains('on'))jobFiltersClose()})}
if(JOBFILTERS){JOBFILTERS.addEventListener('click',chipsClick);JOBFILTERS.addEventListener('click',e=>{if(e.target.closest('#jfx'))jobFiltersClose()})}
// ---- launch: search, kind chips, two-tap OMP / Hermes buttons ----
function paintKinds(){const c=DeckUI.launchCounts(V6.items),f=DeckUI.launchFacets(V6.items);
 if(V6.area!=='all'&&!f.area.some(a=>a.area===V6.area))V6.area='all'; // a saved area the feed no longer has
 $('#lna').innerHTML=f.area.length?['<button class="b lna'+(V6.area==='all'?' on':'')+'" data-area="all">All areas '+V6.items.length+'</button>',...f.area.map(a=>'<button class="b lna'+(V6.area===a.area?' on':'')+'" data-area="'+esc(a.area)+'">'+esc(a.area)+' '+a.n+'</button>')].join(''):'<small class="tnote">Areas appear after the next refresh</small>';
 $('#lnk').innerHTML=['all',...DeckUI.KIND_ORDER].map(k=>'<button class="b lnk'+(V6.kind===k?' on':'')+'" data-kind="'+k+'">'+(k==='all'?'All':DeckUI.KIND_LABEL[k])+' '+c[k]+'</button>').join('');
 $('#lnt').innerHTML=['all',...DeckUI.TIER_ORDER].filter(t=>t==='all'||f.tier[t]>0||V6.tier===t).map(t=>'<button class="b lnt t-'+t+(V6.tier===t?' on':'')+'" data-tier="'+t+'">'+(t==='all'?'All tiers':DeckUI.TIER_LABEL[t])+' '+f.tier[t]+'</button>').join('');
 $('#lnw').innerHTML=f.where.length?['<button class="b lnw'+(V6.where==='all'?' on':'')+'" data-where="all">Anywhere</button>',...f.where.map(w=>'<button class="b lnw'+(V6.where===w.w?' on':'')+'" data-where="'+esc(w.w)+'">'+esc(w.label)+' '+w.n+'</button>')].join(''):'<small class="tnote">Hosts appear once the launch audit lands</small>'}
function paintLaunchList(){const el=$('#lnlist');
 if(!V6.launch){el.innerHTML=DeckUI.empty({k:'bad',title:'Launch list is not reporting',line:DeckUI.line(V6.launchErr,Date.now()),retry:'launch',diag:DeckUI.problem(V6.launchErr).diag});return}
 el.innerHTML=(V6.favs.length?DeckUI.launchFavs(V6.favs,V6.armed):'')+DeckUI.launchList(DeckUI.launchFilter(V6.items,V6.q,V6.kind,120,{tier:V6.tier,where:V6.where,area:V6.area}),V6.armed,{area:V6.area,q:V6.q.trim()})}
function paintLaunchHead(){$('#lnsrc').textContent=V6.launch?DeckUI.line(V6.launch,Date.now())+' \u00B7 '+V6.items.length+' items':V6.launchErr?'Not available':'Loading the list'}
function paintResults(){$('#lnmsg').innerHTML=V6.results.map(r=>'<div class="lnres '+r.k+'"><i class="sd '+(r.k==='pending'?'warn':r.k)+'"></i><span>'+esc(r.text)+'</span><small>'+esc(r.at)+'</small></div>').join('')}
function addResult(r){buzz(r.k==='ok'?'success':r.k==='bad'?'error':'');V6.results.unshift({k:r.k,text:r.text,at:new Date().toLocaleTimeString([],{hour:'numeric',minute:'2-digit',second:'2-digit'})});V6.results=V6.results.slice(0,3);paintResults()}
function paintLaunch(){try{paintKinds();paintLaunchList();paintLaunchHead()}catch(e){$('#lnlist').innerHTML=renderFail('Launch')}}
const v6Launch=force=>once('launch',async()=>{if(force||!V6.launch||Date.now()-V6.launchT>300000){const f=await feedGet('launch');
  if(f&&!f.error){V6.launch=f;V6.items=DeckUI.launchItems(f);V6.favs=DeckUI.launchFavorites(f,V6.items);V6.launchT=Date.now();V6.launchErr=null}else V6.launchErr=f||{error:'deck server did not answer'}}
 paintLaunch()});
{let qT=0;$('#lnq').addEventListener('input',()=>{clearTimeout(qT);qT=setTimeout(()=>{V6.q=$('#lnq').value;paintLaunchList()},120)})}
$('#lnk').addEventListener('click',e=>{const b=e.target.closest('.lnk');if(!b)return;V6.kind=b.dataset.kind;paintKinds();paintLaunchList()});
$('#lna').addEventListener('click',e=>{const b=e.target.closest('.lna');if(!b)return;V6.area=b.dataset.area;localStorage.setItem('launch-area',V6.area);paintKinds();paintLaunchList()});
$('#lnt').addEventListener('click',e=>{const b=e.target.closest('.lnt');if(!b)return;V6.tier=b.dataset.tier;localStorage.setItem('launch-tier',V6.tier);paintKinds();paintLaunchList()});
$('#lnw').addEventListener('click',e=>{const b=e.target.closest('.lnw');if(!b)return;V6.where=b.dataset.where;localStorage.setItem('launch-where',V6.where);paintKinds();paintLaunchList()});
$('#lnlist').addEventListener('click',async e=>{const b=e.target.closest('.lnb');if(!b)return;const key=b.dataset.id+'|'+b.dataset.target;
 if(b.dataset.target!=='hermes')return;
 if(V6.armed!==key){V6.armed=key;clearTimeout(V6.armT);V6.armT=setTimeout(()=>{V6.armed='';paintLaunchList()},3000);paintLaunchList();return}
 V6.armed='';clearTimeout(V6.armT);paintLaunchList();if(V6.sending)return;V6.sending=true;
 const nm=(b.getAttribute('aria-label')||'').replace(/^Run in Hermes: /,'')||'the item';addResult({k:'pending',text:'Starting '+nm+' in Hermes'});
 try{const r=await fetch('/api/launch-item?id='+encodeURIComponent(b.dataset.id)+'&target=hermes',{method:'POST'});
  const j=await r.json().catch(()=>null);V6.results.shift();const res=DeckUI.launchResult(j,r.status);addResult(res);
  if(j&&j.ok&&typeof j.run_id==='string')openRun({run_id:j.run_id,name:j.name||b.dataset.id,opened:Date.now()/1000},true)}
 catch(err){V6.results.shift();addResult({k:'bad',text:DeckUI.humanErr(null,0)})}
 finally{V6.sending=false}});
// ---- v8 run panel: state, elapsed, output lines. Polls /api/run every 1.5 s while open and not finished. Close keeps the run;
// "Last run" reopens it (stored in this browser, with the deck's own launch log as the fallback).
// RUN.r is the run being watched (null = compose mode, nothing sent yet). RUN.thread keeps your messages and run ids (8 turns,
// saved in localStorage); RUN.models holds the last status of every run in the thread so earlier outputs stay on screen.
const RUN_KEY='deck-last-run',THREAD_KEY='deck-last-thread';
const RUN={r:null,open:false,timer:0,tick:0,busy:false,thread:DeckUI.threadLoad(localStorage.getItem(THREAD_KEY)),models:{},prior:{},sending:false,opener:null,html:''};
function runSave(){try{localStorage.setItem(RUN_KEY,JSON.stringify({run_id:RUN.r.run_id,name:RUN.r.name,opened:RUN.r.opened,id:RUN.r.id||null}))}catch(e){}}
function runLoad(){try{const o=JSON.parse(localStorage.getItem(RUN_KEY)||'null');if(o&&typeof o.run_id==='string'&&/^[A-Za-z0-9._-]{1,80}$/.test(o.run_id))return {run_id:o.run_id,name:String(o.name||'').slice(0,60),opened:+o.opened||null,id:typeof o.id==='string'?o.id.slice(0,100):null}}catch(e){}return null}
function threadPersist(){try{localStorage.setItem(THREAD_KEY,DeckUI.threadSave(RUN.thread))}catch(e){}}
// repaint only when the markup changed: the 1 s clock must not rebuild the thread (it would drop a text selection and restart the tool spinners)
function runBody(html,force){const body=$('#runo');if(RUN.html===html&&!force)return;RUN.html=html;const stick=force||body.scrollHeight-body.scrollTop-body.clientHeight<40;body.innerHTML=html;if(stick)body.scrollTop=body.scrollHeight}
function setHtmlOnce(el,html){if(el&&el.dataset.h!==html){el.dataset.h=html;el.innerHTML=html}}
function priorHtml(id,now){const m=RUN.models[id];
 if(m)return DeckUI.runView({run_id:id,model:m,got:now},now).html;
 return '<div class="rl dim">'+(RUN.prior[id]==='fail'?'Output not available':'Loading output')+'</div>'}
function setRunErr(msg){$('#runerr').innerHTML=msg?'<i class="sd bad"></i>'+esc(msg):''}
function paintComposer(state){const ta=$('#runin'),b=$('#runsend');if(!ta||!b)return;
 const st=state!==undefined?state:(RUN.r?DeckUI.runView(RUN.r,Date.now()).state:''),live=st==='running'||st==='queued';
 b.textContent=RUN.sending?'Sending':DeckUI.sendLabel(st);b.disabled=!DeckUI.canSend(ta.value,RUN.sending);
 // a message over the limit is never cut: Send stays off and an inline line says how long it is
 const ss=DeckUI.sendState(ta.value);if(ss.tooLong){setRunErr(DeckUI.tooLongText(ss));RUN.limit=true}else if(RUN.limit){RUN.limit=false;setRunErr('')}
 ta.placeholder=live?'Add an instruction for this run':'Message Hermes';
 b.setAttribute('aria-label',RUN.sending?'Sending':live?'Add an instruction to the running turn':RUN.r?'Send a reply in this session':'Send, starts a new chat')}
function runPaint(){const el=$('#runp');if(!el)return;const now=Date.now();
 if(!RUN.r){el.dataset.state='new';$('#runt').textContent='Ask Hermes';setHtmlOnce($('#runs'),'<i class="sd warn"></i>Ready');$('#runs').className='rs queued';
  $('#rune').textContent='';$('#runf').textContent='';
  runBody('<div class="rl dim">Ask Hermes anything. Nothing starts until you tap Send.</div>');el.classList.remove('err');paintComposer('');paintAgain();return}
 const v=DeckUI.runView(RUN.r,now);
 el.dataset.state=v.state;$('#runt').textContent=v.title;setHtmlOnce($('#runs'),'<i class="sd '+v.mark+'"></i>'+esc(v.label));$('#runs').className='rs '+v.state;
 $('#rune').textContent=v.elapsed;$('#runf').textContent=v.note;
 runBody(DeckUI.threadHtml(DeckUI.threadFor(RUN.thread,RUN.r),id=>id===RUN.r.run_id?v.html:priorHtml(id,now)));
 el.classList.toggle('err',v.stale);paintComposer(v.state);paintAgain()}
async function runPoll(){if(RUN.busy||!RUN.r)return;RUN.busy=true;const r=RUN.r;
 try{const ac=new AbortController(),tm=setTimeout(()=>ac.abort(),14000);
  try{const res=await fetch('/api/run?id='+encodeURIComponent(r.run_id),{signal:ac.signal,cache:'no-store'});const j=await res.json().catch(()=>null);
   if(RUN.r!==r)return;
   if(res.ok&&j&&j.ok){const was=r.model&&r.model.state;r.model=j;RUN.models[r.run_id]=j;r.got=Date.now();r.err='';r.fails=0;r.offline=false;
    if((was==='queued'||was==='running'||(!was&&r.live))&&(j.state==='done'||j.state==='failed'))haptic(j.state==='done'?'success':'error')}
   else{r.fails=(r.fails||0)+1;r.err=((j&&j.error)||('http '+res.status)).slice(0,60);r.offline=!!(j&&j.offline);if(j&&typeof j.last_heartbeat==='number')r.beat=j.last_heartbeat}}
  finally{clearTimeout(tm)}}
 catch(e){if(RUN.r===r){r.fails=(r.fails||0)+1;r.offline=false;r.err=e&&e.name==='AbortError'?'timed out':'deck server did not answer'}}
 finally{RUN.busy=false;if(RUN.r===r){runPaint();runSavePaintLast();
  const done=r.model&&(r.model.state==='done'||r.model.state==='failed');
  if(done||!RUN.open||(r.fails||0)>=DeckUI.RUN_GIVEUP){clearInterval(RUN.timer);RUN.timer=0}}}}
function runSavePaintLast(){const b=$('#lnlast');if(!b)return;const r=RUN.r||runLoad();
 if(!r){b.disabled=true;b.textContent='No run yet';return}b.disabled=false;
 const st=RUN.r?DeckUI.runView(RUN.r,Date.now()).state:'';b.textContent='Last run'+(r.name?' \u00B7 '+DeckUI.runTitle(r.name).slice(0,22):'')+(st?' \u00B7 '+st:'')}
async function postLaunchItem(id,target){const res=await fetch('/api/launch-item?id='+encodeURIComponent(id)+'&target='+(target||'hermes'),{method:'POST'});
 const json=await res.json().catch(()=>null);return {json,status:res.status}}
const AGAIN={armed:'',t:0,busy:false};
function paintAgain(){const b=$('#runagain');if(!b)return;const v=DeckUI.againState(RUN.r||runLoad(),AGAIN.armed);
 b.disabled=v.disabled;b.classList.toggle('armed',v.armed);b.textContent=v.text;b.setAttribute('aria-label',v.aria)}
// relaunch the same saved item through the allowlisted launch route the list row uses; two taps, then it starts
async function runAgain(){const r=RUN.r||runLoad();if(!r||!r.id||AGAIN.busy)return;
 if(AGAIN.armed!==r.run_id){AGAIN.armed=r.run_id;clearTimeout(AGAIN.t);AGAIN.t=setTimeout(()=>{AGAIN.armed='';paintAgain()},3000);paintAgain();return}
 AGAIN.armed='';clearTimeout(AGAIN.t);paintAgain();AGAIN.busy=true;
 addResult({k:'pending',text:'Starting Hermes \u00B7 '+r.id});
 try{const res=await postLaunchItem(r.id);
  const j=res.json;V6.results.shift();addResult(DeckUI.launchResult(j||{ok:false,error:'http '+res.status}));
  if(j&&j.ok&&typeof j.run_id==='string')openRun({run_id:j.run_id,name:j.name||r.name,id:r.id,opened:Date.now()/1000},true)}
 catch(e){V6.results.shift();addResult({k:'bad',text:'deck server did not answer'})}
 finally{AGAIN.busy=false}}
// polling and the 1 s clock; force = keep polling even if the last status was terminal (a message was just sent)
function runTimers(force){clearInterval(RUN.timer);RUN.timer=0;clearInterval(RUN.tick);
 const done=!force&&RUN.r&&RUN.r.model&&(RUN.r.model.state==='done'||RUN.r.model.state==='failed');
 if(RUN.r){runPoll();if(!done)RUN.timer=setInterval(runPoll,1500)}
 RUN.tick=setInterval(()=>{if(RUN.open)runPaint()},1000)}
// focus returns to the control that opened a window; a card that was repainted meanwhile falls back to the active page tab
function focusBack(o){const t=o&&o.isConnected?o:$('#pgs button.on');if(!t)return;
 if(t===o&&!/^(BUTTON|A|INPUT|TEXTAREA)$/.test(t.tagName))t.setAttribute('tabindex','-1');try{t.focus({preventScroll:true})}catch(e){}}
function showRun(opener){if(!RUN.open)RUN.opener=opener||document.activeElement;RUN.open=true;$('#runp').classList.add('on')}
// fetch every earlier run in the thread once, so its output shows under its message after a reload
// one at a time: every /api/run answer starts a deck-launch status process on the server
async function loadPriors(){const cur=RUN.r&&RUN.r.run_id;
 const ids=[...new Set(RUN.thread.map(t=>t.run_id))].filter(id=>id!==cur&&!RUN.models[id]&&!RUN.prior[id]);
 for(const id of ids)RUN.prior[id]='pending';
 for(const id of ids){
  try{const res=await fetch('/api/run?id='+encodeURIComponent(id),{cache:'no-store'});const j=await res.json().catch(()=>null);
   if(res.ok&&j&&j.ok){RUN.models[id]=j;RUN.prior[id]='ok'}else RUN.prior[id]='fail'}
  catch(e){RUN.prior[id]='fail'}
  if(RUN.open)runPaint()}}
// fresh = a run just launched from the Launch list: it starts a new thread
function openRun(r,fresh){if(!r)return;if(!RUN.r||RUN.r.run_id!==r.run_id)RUN.r=Object.assign({model:null,got:0,err:'',fails:0,offline:false,beat:null},r);
 else if((RUN.r.fails||0)>=DeckUI.RUN_GIVEUP)RUN.r.fails=0;
 if(fresh){RUN.r.live=true;RUN.thread=[{run_id:r.run_id,text:'',mode:'launch'}];RUN.models={};RUN.prior={}}
 else if(!RUN.thread.some(t=>t.run_id===r.run_id)){const st=DeckUI.threadLoad(localStorage.getItem(THREAD_KEY));RUN.thread=st.some(t=>t.run_id===r.run_id)?st:[{run_id:r.run_id,text:'',mode:'launch'}]}
 runSave();threadPersist();showRun();setRunErr('');runPaint();runSavePaintLast();runTimers();loadPriors();$('#runx').focus()}
// Ask Hermes: a new chat with an editable draft; nothing is sent until Send is tapped
function openCompose(draft,opener){RUN.r=null;RUN.thread=[];RUN.models={};RUN.prior={};
 const ta=$('#runin');ta.value=draft||'';setRunErr('');showRun(opener);growIn();runPaint();runTimers();runSavePaintLast();
 // a long message (an agent mission) opens from its first line with the keyboard down, so it can be read before Send; a short draft opens ready to type
 if(ta.value.length>300){ta.scrollTop=0;try{ta.setSelectionRange(0,0)}catch(e){}}else{ta.focus();try{ta.setSelectionRange(ta.value.length,ta.value.length)}catch(e){}}}
function closeRun(){RUN.open=false;$('#runp').classList.remove('on');clearInterval(RUN.timer);RUN.timer=0;clearInterval(RUN.tick);RUN.tick=0;runSavePaintLast();
 fitRunVv();const o=RUN.opener;RUN.opener=null;focusBack(o)}
// keep the run window inside the visible area while the soft keyboard is up (visualViewport shrinks, the layout viewport does not)
function fitRunVv(){const vv=window.visualViewport,p=$('#runp');if(!vv||!p)return;
 const f=RUN.open?DeckUI.vvFit(innerHeight,vv.height,vv.offsetTop):null;
 p.style.height=f?f.height+'px':'';p.style.transform=f?'translateY('+f.top+'px)':'';p.classList.toggle('kbd',!!f);
 if(f){const o=$('#runo');if(o)o.scrollTop=o.scrollHeight}}
if(window.visualViewport){visualViewport.addEventListener('resize',fitRunVv);visualViewport.addEventListener('scroll',fitRunVv);
 $('#runin').addEventListener('blur',()=>setTimeout(fitRunVv,80))}
function growIn(){const ta=$('#runin'),long=ta.value.length>300;$('#runp').classList.toggle('long',long);ta.style.height='auto';const cs=getComputedStyle(ta),lh=parseFloat(cs.lineHeight)||20,
  pv=['paddingTop','paddingBottom','borderTopWidth','borderBottomWidth'].reduce((a,k)=>a+(parseFloat(cs[k])||0),0);
 ta.style.height=DeckUI.growHeight(ta.scrollHeight,lh,pv,long?12:4)+'px'}
function runSent(out,text){const prev=RUN.r;if(prev&&prev.model)RUN.models[prev.run_id]=prev.model;
 RUN.thread=DeckUI.threadAdd(RUN.thread,{run_id:out.run_id,text,mode:out.mode});
 if(out.mode==='steer'&&prev&&prev.run_id===out.run_id){prev.err='';prev.fails=0}
 else RUN.r={run_id:out.run_id,name:text.slice(0,40),opened:Date.now()/1000,model:null,got:0,err:'',fails:0,live:true};
 runSave();threadPersist();runTimers(true);runPaint();runSavePaintLast();const o=$('#runo');o.scrollTop=o.scrollHeight}
async function runSend(){const ta=$('#runin'),st=DeckUI.sendState(ta.value),text=st.text;if(!st.ok||RUN.sending)return;
 RUN.sending=true;setRunErr('');paintComposer();haptic('light');
 try{const res=await fetch('/api/run-send',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(DeckUI.sendBody(text,RUN.r))});
  const j=await res.json().catch(()=>null),out=DeckUI.sendResult(j,res.status);
  if(!out.ok){setRunErr('Not sent. '+out.err);haptic('error');return}
  runSent(out,text);ta.value='';growIn()}
 catch(e){setRunErr('Not sent. The deck did not answer');haptic('error')}
 finally{RUN.sending=false;paintComposer()}}
$('#runsend').addEventListener('click',runSend);
$('#runin').addEventListener('input',()=>{growIn();paintComposer()});
$('#runin').addEventListener('keydown',e=>{if(DeckUI.enterSends(e,matchMedia('(pointer:coarse)').matches)){e.preventDefault();runSend()}});
$('#runnew').addEventListener('click',()=>{RUN.r=null;RUN.thread=[];RUN.models={};RUN.prior={};clearInterval(RUN.timer);RUN.timer=0;
 try{localStorage.removeItem(THREAD_KEY);localStorage.removeItem(RUN_KEY)}catch(e){}setRunErr('');runPaint();runSavePaintLast();$('#runin').focus()});
async function reopenRun(){const have=RUN.r||runLoad();if(have)return openRun(have);
 try{const j=await jget('/api/run-last');if(j&&j.ok&&j.run_id)return openRun({run_id:j.run_id,name:String(j.id||'').slice(0,60),opened:j.launched_at||null})}catch(e){}
 addResult({k:'bad',text:'No run to reopen'})}
$('#runx').addEventListener('click',closeRun);$('#lnlast').addEventListener('click',reopenRun);$('#runagain').addEventListener('click',runAgain);
addEventListener('keydown',e=>{if(RUN.open&&!SHEET.open&&e.key==='Escape')closeRun()});
runSavePaintLast();paintAgain();
// ---- v8 Crons tab ----
function paintCrons(f){try{fillCols(['cr1','cr2','cr3'],DeckUI.crons(f,Date.now()),'Crons')}catch(e){$('#cr1').innerHTML=renderFail('Crons')}}
const v8Crons=()=>once('crons',async()=>{const f=await feedGet('crons');V6.crons=f;paintCrons(f)});
// ---- feedback release detail sheet: tap a card to read it whole. Cron sheets carry Run now / Pause / Resume, failing units read /api/unit,
// both end in Ask Hermes (opens the run window with an editable draft). Links are never intercepted.
const SHEET={open:false,spec:null,armed:null,armT:0,opener:null,busy:false,res:null,tok:0};
function paintSheet(){const s=SHEET.spec;if(!s)return;const was=document.activeElement&&document.activeElement.dataset?document.activeElement.dataset.act:'';
 $('#sheett').textContent=s.title;$('#sheets').textContent=s.sub||'';$('#sheetb').innerHTML=DeckUI.sheetBody(s);
 const r=SHEET.res;$('#sheetr').innerHTML=r?'<i class="sd '+(r.k==='ok'?'ok':r.k==='pending'?'warn':'bad')+'"></i>'+esc(r.text):'';
 $('#sheeta').innerHTML=DeckUI.sheetActions(s.actions,SHEET.armed,Date.now(),SHEET.busy)+DeckUI.sheetLink(s.url);
 if(was){const b=[...$$('#sheeta [data-act]')].find(x=>x.dataset.act===was);if(b&&!b.disabled)b.focus()}}
function openSheet(spec,opener){if(!spec)return;if(!SHEET.open)SHEET.opener=opener||document.activeElement;
 clearTimeout(SHEET.armT);SHEET.tok++;SHEET.spec=spec;SHEET.armed=null;SHEET.busy=false;SHEET.res=null;SHEET.open=true;
 $('#sheet').classList.add('on');$('#app').inert=true;paintSheet();$('#sheetb').scrollTop=0;$('#sheetx').focus()}
function closeSheet(skipFocus){if(!SHEET.open)return;SHEET.open=false;SHEET.tok++;clearTimeout(SHEET.armT);SHEET.armed=null;SHEET.spec=null;
 $('#sheet').classList.remove('on');$('#app').inert=false;const o=SHEET.opener;SHEET.opener=null;if(!skipFocus)focusBack(o);return o}
const ACT_WORD={run:'Starting the run',pause:'Pausing',resume:'Resuming'};
async function cronsReload(){const f=await feedGet('crons');if(f&&!f.error){V6.crons=f;paintCrons(f)}}
async function cronAct(s,act){const tok=SHEET.tok;SHEET.busy=true;SHEET.res={k:'pending',text:(ACT_WORD[act]||'Working')+'\u2026'};paintSheet();let out;
 try{const res=await fetch('/api/cron-act?id='+encodeURIComponent(s.id)+'&act='+encodeURIComponent(act),{method:'POST'});
  out=DeckUI.actResult(await res.json().catch(()=>null),res.status,act)}
 catch(e){out=DeckUI.actResult(null,0,act)}
 if(out.k==='ok')await cronsReload();
 if(tok!==SHEET.tok)return;
 SHEET.busy=false;SHEET.res=out;buzz(out.k==='ok'?'success':'error');
 if(out.k==='ok'){const hit=DeckUI.findCron(V6.crons,s.id);if(hit)SHEET.spec=DeckUI.cronSheet(hit.j,hit.paused,Date.now())}
 paintSheet()}
async function openUnit(name,opener){const spec=DeckUI.unitSheet(name);openSheet(spec,opener);const tok=SHEET.tok;let j=null;
 try{const r=await fetch('/api/unit?name='+encodeURIComponent(name),{cache:'no-store'});j=await r.json().catch(()=>null);if(!r.ok&&!(j&&j.error))j={ok:false,error:'http '+r.status}}catch(e){j=null}
 if(tok!==SHEET.tok||SHEET.spec!==spec)return;
 Object.assign(spec,DeckUI.unitView(j),{draft:DeckUI.unitDraft(name,j)});paintSheet()}
$('#sheeta').addEventListener('click',e=>{const b=e.target.closest('button[data-act]');if(!b||SHEET.busy||!SHEET.spec)return;
 const s=SHEET.spec,a=s.actions.find(x=>x.id===b.dataset.act);if(!a)return;
 const t=DeckUI.tapAction(SHEET.armed,a.id,Date.now(),!!a.confirm);SHEET.armed=t.armed;clearTimeout(SHEET.armT);
 if(t.armed)SHEET.armT=setTimeout(()=>{SHEET.armed=null;paintSheet()},DeckUI.ARM_MS);
 paintSheet();
 if(!t.run)return;
 if(a.id==='ask'){const op=closeSheet(true);openCompose(s.draft,op)}else if(s.kind==='cron'&&s.id)cronAct(s,a.id)});
$('#sheetx').addEventListener('click',()=>closeSheet());$('#sheetbg').addEventListener('click',()=>closeSheet());
addEventListener('keydown',e=>{if(SHEET.open&&e.key==='Escape'){e.preventDefault();closeSheet()}});
// keep Tab inside the dialog
$('#sheet').addEventListener('keydown',e=>{if(e.key!=='Tab')return;const f=[...$$('#sheetp button:not([disabled]),#sheetp a[href],#sheetb[tabindex]')];if(!f.length)return;
 const i=f.indexOf(document.activeElement);
 if(e.shiftKey&&i<=0){e.preventDefault();f[f.length-1].focus()}else if(!e.shiftKey&&(i<0||i===f.length-1)){e.preventDefault();f[0].focus()}});
// tap a card on the info pages: sheetPick refuses links, buttons, inputs, cameras, Launch rows and filter chips
$('#pager').addEventListener('click',e=>{if(SHEET.open||RUN.open||vOpen||!e.target||!e.target.closest)return;
 const pg=e.target.closest('.page');if(!pg)return;
 const chain=[];for(let n=e.target;n&&n!==pg;n=n.parentElement)chain.push({tag:n.tagName,cls:typeof n.className==='string'?n.className:''});
 const i=DeckUI.sheetPick(pg.dataset.name,chain);if(i<0)return;
 let el=e.target;for(let k=0;k<i;k++)el=el.parentElement;
 if(el.dataset.cron){const hit=DeckUI.findCron(V6.crons,el.dataset.cron);if(hit)return openSheet(DeckUI.cronSheet(hit.j,hit.paused,Date.now()),el)}
 if(el.dataset.unit&&DeckUI.unitOk(el.dataset.unit))return openUnit(el.dataset.unit,el);
 if(el.dataset.sync)return openSheet(DeckUI.syncSheet(typeof fleetLast!=='undefined'&&fleetLast?fleetLast.backup:null,el.dataset.sync,Date.now()),el);
 openSheet(DeckUI.cardSheet(el.innerHTML,pg.dataset.label),el)});
// The iPhone shell (user agent OmarchyDeck/) loads same-origin target=_blank links in place and opens off-origin ones in Safari; the attribute is dropped on click so a link there behaves as a plain one.
if(DeckUI.isDeckShell(navigator.userAgent))document.addEventListener('click',e=>{const a=e.target&&e.target.closest&&e.target.closest('a[target]');
 if(a&&DeckUI.dropsTarget(navigator.userAgent,a.tagName,a.getAttribute('target')))a.removeAttribute('target')},true);
// ---- feel and recovery: a tick on tab and chip taps; every empty state's Try again button reloads its own page ----
const RETRY={page:()=>deckPage(pname(),false),cluster:()=>v6Cluster(),dev:()=>v6Dev(),keys:()=>v7Keys(),home:()=>v7Home(),life:()=>v6Life(),crons:()=>v8Crons(),shop:()=>v9Shop(),commerce:()=>v12Commerce(),money:()=>v9Money(),schedules:()=>typeof v10Schedules==='function'?v10Schedules():null,agents:()=>typeof v11Agents==='function'?v11Agents():null,invest:()=>typeof v10Invest==='function'?v10Invest():null,launch:()=>v6Launch(true),
 today:()=>{if(typeof today=='function')today();return v7Today()},fleet:()=>typeof fleet=='function'?fleet():null};
document.addEventListener('click',e=>{const t=e.target&&e.target.closest?e.target:null;if(!t)return;
 const r=t.closest('.es-retry');
 if(r){buzz('selection');r.disabled=true;r.textContent='Trying\u2026';setTimeout(()=>{if(r.isConnected){r.disabled=false;r.textContent='Try again'}},6000);
  try{Promise.resolve((RETRY[r.dataset.retry]||RETRY.page)()).catch(()=>{})}catch(err){}return}
 if(t.closest('#pgs button,.chips button,#hosts button,#ptg button'))buzz('selection')});
// "Copy retry command" (Shop failing sources): the deck never runs a collector, it copies the exact command the feed allows for the owner's terminal
document.addEventListener('click',e=>{const b=e.target&&e.target.closest?e.target.closest('button.cpy'):null;if(!b||!b.dataset.cmd)return;
 const done=ok=>{b.textContent=ok?'Copied':'Copy failed';setTimeout(()=>{if(b.isConnected)b.textContent='Copy retry command'},2500)};
 const legacy=()=>{try{const a=document.createElement('textarea');a.value=b.dataset.cmd;a.setAttribute('readonly','');a.style.cssText='position:fixed;opacity:0;top:0';document.body.appendChild(a);a.select();const ok=document.execCommand('copy');a.remove();done(ok)}catch(err){done(false)}};
 try{if(navigator.clipboard&&navigator.clipboard.writeText)navigator.clipboard.writeText(b.dataset.cmd).then(()=>done(true),legacy);else legacy()}catch(err){legacy()}});
{const h=$('#lnhelp');if(h)h.textContent='Tap Hermes, then tap again within 3 seconds to confirm. The run window opens so you can follow along. Closing it keeps the run; Last run brings it back.'}
// ---- v9 Shop tab (GET /api/ecom, /api/listings and the Amazon view /api/amazon) ----
// the page opens the long lists short (DeckUI.SHOP_WATCH watch cards, SHOP_AMZ Amazon cards); Show more / Show fewer repaint from the feeds already read
const SHOPV={f:null,l:null,a:null,view:{watch:DeckUI.SHOP_WATCH,amz:DeckUI.SHOP_AMZ,lst:DeckUI.SHOP_LIST}};
function paintShop(){try{fillCols(['sh1','sh2','sh3'],DeckUI.shop(SHOPV.f,Date.now(),SHOPV.l,SHOPV.a,SHOPV.view),'Shop')}catch(e){$('#sh1').innerHTML=renderFail('Shop')}}
const v9Shop=()=>once('shop',async()=>{const [f,l,a]=await Promise.all([feedGet('ecom'),feedGet('listings'),feedGet('amazon')]);Object.assign(SHOPV,{f,l,a});paintShop()});
{const sp=$('#shop');if(sp)sp.addEventListener('click',e=>{const b=e.target.closest&&e.target.closest('button[data-more^="shop-"]');if(!b)return;
 const k=b.dataset.more==='shop-amz'?'amz':b.dataset.more==='shop-lst'?'lst':'watch',lo=k==='amz'?DeckUI.SHOP_AMZ:k==='lst'?DeckUI.SHOP_LIST:DeckUI.SHOP_WATCH;
 SHOPV.view[k]=b.dataset.less?lo:SHOPV.view[k]+DeckUI.SHOP_STEP;paintShop()})}
// ---- Commerce tab (GET /api/commerce). A tile opens a read-only page on the computer picked in the top bar (POST /api/launch). ----
const cmHost=()=>typeof host==='string'?host:'pc-desktop';
// Order amounts stay masked until a Reveal tap, and hide again after FIN_HIDE_MS, when the page is hidden, in ambient mode and when
// another tab comes on screen. /api/commerce is cookie only and same-origin only on the server (amount_gate), fetched no-store.
const CM={c:null,rev:false,t:0};
function paintCommerce(){try{fillCols(['cm1','cm2','cm3'],DeckUI.commerce(CM.c,Date.now(),cmHost(),CM.rev),'Commerce')}catch(e){$('#cm1').innerHTML=renderFail('Commerce')}}
function cmHide(){if(CM.t){clearTimeout(CM.t);CM.t=0}if(CM.rev){CM.rev=false;paintCommerce()}}
const v12Commerce=()=>once('commerce',async()=>{CM.c=await fetch('/api/commerce',{cache:'no-store',credentials:'same-origin'}).then(r=>r.ok?r.json():{error:'http '+r.status}).catch(()=>null);
 paintCommerce()});
{const hit=e=>{const b=e.target.closest?e.target.closest('button.cmr'):null;if(!b)return;
  if(b.dataset.rev!=='1'){cmHide();return}
  CM.rev=true;if(CM.t)clearTimeout(CM.t);CM.t=setTimeout(cmHide,DeckUI.FIN_HIDE_MS);paintCommerce()};
 ['cm1','cm2','cm3'].forEach(id=>{const el=$('#'+id);if(el)el.addEventListener('click',hit)})}
document.addEventListener('visibilitychange',()=>{if(document.hidden)cmHide()});
addEventListener('pagehide',()=>cmHide());
setInterval(()=>{if(CM.rev&&typeof mode!=='undefined'&&mode==='ambient')cmHide()},1000);
document.addEventListener('click',async e=>{const b=e.target&&e.target.closest?e.target.closest('button[data-cm]'):null;if(!b||b.disabled)return;
 const s=b.querySelector('small'),was=s?s.textContent:'';b.disabled=true;buzz('light');if(s)s.textContent='Opening\u2026';
 let r=null;try{r=await q('launch?v='+encodeURIComponent(b.dataset.cm),1)}catch(err){r={error:'The deck did not answer'}}
 const ok=r&&!r.error&&r.ok!==false;if(s)s.textContent=ok?'Opened on '+(cmHost()==='Dell'?'Dell':'PC'):String((r&&r.error)||'Did not open').slice(0,80);buzz(ok?'success':'error');
 setTimeout(()=>{b.disabled=false;if(s)s.textContent=was},4000)});
// the tiles say which computer they open on: repaint when the top-bar host changes
document.addEventListener('click',e=>{if(e.target&&e.target.closest&&e.target.closest('#hosts button,#swap'))setTimeout(()=>{if(pname()==='commerce')paintCommerce()},0)});
// ---- v9 Money tab. /api/finance carries statuses only and loads with the page. Amounts come from /api/finance-values, requested only on a
// Reveal tap, held in FINC (DeckUI.finCtl) alone, hidden after 30 s, when the page is hidden, and when another tab comes on screen.
// Nothing financial goes into a URL, browser storage or a log; both routes are fetched with cache:'no-store'.
const FIN={f:null};
const finGet=p=>fetch(p,{cache:'no-store',credentials:'same-origin'}).then(r=>r.ok?r.json():{error:'http '+r.status});
const FINC=DeckUI.finCtl({get:finGet,setT:(fn,ms)=>setTimeout(fn,ms),clearT:t=>clearTimeout(t),now:()=>Date.now(),onChange:()=>paintMoney()});
function paintMoney(){
 try{fillCols(['mn1','mn2','mn3'],DeckUI.fin(FIN.f,Date.now(),FINC.view()),'Money')}catch(e){$('#mn1').innerHTML=renderFail('Money')}}
const v9Money=()=>once('money',async()=>{FIN.f=await finGet('/api/finance').catch(()=>null);paintMoney()});
{const hit=e=>{const b=e.target.closest('button.fr,button.fh');if(!b||b.disabled)return;
  if(b.classList.contains('fh')){if(b.dataset.app)FINC.drop(b.dataset.app);else FINC.hide();return}
  FINC.reveal(b.dataset.all?'*':(b.dataset.app||''))};
 ['mn1','mn2','mn3'].forEach(id=>{const el=$('#'+id);if(el)el.addEventListener('click',hit)})}
document.addEventListener('visibilitychange',()=>{if(document.hidden)FINC.hide()});
addEventListener('pagehide',()=>FINC.hide());
// one-second tick: expire reveals even if a timer was throttled, hide in ambient mode, keep the countdown honest without repainting
setInterval(()=>{const v=FINC.view();if(!Object.keys(v.exp).length)return;
 if(typeof mode!=='undefined'&&mode==='ambient'){FINC.hide();return}
 if(FINC.sweep())return;
 const now=Date.now();document.querySelectorAll('.fcd[data-exp]').forEach(el=>{el.textContent=DeckUI.fcdText(+el.dataset.exp,now)})},1000);
function paintMarketHead(){const el=$('#mhead');if(!el)return;once('mhead',async()=>{const t=await feedGet('today');
 try{el.innerHTML=DeckUI.markets(t,Date.now(),!t||!!t.error)}catch(e){el.innerHTML=renderFail('Markets')}})}
// called by app.js when a page comes on screen (tick=false) and every 15 s while it stays (tick=true).
// A guest deck (app.js GUEST) loads none of these: its Home and Keys skip the products and accounts feeds.
function deckPage(name,tick){const age=n=>Date.now()-(V6.t[n]||0);if(GUEST)return;
 if(name!=='money')FINC.hide();
 if(name!=='commerce')cmHide();
 if(name==='cluster')v6Cluster();
 else if(name==='dev'&&(!tick||age('dev')>60000))v6Dev();
 else if(name==='life'&&(!tick||age('life')>60000))v6Life();
 else if(name==='launch'&&!tick)v6Launch(false);
 else if(name==='crons'&&(!tick||age('crons')>30000))v8Crons();
else if(name==='schedules'&&typeof v10Schedules==='function'&&(!tick||age('schedules')>30000))v10Schedules();
 else if(name==='agents'&&typeof v11Agents==='function'&&(!tick||age('agents')>30000))v11Agents();
 else if(name==='shop'&&(!tick||age('shop')>60000))v9Shop();
 else if(name==='commerce'&&(!tick||age('commerce')>60000))v12Commerce();
 else if(name==='money'&&(!tick||age('money')>60000))v9Money();
 else if(name==='keys'&&(!tick||age('keys')>60000))v7Keys();
 else if(name==='home'&&(!tick||age('home')>60000))v7Home();
 else if((name==='markets'||name==='invest')&&(!tick||age('mhead')>60000))paintMarketHead();
 else if(name==='today'&&(!tick||age('today')>30000))v7Today();
 else if(name==='launch'&&tick&&age('launch')>3600000)v6Launch(false);
 else if(name==='home'&&tick&&age('home')>3600000)v7Home()}
// app.js boots before this file exists, so the page the deck opens on gets its first deck.js render here
if(!document.hidden)deckPage(pname(),false);
