// Offline shell cache. Never touches /api/ or non-GET.
// Stale while revalidate: the cached shell answers at once (no blank or spinner first paint), the network copy
// refreshes the cache for the next open. Updates still land immediately through the worker itself:
// bump V with every shell change; install precaches fresh files, activate() deletes every other cache, and app.js
// reloads once when the new worker takes control. First visits and the ?t= cookie bootstrap always use the network.
const V='pdeck-shell-v67',SHELL=['/','/app.js','/deck.js','/schedules.js','/agents.js','/pad.js','/invest.js','/ops.js','/theme.css','/manifest.webmanifest','/icon-192.png','/icon-512.png','/icon.svg','/apple-touch-icon.png'];
self.addEventListener('install',e=>{e.waitUntil(caches.open(V).then(c=>Promise.all(SHELL.map(u=>fetch(u,{credentials:'same-origin',cache:'reload'}).then(r=>r.ok&&c.put(u,r)).catch(()=>0)))).then(()=>self.skipWaiting()))});
self.addEventListener('activate',e=>{e.waitUntil(caches.keys().then(ks=>Promise.all(ks.filter(k=>k!==V).map(k=>caches.delete(k)))).then(()=>self.clients.claim()))});
self.addEventListener('fetch',e=>{
 const r=e.request,u=new URL(r.url);
 // Finance (v9 Money tab): never cached, never answered by the worker. The generic /api/ rule below already covers it;
 // this one is explicit so a later edit of that rule cannot start caching amounts. Tested in tests/deck_v9_money.test.js.
 if(u.pathname==='/api/finance'||u.pathname==='/api/finance-values')return;
 // Invest tab amounts (v10): same rule, never answered or cached by the worker.
 if(u.pathname==='/api/portfolio-values')return;
 if(r.method!=='GET'||u.origin!==location.origin||u.pathname.startsWith('/api/'))return;
 if(!SHELL.includes(u.pathname)||u.searchParams.has('t'))return;
 e.respondWith(caches.open(V).then(async c=>{
  const hit=await c.match(u.pathname);
  const net=fetch(r).then(res=>{
   if(res.ok)c.put(u.pathname,res.clone());
   else if(res.status===401&&u.pathname==='/')c.delete('/');
   return res}).catch(()=>null);
  if(hit){e.waitUntil(net);return hit}
  return (await net)||new Response('offline',{status:503});
 }));
});
