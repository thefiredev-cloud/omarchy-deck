// ---- burn-in guard timings (ms). Test override: #t=<dimSec>,<ambientSec> in the URL hash ----
const DIM_MS=2*60*1000, AMBIENT_MS=10*60*1000, DRIFT_MS=60*1000, SHIFT_MS=3*60*1000, DIM_OPACITY=0.35, SHIFT_MAX_PX=3;
const HASH=location.hash,SEARCH=location.search;history.replaceState(null,'','/');
// ?p=<page> opens one page on load (a link, a screenshot script); no query keeps the remembered page.
const DEEP=new URLSearchParams(SEARCH).get('p')||(HASH.match(/p=([a-z]+)/)||[])[1]||'';
const _t=(HASH.match(/t=(\d+),(\d+)/)||[]);
const T_DIM=_t[1]?+_t[1]*1000:DIM_MS, T_AMB=_t[2]?+_t[2]*1000:AMBIENT_MS;
let booted=false,host=localStorage.getItem('host')||'pc-desktop',busy=0,fbusy=0,page=0,keys=[],lastMedia={},ws=null,lastWs=null;
const $=s=>document.querySelector(s),$$=s=>document.querySelectorAll(s);
// Guest deck (owner 2026-10-13): GET /api/whoami names the principal behind the cookie, read once before the pager is built.
// A guest sees Home (the house part only) and Pad. Keys is a chip on Pad. This is cosmetic:
// the server's guest allowlist is the control. Offline, the last answer stands.
const GUEST_PAGES=['home','pad'];
const GUEST=(()=>{let r=null;try{const x=new XMLHttpRequest();x.open('GET','/api/whoami',false);x.send();if(x.status===200)r=JSON.parse(x.responseText).role}catch(e){}
 if(r==='guest'||r==='owner')localStorage.setItem('role',r);else r=localStorage.getItem('role');return r==='guest'})();
if(GUEST){document.documentElement.classList.add('guest');$$('#pager>.page').forEach(p=>{if(!GUEST_PAGES.includes(p.dataset.name))p.hidden=true});$$('#ptg [data-t=mini]').forEach(b=>b.remove())}
const q=(p,post)=>fetch('/api/'+p+(p.includes('?')?'&':'?')+'host='+encodeURIComponent(host),{method:post?'POST':'GET'}).then(r=>r.json());
const other=()=>host=='pc-desktop'?'Dell':'pc-desktop';
// one name per machine on every control (the server ids stay pc-desktop and Dell)
const HOSTNAME={'pc-desktop':'PC',Dell:'Dell'},hostName=h=>HOSTNAME[h]||h;
const esc=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
// Haptics (shell contract 3): the iOS shell registers `deckHaptic`; in every other browser this does nothing.
// style: selection | light | medium | success | warning | error. The shell ignores unknown styles and rate-limits itself.
function haptic(style){try{window.webkit?.messageHandlers?.deckHaptic?.postMessage({style})}catch(e){}}
window.deckHaptic=haptic;
const reduceMotion=()=>matchMedia('(prefers-reduced-motion: reduce)').matches;
let wxText='',errText='',errMsg='',wxParts=[];
function showSt(){const st=$('#st'),box=$('#status');st.textContent=errText||wxText;box.className=errText?'bad':'';box.title=errText||wxText;
 // a failed command is a pill of two lines at most: when the host prefix does not fit, the message stands alone, whole
 if(errText){if(errMsg&&st.scrollHeight>st.clientHeight+1)st.textContent=errMsg}else fitSt()}
// weather never truncates: drop trailing parts whole, then the text itself; nothing is ever cut mid-word
function fitSt(){const st=$('#st');if(!wxParts.length)return;let parts=wxParts.slice();const put=()=>{st.textContent=parts.join(' \u00B7 ')};
 put();const over=()=>st.scrollWidth>st.clientWidth+1;
 while(over()&&parts.length>1){parts=parts.slice(0,-1);put()}
 if(over())st.textContent=''}
function flag(r){errMsg=(r&&r.error)?(typeof DeckUI==='object'?DeckUI.humanErr(r,0).split('. ')[0]:'That did not go through'):'';errText=errMsg?hostName(host)+': '+errMsg:'';showSt()}
// Home, the Keys sub page and Pad show the host readouts (media, volume, workspaces); no other page polls them
const hostPage=()=>{const n=pname();return n==='home'||n==='pad'};
function setHost(h){host=h;localStorage.setItem('host',h);$$('#hosts button').forEach(b=>b.classList.toggle('on',b.dataset.h==h));$('#sh').textContent=hostName(h);$('#swapl').textContent=hostName(other());booted=true;lastWs=null;if(hostPage()){refresh();if(pname()==='home')stats()}}
$$('#hosts button').forEach(b=>b.onclick=()=>setHost(b.dataset.h));
$('#swap').onclick=()=>setHost(other());
$$('button[data-a]').forEach(b=>b.onclick=async()=>{const r=await q(b.dataset.a+'?v='+(b.dataset.v||''),1);flag(r);refresh()});
$('#lock').onclick=async()=>{const l=$('#lock');if(l.dataset.arm){delete l.dataset.arm;l.classList.remove('armed');l.querySelector('span').textContent='Lock';flag(await q('lock',1))}else{l.dataset.arm=1;l.classList.add('armed');l.querySelector('span').textContent='Tap again';setTimeout(()=>{delete l.dataset.arm;l.classList.remove('armed');l.querySelector('span').textContent='Lock'},3000)}};
// volume (home + focus sliders)
function showVol(v){$('#vs').value=v;$('#vs').style.setProperty('--p',v+'%');$('#vp').textContent=v+'%'}
async function setVol(v){v=Math.max(0,Math.min(100,v));showVol(v);busy=Date.now();flag(await q('vol-set?v='+v,1))}
{const s='#vs';$(s).oninput=()=>{busy=Date.now();showVol($(s).value)};$(s).onchange=()=>setVol(+$(s).value)}
$('#vdn').onclick=()=>setVol(+$('#vs').value-5);$('#vup').onclick=()=>setVol(+$('#vs').value+5);
// presets: one tap to a common level instead of holding + or dragging the slider
$$('#volp button').forEach(b=>b.onclick=()=>setVol(+b.dataset.v));
// Workspaces: one row of numbers; the chip picks go-to or move-window. A tap is always a tap, the deck
// never switches workspace by itself and never touches workspace 1 on its own.
let wsMode=localStorage.getItem('ws-mode')=='move'?'move':'go';
function paintWsMode(){const b=$('#wsmd');if(!b)return;b.textContent=wsMode=='move'?'move':'go';$('#cc').classList.toggle('move',wsMode=='move');
 b.setAttribute('aria-label','Workspace buttons: '+(wsMode=='move'?'move the focused window':'switch workspace')+'. Tap to change.')}
$('#wsmd').onclick=()=>{wsMode=wsMode=='move'?'go':'move';localStorage.setItem('ws-mode',wsMode);paintWsMode()};
$('#wsrow').addEventListener('click',async e=>{const b=e.target.closest('button[data-n]');if(!b)return;
 flag(await q((wsMode=='move'?'mvws':'ws')+'?v='+b.dataset.n,1));setTimeout(refresh,400)});
paintWsMode();
// ---- refresh (media, vol, ws-now) ----
function fmtSt(m){return m.player?(m.player+(m.status&&m.status!='Playing'?' · '+m.status.toLowerCase():'')):''}
// transport and mute are drawn icons, never colour emoji (they follow the text colour and the theme); innerHTML is rewritten only when the state changes
const IC=p=>'<svg viewBox="0 0 24 24" aria-hidden="true">'+p+'</svg>';
const ICON_PLAY=IC('<path d="M7 4.8v14.4c0 .9 1 1.4 1.7.9l10.8-7.2c.6-.4.6-1.4 0-1.8L8.7 3.9C8 3.4 7 3.9 7 4.8z" fill="currentColor"/>');
const ICON_PAUSE=IC('<rect x="6" y="4.5" width="4" height="15" rx="1.2" fill="currentColor"/><rect x="14" y="4.5" width="4" height="15" rx="1.2" fill="currentColor"/>');
const ICON_MUTE=IC('<path d="M4 9.5h3.5L12 5.8v12.4l-4.5-3.7H4z" fill="currentColor"/><path d="M16 9.5l5 5M21 9.5l-5 5" stroke="currentColor" stroke-width="2" stroke-linecap="round" fill="none"/>');
const ICON_SOUND=IC('<path d="M4 9.5h3.5L12 5.8v12.4l-4.5-3.7H4z" fill="currentColor"/><path d="M15.5 9a4.2 4.2 0 010 6M18 6.8a7.5 7.5 0 010 10.4" stroke="currentColor" stroke-width="2" stroke-linecap="round" fill="none"/>');
let ppKey='',muteKey='';
// ==== SPACES UI HELPERS BEGIN (pure: no DOM, no fetch; tests/spaces_ui.test.js loads this block) ====
// Workspaces 1 to 5 with the apps open on each (GET /api/ws-list, window classes only, never a title). Anything off-shape reads as empty, never as a guess.
const SpacesUI=(()=>{
 const isObj=x=>x!==null&&typeof x==='object'&&!Array.isArray(x);
 const cnt=v=>Number.isInteger(v)&&v>=0?Math.min(v,99):0;
 const norm=w=>{const o=isObj(w)?w:{};return {n:cnt(o.n),apps:(Array.isArray(o.apps)?o.apps:[]).filter(a=>typeof a==='string'&&/^[A-Za-z0-9][A-Za-z0-9 .+]{0,19}$/.test(a)).slice(0,3),more:cnt(o.more)}};
 const parse=j=>{const ws={};if(!isObj(j)||j.ok!==true||!Array.isArray(j.ws))return {ok:false,active:null,ws,other:norm(null)};
  for(const w of j.ws){if(!isObj(w)||!Number.isInteger(w.id)||w.id<1||w.id>5)continue;ws[w.id]=norm(w)}
  return {ok:true,active:Number.isInteger(j.active)&&j.active>=1&&j.active<=5?j.active:null,ws,other:norm(j.other)}};
 // the tile line: the first app and how many windows are open besides it ("Chromium +4"), "Empty" for none, nothing while unknown
 const tile=w=>!w?'':!w.n?'Empty':(w.apps[0]||'Window')+(w.n>1?' +'+(w.n-1):'');
 // the same tile when it is too narrow for a name (landscape, 25 keys on one screen): a count, never a cut word ("5 open")
 const short=w=>!w?'':!w.n?'Empty':w.n+' open';
 // the whole list for a screen reader and the long press title
 const full=(id,w,on)=>'Workspace '+id+(!w?'':!w.n?', empty':': '+(w.apps.length?w.apps.join(', ')+(w.more?' and '+w.more+' more':''):w.n+' windows'))+(on?', current':'');
 return {parse,norm,tile,short,full};
})();
// ==== SPACES UI HELPERS END ====
// every workspace button (Home card and Keys tab) shows the apps on it and which one you are on
let spacesSeen=null; // the last [ws-list answer, ws-now id], so keys drawn later show the apps at once
function paintSpaces(j,fallbackActive){spacesSeen=[j,fallbackActive];const p=SpacesUI.parse(j),active=p.ok?p.active:(Number.isInteger(fallbackActive)?fallbackActive:null);
 $$('[data-a=ws],[data-ws]').forEach(b=>{const id=+(b.dataset.v||b.dataset.ws),w=p.ok?(p.ws[id]||SpacesUI.norm(null)):null,on=active===id;
  b.classList.toggle('on',on);b.setAttribute('aria-label',SpacesUI.full(id,w,on));b.title=b.getAttribute('aria-label');
  const af=b.querySelector('.ap .af'),ac=b.querySelector('.ap .ac');if(af&&af.textContent!==SpacesUI.tile(w))af.textContent=SpacesUI.tile(w);if(ac&&ac.textContent!==SpacesUI.short(w))ac.textContent=SpacesUI.short(w)})}
async function refresh(){
 try{
 const [m,v,w,wl]=await Promise.all([q('media'),q('vol'),q('ws-now'),q('ws-list').catch(()=>null)]);flag(m.error?m:null);lastMedia=m;
 const t=m.title||(m.error?'Unreachable':'Nothing playing'),playing=!!m.title;
 $('#title').textContent=t;$('#artist').textContent=m.artist||'';$('#pl').textContent=fmtSt(m);
 {const ns=$('#npstate'),w=m.error?'Unreachable':!playing?'Idle':m.status&&m.status!='Playing'?'Paused':'Playing';if(ns.textContent!==w)ns.textContent=w;ns.classList.toggle('on',w==='Playing')}
  {const k=m.status=='Playing'?'pause':'play';if(ppKey!==k){ppKey=k;$('#pp').innerHTML=k==='pause'?ICON_PAUSE:ICON_PLAY}}
 $('#np').classList.toggle('idle',!playing);
 {const a=artSrc(m.art,location.origin),im=$('#art');if(a&&playing){im.src=a;im.hidden=false}else im.hidden=true}
 $('#ambtrk').textContent=playing?(m.title+(m.artist?' \u00B7 '+m.artist:'')):'';
 if(v.volume!=null&&Date.now()-busy>3000)showVol(v.volume);
 {const k=v.muted?'sound':'mute';if(muteKey!==k){muteKey=k;$('#mute').innerHTML=k==='sound'?ICON_SOUND:ICON_MUTE}}$('#mute').classList.toggle('on',!!v.muted);
 ws=w.ws;paintSpaces(wl,w.ws);
 ctx();
}catch(e){errText='offline';errMsg='';showSt()}
}
// Focus mode removed by owner request 2026-09-29. No automatic layout switching. ctx() is a no-op kept for callers.
function ctx(){}
// ---- stats ----
function g(n,val,pct,sub,hot){$('#s'+n).textContent=val;$('#b'+n).style.width=(pct||0)+'%';$('#t'+n).textContent=sub||'';$('#b'+n).classList.toggle('hot',!!hot)}
async function stats(){try{const s=await q('stats');
 g(1,s.cpu_pct!=null?s.cpu_pct+'%':'--',s.cpu_pct,s.cpu_temp?s.cpu_temp+'\u00B0C':(s.load?'load '+s.load[0]:''),s.cpu_temp>=85);
 g(2,s.ram_pct!=null?s.ram_pct+'%':'--',s.ram_pct,s.ram_gb?'of '+Math.round(s.ram_gb)+' GB':'',s.ram_pct>=95);
 g(3,s.gpu_util!=null?s.gpu_util+'%':'n/a',s.gpu_util,s.gpu_temp!=null?s.gpu_temp+'\u00B0C':'',s.gpu_temp>=85);
}catch(e){}}
async function wx(){try{const raw=String((await fetch('/api/weather').then(r=>r.json())).text||'');
 wxParts=raw.split('\u00B7').map(x=>x.trim().replace(/^Temp\s+/,'').replace(/Wind\s*(\S+?)\s*(\d+)\s*mph/,'Wind $1 $2 mph').replace(/\s{2,}/g,' ')).filter(Boolean);wxText=wxParts.join(' \u00B7 ');showSt()}catch(e){}}
function clock(){const d=new Date(),t=d.toLocaleTimeString([],{hour:'numeric',minute:'2-digit'});$('#clock').textContent=t;$('#ambclock').textContent=t;$('#date').textContent=d.toLocaleDateString([],{weekday:'short',month:'short',day:'numeric'})}
// Fullscreen and orientation lock exist on the Pixel (Brave/Chrome) but not on iPhone Safari. The iPhone home-screen app and the
// OmarchyDeck shell are already full screen, and the shell keeps its own control in the top-right corner (--shell-reserve-top-right):
// there the button hides and nothing is requested.
const IN_SHELL=/OmarchyDeck\//.test(navigator.userAgent||'');
const canFS=!IN_SHELL&&!!(document.fullscreenEnabled&&document.documentElement.requestFullscreen);
if(!canFS)document.documentElement.classList.add('nofs');
async function goFull(){if(!canFS)return;try{if(!document.fullscreenElement)await document.documentElement.requestFullscreen({navigationUI:'hide'});if(screen.orientation&&screen.orientation.lock)await screen.orientation.lock('landscape')}catch(e){}}
$('#fs').onclick=()=>document.fullscreenElement?document.exitFullscreen():goFull();
if(canFS)document.addEventListener('pointerdown',()=>{if(!document.fullscreenElement&&!localStorage.getItem('nofs'))goFull()},{once:true});
// ---- secure context + wake lock ----
if(window.isSecureContext)$('#sec').style.display='inline-flex';
let wl=null;
async function wake(){try{if(window.isSecureContext&&navigator.wakeLock&&!document.hidden&&(!wl||wl.released)){wl=await navigator.wakeLock.request('screen');wl.addEventListener('release',()=>{wl=null})}}catch(e){}}
document.addEventListener('visibilitychange',()=>{syncCameras();if(document.hidden){saveAllScroll();return}wl=null;wake();pageVisible();if(swReg)swReg.update().catch(()=>{})});
// Shell cache: the browser always revalidates sw.js (updateViaCache none); a new worker takes over and the
// page reloads once so the phone never keeps an old build.
let swReg=null;
if('serviceWorker' in navigator&&window.isSecureContext){const hadSW=!!navigator.serviceWorker.controller;let reloaded=false;
 navigator.serviceWorker.register('/sw.js',{scope:'/',updateViaCache:'none'}).then(r=>{swReg=r}).catch(()=>{});
 navigator.serviceWorker.addEventListener('controllerchange',()=>{if(hadSW&&!reloaded){reloaded=true;location.reload()}})}
// ---- pager: pages come from the DOM order; tabs are built from data-name / data-label. The tabs are the one page indicator (no dots). ----
const pager=$('#pager'),PAGES=[...$$('#pager>.page:not([hidden])')],pname=()=>(PAGES[page]&&PAGES[page].dataset.name)||'';
$('#pgs').innerHTML=PAGES.map((p,i)=>'<button class="press" data-p="'+i+'" data-n="'+esc(p.dataset.name)+'" data-t="'+esc(p.dataset.label||p.dataset.name)+'">'+esc(p.dataset.label||p.dataset.name)+'</button>').join('');
let shown=-1,quietUntil=0;
function showTab(i,instant){shown=i;$$('#pgs button').forEach(b=>{const on=+b.dataset.p==i;b.classList.toggle('on',on);if(on)b.setAttribute('aria-current','page');else b.removeAttribute('aria-current')});
 // Horizontal overflow hides pages visually, not from keyboard focus or VoiceOver. Keep only the shown page interactive.
 PAGES.forEach((p,k)=>{p.inert=k!==i});
 $('#app').dataset.page=(PAGES[i]&&PAGES[i].dataset.name)||'';revealTab(i,instant);tabEdges()}
// Keep the active tab clear of the 32 px edge fades (#pgs.more/.less): the strip moves only when the tab sits inside a fade zone plus 12 px, and never snaps under Reduce Motion.
const TAB_FADE=32,TAB_M=TAB_FADE+12;
function revealTab(i,instant){const s=$('#pgs'),b=s&&$('#pgs button[data-p="'+i+'"]');if(!b)return;
 const sr=s.getBoundingClientRect(),br=b.getBoundingClientRect(),M=TAB_M;let d=0;
 if(br.left<sr.left+M)d=br.left-sr.left-M;else if(br.right>sr.right-M)d=br.right-sr.right+M;
 const to=Math.max(0,Math.min(s.scrollWidth-s.clientWidth,Math.round(s.scrollLeft+d)));
 if(d&&to!=Math.round(s.scrollLeft))s.scrollTo({left:to,behavior:instant||reduceMotion()?'instant':'smooth'})}
function tabEdges(){const s=$('#pgs');s.classList.toggle('less',s.scrollLeft>2);s.classList.toggle('more',s.scrollLeft+s.clientWidth<s.scrollWidth-2)}
$('#pgs').addEventListener('scroll',tabEdges,{passive:true});
// The strip changes size after a rotation, when a font loads, or when the status text beside it fills in; keep the active tab in view (a landscape iPhone showed Money last and Pad off the right edge).
if(typeof ResizeObserver==='function'){let sig='';const ro=new ResizeObserver(()=>{const s=$('#pgs'),g=s.clientWidth+':'+s.scrollWidth;if(g===sig)return;sig=g;if(shown>=0)revealTab(shown,true);tabEdges()});ro.observe($('#pgs'));$$('#pgs button').forEach(b=>ro.observe(b))}
if(document.fonts&&document.fonts.ready)document.fonts.ready.then(()=>{if(shown>=0)revealTab(shown,true)});
// goal: the page a tab tap is scrolling to. A resize mid-scroll (first tap enters fullscreen on the
// Pixel, or the iPhone rotates) snaps to the goal instead of back to the old page.
let goal=null;
function goPage(i,instant){goal=i;pager.scrollTo({left:i*pager.clientWidth,behavior:instant||reduceMotion()?'instant':'smooth'})}
$$('#pgs button').forEach(b=>b.onclick=()=>goPage(+b.dataset.p));
// The tabs follow the finger (one rAF per frame, class toggles only: no layout reads beyond scrollLeft). The page itself settles
// 90 ms after the last scroll event, and only then do data refreshes run. A swipe that crosses a page ticks `selection` once.
let scT=0,trT=0;
const nearest=()=>{const w=pager.clientWidth;return w?Math.max(0,Math.min(PAGES.length-1,Math.round(pager.scrollLeft/w))):page};
function track(){trT=0;const i=nearest();if(i!=shown){if(goal==null&&Date.now()>quietUntil)haptic('selection');showTab(i)}}
pager.addEventListener('scroll',()=>{if(!trT)trT=requestAnimationFrame(track);clearTimeout(scT);
 scT=setTimeout(()=>{const i=nearest();goal=null;if(i!=page){page=i;localStorage.setItem('page',pname());showTab(i);pageVisible()}},90)},{passive:true});
addEventListener('resize',()=>{const to=goal??page;quietUntil=Date.now()+400;pager.style.scrollBehavior='auto';pager.scrollLeft=to*pager.clientWidth;pager.style.scrollBehavior='';fitKeys();ctx();showTab(to,true);showSt()});
// entering fullscreen cancels a smooth scroll in flight without a resize; finish it instantly
document.addEventListener('fullscreenchange',()=>{if(goal!=null)goPage(goal,true)});
// ---- glass bars float over the content. Pages scroll under the top bar and start below it (--under); the run window's thread scrolls under its bar and composer (--rtop, --rbot). ----
function fitUnder(){const t=$('#top'),a=$('#app');if(!t||!a)return;const u=t.offsetTop+t.offsetHeight;if(u>0)a.style.setProperty('--under',Math.ceil(u+8)+'px');
 const rp=$('#runp'),rb=$('#runbar'),rc=$('#runc');if(rp&&rb&&rc&&rp.clientHeight>0){rp.style.setProperty('--rtop',Math.ceil(rb.offsetTop+rb.offsetHeight+8)+'px');rp.style.setProperty('--rbot',Math.ceil(rp.clientHeight-rc.offsetTop+8)+'px')}}
if(typeof ResizeObserver==='function'){const ro=new ResizeObserver(fitUnder);['#top','#runp','#runbar','#runc'].forEach(s=>{const e=$(s);if(e)ro.observe(e)})}
addEventListener('resize',fitUnder);fitUnder();
// the bar lifts (a deeper shadow) while any page is scrolled beneath it; the scroll position is kept for a reload and the Top button follows it
let svT=0;
document.addEventListener('scroll',e=>{const el=e.target;if(!el||el===pager||el.id==='pgs'||!el.closest||!el.closest('#pager'))return;$('#top').classList.toggle('lift',el.scrollTop>2);
 if(el.classList&&el.classList.contains('jnav'))return;paintTop();clearTimeout(svT);const pg=el.closest('.page');svT=setTimeout(()=>saveScroll(pg),1000)},{capture:true,passive:true});
// ---- long pages: a jump strip of section chips under the bar (portrait), a Top button, and each page's scroll kept across a reload (the iOS shell's Reload deck) ----
// ==== SCROLL NAV HELPERS BEGIN (pure: no DOM; tests/deck20261029_webshell.test.js loads this block) ====
const ScrollNav=(()=>{
 const MAX=8;
 // at most MAX chips, spread over the whole page so the last section always has one
 const pick=(list,max)=>{const n=list.length,m=max||MAX;if(n<=m)return list.slice();const out=[];for(let i=0;i<m;i++)out.push(list[Math.round(i*(n-1)/(m-1))]);return out};
 // a section title as a chip label: whole words, at most 24 characters, never cut mid-word
 const chipName=s=>{const t=String(s==null?'':s).replace(/\s+/g,' ').trim();if(t.length<=24)return t;const w=t.slice(0,25).split(' ');w.pop();return w.join(' ')||t.slice(0,24)};
 // titles in page order, empty and repeated neighbours dropped ("Paused" then "Paused (continued)" keeps both; two "Markets" in a row keep one)
 const names=list=>{const out=[];for(const x of list){const n=chipName(x&&x.name);if(!n)continue;if(out.length&&out[out.length-1].name===n)continue;out.push({...x,name:n})}return out};
 // the strip shows on a page taller than 2.5 screens with two sections or more; the Top button after 1.5 screens of scroll
 const wants=(scrollH,clientH,count)=>count>=2&&clientH>0&&scrollH>2.5*clientH;
 const showTop=(scrollTop,clientH)=>clientH>0&&scrollTop>1.5*clientH;
 // where to scroll so a title sits `gap` px under the strip; past the end a spacer of `tail` px makes the room
 const target=(titleTop,scrollTop,stripBottom,gap,maxScroll)=>{const t=Math.max(0,Math.round(scrollTop+titleTop-stripBottom-gap));return {top:t,tail:Math.max(0,t-Math.max(0,maxScroll))}};
 // a saved position comes back once the page is tall enough to hold it; an entry gives up after `ms`
 const canRestore=(want,scrollH,clientH)=>want>0&&scrollH-clientH>=want-2;
 return {MAX,pick,chipName,names,wants,showTop,target,canRestore};
})();
// ==== SCROLL NAV HELPERS END ====
const isPortrait=()=>innerHeight>innerWidth;
const subOf=pg=>pg&&pg.querySelector(':scope>.sub:not([hidden])');
// what scrolls a page: the page itself in portrait (on Pad only the Keys sub page scrolls), its columns in landscape
function scrollersOf(pg){if(!pg)return [];const sub=subOf(pg);
 if(isPortrait())return pg.dataset.name==='pad'?(sub&&sub.dataset.sub==='keys'?[sub]:[]):[pg];
 return [...pg.querySelectorAll('.cols3>div,#fl1,#fl2,#fl3,#keyswrap,#conn1,#conn2,#lnlist,#sclist')].filter(e=>e.offsetParent!==null&&!e.closest('.sub[hidden]'))}
const scrollId=e=>e.id||'sub-'+(e.dataset.sub||'');
const leafKey=pg=>{const s=subOf(pg);return 'scroll:'+pg.dataset.name+(s?'/'+s.dataset.sub:'')+(isPortrait()?':p':':l')};
const restoring=new Map();
function saveScroll(pg){if(!pg||!pg.dataset)return;try{const o={};scrollersOf(pg).forEach(e=>{const r=restoring.get(e),t=r?r.t:Math.round(e.scrollTop);if(t>0)o[scrollId(e)]=t});sessionStorage.setItem(leafKey(pg),JSON.stringify(o))}catch(e){}}
function saveAllScroll(){PAGES.forEach(saveScroll)}
addEventListener('pagehide',saveAllScroll);
function tryRestore(){const now=Date.now();for(const [e,r] of restoring){if(now>r.until){restoring.delete(e);continue}
 if(ScrollNav.canRestore(r.t,e.scrollHeight,e.clientHeight)){e.scrollTop=r.t;if(Math.abs(e.scrollTop-r.t)<=2)restoring.delete(e)}}}
function restoreScroll(pg){let o=null;try{o=JSON.parse(sessionStorage.getItem(leafKey(pg))||'null')}catch(e){}if(!o||typeof o!=='object')return;
 scrollersOf(pg).forEach(e=>{const t=Number(o[scrollId(e)]);if(t>0)restoring.set(e,{t,until:Date.now()+15000})});tryRestore()}
// a finger on the page wins over a pending restore
pager.addEventListener('pointerdown',()=>restoring.clear(),{passive:true});
const totop=$('#totop');
function paintTop(){const pg=PAGES[page],sc=pg&&isPortrait()?scrollersOf(pg)[0]:null,on=!!sc&&ScrollNav.showTop(sc.scrollTop,sc.clientHeight);if(totop.hidden===on)totop.hidden=!on}
totop.onclick=()=>{const sc=scrollersOf(PAGES[page])[0];if(sc){restoring.delete(sc);sc.scrollTo({top:0,behavior:reduceMotion()?'instant':'smooth'})}};
function sectionTitles(scope){const vis=e=>e.offsetParent!==null&&!(e.closest('details:not([open])')&&!e.closest('summary'));
 let hs=[...scope.querySelectorAll('.secttl,.klab')].filter(e=>vis(e)&&!e.closest('.jnav,#sheet,#runp,#jsh,#jfl'));
 if(hs.length<2)hs=[...scope.querySelectorAll('.tgrp')].filter(vis);
 return ScrollNav.names(hs.map(h=>({el:h,name:((h.classList.contains('klab')?h:h.querySelector(':scope>span'))||h).textContent})))}
// one strip per scroller: on a portrait page under the bar; on the Keys sub page at the top of the key column, in both orientations
function jumpNav(){const pg=PAGES[page];if(!pg)return;const sub=subOf(pg),keysSub=pg.dataset.name==='pad'&&sub&&sub.dataset.sub==='keys'&&isPortrait();
 let host=null,scroller=null;
 if(keysSub){host=$('#keyswrap');scroller=isPortrait()?sub:host}else if(isPortrait()&&pg.dataset.name!=='pad'){host=sub||pg;scroller=pg}
 document.querySelectorAll('.jnav').forEach(n=>{if(n.parentElement!==host)n.remove()});
 if(!host)return paintTop();
 let nav=host.querySelector(':scope>.jnav');
 const all=sectionTitles(keysSub?$('#keys'):host),list=ScrollNav.pick(all);
 const want=keysSub?list.length>=2&&scroller.scrollHeight>scroller.clientHeight+8:ScrollNav.wants(scroller.scrollHeight,scroller.clientHeight,all.length);
 if(!want){if(nav)nav.remove();return paintTop()}
 const sig=list.map(x=>x.name).join('|');
 if(!nav){nav=document.createElement('nav');nav.className='jnav'+(keysSub?' kj':'');nav.setAttribute('aria-label',keysSub?'Key groups':'Sections on this page');host.prepend(nav)}
 if(nav.dataset.sig!==sig){nav.dataset.sig=sig;nav.innerHTML=list.map((x,i)=>'<button type="button" class="b" data-j="'+i+'">'+esc(x.name)+'</button>').join('')}
 nav._titles=list.map(x=>x.el);nav._scroller=scroller;paintTop()}
document.addEventListener('click',e=>{const b=e.target.closest&&e.target.closest('.jnav button[data-j]');if(!b)return;const nav=b.parentElement,el=nav._titles&&nav._titles[+b.dataset.j],sc=nav._scroller;if(!el||!sc||!el.isConnected)return;
 haptic('selection');restoring.delete(sc);
 // land the title 8 px under the strip's real bottom edge, whatever the scroller is
 const strip=nav.getBoundingClientRect();
 const host=nav.parentElement;let tail=host.querySelector(':scope>.jtail');
 const base=tail?tail.offsetHeight:0,max=sc.scrollHeight-sc.clientHeight-base;
 const t=ScrollNav.target(el.getBoundingClientRect().top,sc.scrollTop,strip.bottom,8,max);
 if(t.tail){if(!tail){tail=document.createElement('div');tail.className='jtail';tail.setAttribute('aria-hidden','true');host.appendChild(tail)}tail.style.height=t.tail+'px'}else if(tail)tail.remove();
 sc.scrollTo({top:t.top,behavior:reduceMotion()?'instant':'smooth'})});
// pages paint their feeds after they are shown: rebuild the strip and finish a pending restore when the page's content changes (camera and trackpad readouts excluded)
let jnT=0;const jumpSoon=()=>{clearTimeout(jnT);jnT=setTimeout(()=>{jumpNav();tryRestore()},250)};
if(typeof MutationObserver==='function')new MutationObserver(recs=>{if(recs.every(r=>r.target&&r.target.closest&&r.target.closest('.cam,#tp,#kblist,.jnav,#hn')))return;jumpSoon()}).observe(pager,{childList:true,subtree:true});
addEventListener('resize',jumpSoon);
function leafOf(n){const sub=localStorage.getItem('sub:'+n)||'';if((n==='fleet'||n==='pad')&&sub)return sub;if(n==='markets')return 'markets';return n}
function pageVisible(){syncCameras();if(document.hidden||mode=='ambient')return;const n=pname(),leaf=leafOf(n);
 if(n==='today'){today();traffic()}
 if(n==='home'){ha();cams();stats()}
 if(hostPage())refresh();
 if(leaf==='fleet')fleet();
 if(leaf==='keys')fitKeys();
 if(typeof deckPage==='function')deckPage(leaf,false);
 jumpSoon()}
// ---- deck keys ----
let keyGroups=[];
async function loadKeys(){try{const j=await fetch('/api/keys').then(r=>r.json());keys=Array.isArray(j.keys)?j.keys:[];keyGroups=Array.isArray(j.groups)?j.groups:[]}catch(e){}renderKeys();renderQK()}
function keyBtn(k,i){const b=document.createElement('button');b.className='key press';b.innerHTML='<span class="ic" aria-hidden="true">'+esc(k.icon)+'</span><span class="lb">'+esc(k.label)+'</span>'+(k.action==='ws'?'<span class="ap"><span class="af"></span><span class="ac"></span></span>':'');
 b.setAttribute('aria-label',String(k.label||''));b.title=String(k.label||'');
 if(k.action==='ws')b.dataset.ws=String(k.arg);
 b.onclick=()=>fire(b,k,i);return b}
async function fire(b,k,i){
 if(k.confirm&&!b.dataset.arm){b.dataset.arm=1;b.classList.add('armed');const l=b.querySelector('.lb'),o=l.textContent;l.textContent='Tap again';b.setAttribute('aria-label','Tap again to confirm: '+k.label);
  setTimeout(()=>{delete b.dataset.arm;b.classList.remove('armed');l.textContent=o;b.setAttribute('aria-label',String(k.label||''))},3000);return}
 if(b.dataset.arm){delete b.dataset.arm;b.classList.remove('armed');b.querySelector('.lb').textContent=k.label;b.setAttribute('aria-label',String(k.label||''))}
 flag(await q('key?v='+(Number.isInteger(k.i)?k.i:i),1));setTimeout(refresh,500)}
// ==== KEY ROWS HELPERS BEGIN (pure: no DOM, no fetch, no globals; tests/home_keys_ui.test.js loads this block) ====
// A key's row is its served `group` (keys.json); a key without one is grouped by its action, so the rows stay right for
// whatever keys.json the host serves. Row names come from the served `groups` list, else the names below.
const KEYROWS=(()=>{
 const GROUPS=[['apps','Apps'],['media','Media'],['workspaces','Go to workspace'],['window','Move window'],['system','System'],['tv','TV'],['games','Games'],['music','Music'],['sprinklers','Sprinklers'],['house','House']];
 const GID=/^[a-z][a-z0-9_-]{0,23}$/;
 const label=(id,served)=>{const s=Array.isArray(served)?served.find(x=>x&&x.id===id&&typeof x.name==='string'&&x.name.trim()):null;if(s)return s.name.trim().slice(0,40);const g=GROUPS.find(x=>x[0]===id);return g?g[1]:id};
 function group(k){if(k&&typeof k.group==='string'&&GID.test(k.group))return k.group;
  const a=(k&&k.action)||'',v=(k&&k.arg)||'';
  if(a=='ws')return 'workspaces';
  if(a=='mvws')return 'window';
  if(a=='media-act'||a=='mute')return 'media';
  if(a=='screenshot'||a=='lock')return 'system';
  if(a=='launch'&&(v=='menu'||v=='nightlight'))return 'system';
  return 'apps'}
 // Rows in page order; a group with no keys is not drawn at all. Each entry keeps its served index, which
 // is what POST /api/key?v= takes, so grouping can never shift a key onto the wrong action.
 function rows(keys,served){const out=[];
  (keys||[]).forEach((k,i)=>{const g=group(k);let r=out.find(x=>x.id===g);if(!r){r={id:g,name:label(g,served),keys:[]};out.push(r)}r.keys.push({k,i})});
  return out}
 // Each row on its own: as many columns as keep a cell at or above its floor (44 px, or the row's longest label word, opts.need[i]),
 // at most opts.cols (four on a phone held upright); the cells then share the row's width, up to opts.max. A long row wraps.
 function layout(rows,W,opts){const o=opts||{},gap=o.gap==null?6:o.gap,min=o.min||44,max=o.max||96,cap=o.cols||Infinity;
  if(!(W>50))return [];
  return rows.map((r,i)=>{const n=r&&r.keys?r.keys.length:0;if(!n)return {cols:0,s:0};const floor=Math.max(min,Math.ceil(Number(o.need&&o.need[i])||0));
   const cols=Math.max(1,Math.min(n,cap,Math.floor((W+gap)/(floor+gap))));
   return {cols,s:Math.max(floor,Math.min(max,Math.floor((W-gap*(cols-1))/cols)))}})}
 // the smallest cell over all rows (the icon size every row shares); 0 when nothing fits
 function fit(rows,W,H,opts){const o=opts||{};if(!rows.length||!(W>50))return 0;const l=layout(rows,W,Object.assign({},o,{cols:o.cols||(o.portrait?4:undefined)})).filter(x=>x.s);return l.length?Math.min(...l.map(x=>x.s)):0}
 return {GROUPS,label,group,rows,layout,fit};
})();
// ==== KEY ROWS HELPERS END ====
function renderKeys(){const c=$('#keys');c.innerHTML='';
 KEYROWS.rows(keys,keyGroups).forEach(grp=>{
  const row=document.createElement('div');row.className='krow';row.dataset.g=grp.id;
  row.innerHTML='<span class="klab" role="heading" aria-level="3">'+esc(grp.name)+'</span><div class="kgrid" role="group" aria-label="'+esc(grp.name)+'"></div>';
  c.appendChild(row);
  const grid=row.querySelector('.kgrid');
  grp.keys.forEach(({k,i})=>grid.appendChild(keyBtn(k,i)))});
 if(typeof spacesSeen!=='undefined'&&spacesSeen&&typeof paintSpaces==='function')paintSpaces(spacesSeen[0],spacesSeen[1]);
 fitKeys();watchKeys()}
// The first fit can land while the pager is still scrolling into place, when the key column has almost no
// size. Watching the element means the rows always end up sized for the box they are really in.
let keyObs=null;
function watchKeys(){if(keyObs||typeof ResizeObserver!=='function')return;const c=$('#keys');if(!c)return;
 let t=0;keyObs=new ResizeObserver(()=>{clearTimeout(t);t=setTimeout(fitKeys,60)});
 keyObs.observe(c);const w=$('#keyswrap');if(w)keyObs.observe(w)}
function renderQK(){const c=$('#qk');c.innerHTML='';keys.slice(0,6).forEach((k,i)=>c.appendChild(keyBtn(k,i)))}
// Keys share the page with Connections. Each group row is sized on its own (KEYROWS.layout): never under 44 px and never narrower
// than its longest label word, so labels wrap as whole words and nothing is cut. Portrait phones show four keys a row.
let measureCtx=null;
function wordNeed(keys){const lb=keys[0]&&keys[0].querySelector('.lb');if(!lb)return 0;
 try{measureCtx=measureCtx||document.createElement('canvas').getContext('2d');const cs=getComputedStyle(lb);measureCtx.font=cs.fontWeight+' '+cs.fontSize+' '+cs.fontFamily}catch(e){return 0}
 let w=0;keys.forEach(k=>{const t=(k.querySelector('.lb')||{}).textContent||'';t.split(/\s+/).forEach(x=>{if(x)w=Math.max(w,measureCtx.measureText(x).width)})});
 return Math.ceil(w)+10} // the key's 2 px padding each side plus room for the press scale
function fitKeys(){
 const c=$('#keys'),W=c.clientWidth,rows=[...c.querySelectorAll('.krow')];if(!rows.length)return;
 // the first fit can land while the page is still taking its shape (a 55 px column during the tab switch): it sizes one row, not eight
 if(W<120){clearTimeout(fitKeys.t);fitKeys.t=setTimeout(fitKeys,120);return}
 const portrait=isPortrait(),phone=portrait&&innerWidth<600;
 const geo=rows.map(r=>({r,keys:[...r.querySelectorAll('.key')]})).filter(x=>x.keys.length);
 const L=KEYROWS.layout(geo,W,{gap:6,min:44,max:portrait?96:72,cols:phone?4:undefined,need:geo.map(x=>wordNeed(x.keys))});
 const sizes=L.filter(l=>l.s).map(l=>l.s);if(!sizes.length)return;
 geo.forEach((x,i)=>{const l=L[i];if(!l||!l.s)return;const g=x.r.querySelector('.kgrid');
  g.style.gridTemplateColumns='repeat('+l.cols+','+l.s+'px)';g.style.gridAutoRows='minmax('+l.s+'px,auto)'});
 c.style.setProperty('--kf',Math.max(16,Math.min(28,Math.floor(Math.min(...sizes)*.4)))+'px');jumpSoon()}
// ---- shared ----
const ago=t=>{if(t==null)return 'time unknown';const s=Math.max(0,Math.round(Date.now()/1000-t));return s<45?'just now':s<5400?Math.max(1,Math.round(s/60))+' min ago':s<172800?Math.round(s/3600)+' h ago':Math.round(s/86400)+' d ago'};
const hhmm=t=>t==null?'':new Date(t*1000).toLocaleTimeString([],{hour:'numeric',minute:'2-digit'});
const SD=k=>'<i class="sd '+k+'"></i>';
const stOf=c=>/\bbad\b/.test(c||'')?'bad':/\bstale\b/.test(c||'')?'warn':/\bok\b/.test(c||'')?'ok':'';
const wxWord=s=>{if(!s||!s.state)return 'No reading';const w=String(s.state).replace(/[-_]+/g,' ');return w.charAt(0).toUpperCase()+w.slice(1)};
const T=(h,v,t,cls,dg)=>{const k=stOf(cls);return '<div class="tile '+(cls||'')+'"><div class="h">'+(k?SD(k):'')+esc(h)+'</div><div class="v">'+esc(v)+'</div>'+(t?'<div class="t">'+esc(t)+'</div>':'')+(typeof TodayUI==='object'?TodayUI.dgH(dg):'')+'</div>'};
const srcAge=x=>(x.stale?'Out of date \u00B7 ':'')+'Updated '+ago(x.t);
// a request that never answers is cut off after 60 s: it must not leave a page blank or hold its "busy" flag (deck.js once()) forever
// A fetch that never reaches the deck server marks the status pill offline on every page (the host pollers only run on Home and Pad); the next answer clears it.
const netState=up=>{if(up){if(errText==='offline'){errText='';showSt()}}else if(errText!=='offline'){errText='offline';errMsg='';showSt()}};
const jget=async p=>{const c=typeof AbortController==='function'?new AbortController():null,t=c?setTimeout(()=>c.abort(),60000):0;try{let r;try{r=await fetch(p,c?{signal:c.signal}:undefined)}catch(e){netState(false);throw e}netState(true);if(!r.ok)throw new Error(r.status);return await r.json()}finally{clearTimeout(t)}};
// http(s) only, no quotes or spaces: the only URLs that may become an href
const safeHttp=u=>typeof u==='string'&&/^https?:\/\/[^\s"'<>]+$/i.test(u)?u:'';
// Now-playing art shows only when it is same-origin: the shell blocks every other host, and nothing may fetch off-origin under the OmarchyDeck/ user agent.
// Returns the path to use, or '' (hide the picture) for any other origin, scheme, data: or blob: URL.
const artSrc=(u,origin)=>{try{if(typeof u!=='string'||!u||typeof origin!=='string')return '';const x=new URL(u,origin);return /^https?:$/.test(x.protocol)&&x.origin===origin?x.pathname+x.search:''}catch(e){return ''}};
// ==== TODAY UI HELPERS BEGIN (pure: no DOM, no fetch; the only global it reads is DeckUI.redact, looked up per call; tests/today_ui.test.js loads this block) ====
const TodayUI=(()=>{
 const MON=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
 const METRICS={organic_search_clicks:{label:'organic search clicks',unit:'clicks'},visits:{label:'visits',unit:'visits'}};
 const PROVIDERS={google_search_console:'Search Console',search_console:'Search Console',gsc:'Search Console',plausible:'Plausible',cloudflare:'Cloudflare',google_analytics:'Google Analytics',ga4:'Google Analytics',vercel:'Vercel'};
 const escH=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 // technical detail rides in a hidden .diag span; the detail sheet shows it under "Details". It goes through the deck's ONE redaction rule (DeckUI.redact in
 // deck.js, looked up when a span is written, so nothing here can drift from it): home folders read "~", credentials and account flags are masked. Without
 // that rule (deck.js not loaded yet) a span is not written at all.
 const redactor=()=>{try{return typeof DeckUI==='object'&&DeckUI&&typeof DeckUI.redact==='function'?DeckUI.redact:null}catch(e){return null}};
 const dgH=ds=>{const r=redactor();return r?(Array.isArray(ds)?ds:[]).filter(x=>typeof x==='string'&&x).map(x=>'<span class="diag">'+escH(r(x))+'</span>').join(''):''};
 const isObj=x=>x!==null&&typeof x==='object'&&!Array.isArray(x);
 const num=v=>typeof v==='number'&&isFinite(v)&&v>=0?v:null;
 const str=(v,max)=>typeof v==='string'&&v.trim()?v.trim().slice(0,max||80):'';
 const SD=k=>'<i class="sd '+k+'"></i>';
 // null is never zero: only a real finite non-negative number prints, everything else is "--"
 function fmtNum(v){const n=num(v);if(n==null)return '--';const r=Math.round(n);
  if(r>=1e6)return (r/1e6).toFixed(1).replace(/\.0$/,'')+'M';
  return String(r).replace(/\B(?=(\d{3})+(?!\d))/g,',')}
 function parseDate(s){const m=/^(\d{4})-(\d{2})-(\d{2})/.exec(typeof s==='string'?s:'');if(!m)return null;
  const y=+m[1],mo=+m[2],d=+m[3];if(mo<1||mo>12||d<1||d>31)return null;return {y,mo,d,k:y*10000+mo*100+d}}
 function fmtWindow(start,end){const a=parseDate(start),b=parseDate(end);if(!a||!b||b.k<a.k)return 'window unknown';
  if(a.k===b.k)return MON[a.mo-1]+' '+a.d;
  if(a.y!==b.y)return MON[a.mo-1]+' '+a.d+', '+a.y+' to '+MON[b.mo-1]+' '+b.d+', '+b.y;
  if(a.mo===b.mo)return MON[a.mo-1]+' '+a.d+' to '+b.d;
  return MON[a.mo-1]+' '+a.d+' to '+MON[b.mo-1]+' '+b.d}
 function fmtAge(t,now){const x=num(t);if(x==null||typeof now!=='number'||!isFinite(now))return 'time unknown';const s=Math.max(0,Math.round(now/1000-x));
  return s<45?'just now':s<5400?Math.max(1,Math.round(s/60))+' min ago':s<172800?Math.round(s/3600)+' h ago':Math.round(s/86400)+' d ago'}
 function providerLabel(p){const k=str(p,40);if(!k)return 'Source unknown';return PROVIDERS[k.toLowerCase()]||k.replace(/[_-]+/g,' ')}
 function rowModel(site,payload,now){
  const s=isObj(site)?site:{},pl=isObj(payload)?payload:{};
  const domain=str(s.domain,60)||'Unknown site',m=METRICS[s.metric]||null,value=num(s.value);
  let st=String(s.status==null?'':s.status).toLowerCase();
  if(st==='')st=value!=null?'ok':'unavailable';
  if(st!=='ok'&&st!=='partial'&&st!=='stale')st='unavailable';
  if(st==='ok'&&pl.stale===true)st='stale';
  if(st==='ok'&&value==null&&m)st='partial';
  const show=st!=='unavailable'&&!!m&&value!=null;
  const impr=show?num(s.impressions):null;
  const t=num(s.t)!=null?num(s.t):num(pl.t);
  // C3: a Search Console 403 or unverified property is "no_access" (the owner must grant it); anything else that failed is "failed"
  const noAccess=st==='unavailable'&&String(s.reason||'').toLowerCase()==='no_access';
  const word=st==='stale'?'Out of date':st==='partial'?'Partial':noAccess?'No access':st==='unavailable'?'Not reporting':'';
  const err=str(s.error,80);
  const line2=noAccess?'No Search Console access for this site':st==='unavailable'?'Could not be read. It tries again on its own.':
   ((m?m.label:'unknown metric')+' \u00B7 '+fmtWindow(s.start_date,s.end_date)+(st==='partial'&&value==null?' \u00B7 no value reported':''));
  const line3=(word?word+' \u00B7 ':'')+providerLabel(s.provider)+' \u00B7 '+fmtAge(t,now);
  return {domain,st,mark:st==='ok'?'ok':noAccess?'warn':st==='unavailable'?'bad':'warn',value:show?fmtNum(value):'No reading',unit:m?m.unit:'',
   impr:impr!=null?fmtNum(impr)+' impr':'',line2,line3,show,metric:m?s.metric:null,t,diag:err?['Reason: '+err]:[],
   tracked:typeof s.tracked==='boolean'?s.tracked:null,reason:noAccess?'no_access':st==='unavailable'?'failed':''}}
 // Daily view: per-site clicks for the latest complete day plus the four-site aggregate against the goal.
 // Unmeasured sites are rows that say No reading, never zero; a partial aggregate says how many sites it covers.
 function dailyModel(payload,now){
  const d=payload.daily;if(!isObj(d))return null;
  const rows=(Array.isArray(d.sites)?d.sites:[]).map(x=>rowModel(x,payload,now));
  const g=isObj(d.aggregate)?d.aggregate:{};
  const clicks=num(g.clicks),measured=num(g.measured)||0,tracked=num(g.tracked)||0,goal=num(d.goal),pct=num(g.pct),lag=num(d.lag_days);
  const st=String(d.status==null?'':d.status).toLowerCase();
  const stale=payload.stale===true;
  const complete=g.complete===true;
  const state=clicks==null||st==='unavailable'?'unavailable':stale?'stale':complete?'ok':'partial';
  const day=parseDate(d.date)?fmtWindow(d.date,d.date):'date unknown';
  const pctText=pct==null?'No percentage without a measured site':(complete?'':'At least ')+(Math.round(pct*10)/10)+'% of goal'+(complete?'':' (partial)');
  const err=str(d.error,80);
  return {state,rows,stale,diag:err?['Reason: '+err]:[],agg:{value:clicks==null?'No reading':fmtNum(clicks),
   goalText:goal==null?'No goal set':'of '+fmtNum(goal)+' daily goal',
   bar:pct==null?null:Math.max(0,Math.min(100,pct)),pctText,
   line2:day+' \u00B7 '+(tracked?measured+' of '+tracked+' sites measured':'No sites measured'),
   line3:(state==='unavailable'?'Not reporting \u00B7 ':stale?'Out of date \u00B7 ':complete?'':'Partial \u00B7 unmeasured sites are not counted as zero \u00B7 ')+'organic search clicks'}}}
 function trafficModel(payload,opts){
  const o=opts||{},now=typeof o.now==='number'?o.now:0,fetchErr=str(o.fetchError,80);
  if(!isObj(payload)){
   const why=o.loading?'Loading traffic':fetchErr?'Traffic could not be read. It tries again on its own.':'Traffic is not reporting. It tries again on its own.';
   return {state:o.loading?'loading':'unavailable',stale:false,age:'',rows:[{domain:o.loading?'Loading':'Traffic not reporting',st:o.loading?'partial':'unavailable',mark:o.loading?'warn':'bad',
    value:'No reading',unit:'',impr:'',line2:why,line3:o.loading?'Reading':'Nothing to show yet',show:false,metric:null,t:null,diag:fetchErr?['Reason: '+fetchErr]:[]}],notice:'',footer:'',diag:[]}}
  const sites=Array.isArray(payload.sites)?payload.sites:[];
  // the owner's monitoring scope (C3 `tracked`) leads; other properties fold under "More sites". A feed without the flag keeps every site in the main list.
  const all=sites.map(x=>rowModel(x,payload,now)),flagged=all.some(r=>r.tracked!==null);
  // only an explicit `tracked:false` folds a site under More sites: a missing flag is not evidence that it is out of scope
  all.forEach(r=>{if(r.tracked===null)r.tracked=true});
  const rows=all.filter(r=>r.tracked),more=all.filter(r=>!r.tracked),judged=rows.length?rows:all;
  const usable=judged.some(r=>r.show);
  const pst=String(payload.status==null?'':payload.status).toLowerCase();
  const issue=(!flagged&&pst!=='ok')||judged.some(r=>r.st!=='ok');
  const stale=payload.stale===true||!!fetchErr;
  let state=!usable?'unavailable':issue||stale?'partial':'ok';
  if(!all.length){
   const msg=pst==='unavailable'?'Traffic sources are not reporting. Try again later.':'No sites are tracked yet.';
   rows.push({domain:pst==='unavailable'?'Traffic not reporting':'No sites',st:'unavailable',mark:'bad',value:'--',unit:'',impr:'',line2:msg,
    line3:'Updated '+fmtAge(payload.t,now),show:false,metric:null,t:null,diag:[str(payload.error,80)&&'Reason: '+str(payload.error,80),str(payload.src,60)&&'Source: '+str(payload.src,60)].filter(Boolean)});state='unavailable'}
  return {state,stale,age:(stale?'Out of date \u00B7 ':'')+(num(payload.t)==null?'Update time unknown':'Updated '+fmtAge(payload.t,now)),rows,more,daily:dailyModel(payload,now),
   notice:fetchErr?'Could not refresh. Showing the last reading.':'',diag:[fetchErr&&'Reason: '+fetchErr,str(payload.src,60)&&'Source: '+str(payload.src,60)].filter(Boolean),
   footer:'Organic search clicks are not visits.'}}
 function rowHtml(r){
  return '<div class="trow '+r.st+'"><div class="tl"><b class="td">'+SD(r.mark)+escH(r.domain)+'</b><span class="tm">'+escH(r.line2)+'</span><span class="tm">'+escH(r.line3)+'</span></div>'+
   (r.unit||r.value!=='--'?'<div class="tr"><b>'+escH(r.value)+'</b><small>'+escH(r.unit)+'</small><small>'+escH(r.impr)+'</small></div>':'')+dgH(r.diag)+'</div>'}
 function tggHtml(t){return '<div class="tgrp">'+escH(t)+'</div>'}
 function dailyHtml(d){
  const a=d.agg;
  return tggHtml('Daily clicks \u00B7 latest complete day')+
   '<div class="tagg '+d.state+'"><div class="tav"><b>'+escH(a.value)+'</b><small>'+escH(a.goalText)+'</small></div>'+
   (a.bar!=null?'<div class="tbar" role="img" aria-label="'+escH(a.pctText)+'"><i style="width:'+a.bar+'%"></i></div>':'')+
   '<span class="tm">'+escH(a.pctText)+'</span><span class="tm">'+escH(a.line2)+'</span><span class="tm">'+escH(a.line3)+'</span></div>'+
   d.rows.map(rowHtml).join('')}
 function moreHtml(rs){return rs&&rs.length?'<details class="tmore"><summary class="tgrp">More sites \u00B7 '+rs.length+'</summary>'+rs.map(rowHtml).join('')+'</details>':''}
 function trafficHtml(m){
  return '<section class="tcard '+m.state+(m.stale?' stale':'')+'" aria-label="Website traffic"><div class="secttl"><span>Website traffic</span><span>'+escH(m.age)+'</span></div>'+
   '<div class="trows">'+(m.daily?dailyHtml(m.daily)+tggHtml('28-day totals'):'')+m.rows.map(rowHtml).join('')+moreHtml(m.more)+'</div>'+
   (m.notice?'<div class="tnote">'+escH(m.notice)+'</div>':'')+(m.footer?'<div class="tnote">'+escH(m.footer)+'</div>':'')+dgH(m.diag)+'</section>'}
const wnum=(v,dg,u)=>{const n=typeof v==='number'&&isFinite(v)?v:null;return n==null?'No reading':n.toFixed(dg||0)+(u||'')};
 const wt=(h,v,t)=>'<div class="tile wt"><div class="h">'+escH(h)+'</div><div class="v">'+escH(v)+'</div><div class="t">'+escH(t)+'</div></div>';
 function watchHtml(w,now,staleRead){
  const title='Apple Watch';
  if(!isObj(w)||!Object.keys(w).length)return '<div class="secttl"><span>'+title+'</span><span>Not reporting</span></div><div class="tile stale"><div class="h">'+SD('warn')+title+'</div><div class="v">Not reporting</div><div class="t">The deck did not answer. It tries again on its own.</div></div>';
  if(w.error){const missing=/missing|not found|no such file/i.test(String(w.error));
   const line=missing?'No watch file yet. It shows up after the next hourly check.':'The watch feed did not answer. It tries again on its own.';
   return '<div class="secttl"><span>'+title+'</span><span>Not reporting</span></div><div class="tile stale"><div class="h">'+SD('warn')+title+'</div><div class="v">Not reporting</div><div class="t">'+line+'</div>'+dgH([str(w.error,80),str(w.src,60),str(w.reason,80)].filter(Boolean))+'</div>'}
  const c=w.connected===true,known=typeof w.connected==='boolean',old=staleRead||w.stale===true||(num(w.t)!=null&&now/1000-w.t>7200);
  const word=old?'Last reading':c?'Connected':known?'Not connected':'Unknown';
  const pill='<span class="pill'+(c&&!old?'':' warn')+'">'+SD(c&&!old?'ok':'warn')+word+'</span>';
  const none=[w.hr,w.hrv,w.sleep_h,w.battery].every(v=>!(typeof v==='number'&&isFinite(v)));
  const empty=typeof DeckUI==='object'&&DeckUI&&DeckUI.watchEmpty?DeckUI.watchEmpty(w,now,'No readings yet'):typeof DeckUI==='object'&&DeckUI&&DeckUI.empty?DeckUI.empty({title:'No readings yet',line:'Heart rate, HRV, sleep and battery show here when the watch checks in.'}):'<div class="tile"><div class="h">'+title+'</div><div class="v">No readings yet</div><div class="t">Heart rate, HRV, sleep and battery show here when the watch checks in.</div></div>';
  const extra=[typeof w.move_kcal==='number'?wt('Move',wnum(w.move_kcal),'kcal'):'',typeof w.exercise_min==='number'?wt('Exercise',wnum(w.exercise_min),'min'):'',typeof w.stand_h==='number'?wt('Stand',wnum(w.stand_h),'h'):''].join('');
  const why=str(w.reason,80);
  return '<div class="secttl"><span>'+title+' '+pill+'</span><span>'+(old?'Out of date \u00B7 ':'')+(num(w.t)==null?'Update time unknown':'Updated '+escH(fmtAge(w.t,now)))+'</span></div>'+(none?empty:'<div id="wh">'+
   wt('HR',wnum(w.hr),'bpm')+wt('HRV',wnum(w.hrv),'ms')+wt('Sleep',wnum(w.sleep_h,1),'h')+wt('Battery',wnum(w.battery,0),'%')+extra+'</div>')+
   (why?'<div id="tnote">'+escH(why)+'</div>':'')}
 function briefingNext(c){if(!isObj(c))return [];const jobs=Array.isArray(c.briefings)?c.briefings:c.next;return Array.isArray(jobs)?jobs.filter(j=>isObj(j)&&/^(Markets Daily Brief|Morning Inbox and Briefing)$/i.test(String(j.name||'').trim())):[]}
 return {fmtNum,fmtWindow,fmtAge,parseDate,providerLabel,rowModel,trafficModel,trafficHtml,watchHtml,briefingNext,escH,dgH};
})();
// ==== TODAY UI HELPERS END ====
// ---- today ----
// Website traffic is its own read: a failed /api/traffic never touches gateway, mail, cron, markets or Apple Watch.
let trafficLast=null,trafficErr='',trafficBusy=false,trafficSeen=false,trafficT=0;
// v7 Today: three scrolling columns of compact sections. app.js fills status, a 3 line markets glance, Apple Watch and traffic;
// deck.js (v7Today) fills needs, cluster, calendar, car and house, surf, hockey, jobs and homes.
function ensureToday(){if($('#tstat'))return;
 $('#tc1').innerHTML='<div id="tattn"></div><div id="tneeds"></div><div id="tcal"></div><div id="tnext"></div><div id="wcard"></div>';
 $('#tc2').innerHTML='<div id="tmaint"></div><details class="tgroup"><summary class="secttl"><span>System status</span><span id="tstatusflag"></span></summary><div id="tstat" class="tgrid"></div><div id="tclu"></div></details><div id="thome"></div>';
 $('#tc3').innerHTML='<details class="tgroup" open><summary class="secttl"><span>Life and research</span></summary><div id="mk"></div><div id="tfc"></div><div id="tsurf"></div><div id="thockey"></div><div id="tjobs"></div><div id="thomes"></div></details>';paintTraffic()}
function paintTraffic(){const el=$('#tfc');if(!el)return;try{el.innerHTML=TodayUI.trafficHtml(TodayUI.trafficModel(trafficLast,{now:Date.now(),fetchError:trafficErr,loading:!trafficSeen}))}catch(e){el.innerHTML='<section class="tcard unavailable"><div class="secttl"><span>Website traffic</span><span>Not reporting</span></div><div class="tnote">Traffic could not be shown. Reload the deck to try again.</div></section>'}}
async function traffic(force){if(trafficBusy)return;if(!force&&Date.now()-trafficT<(trafficErr?30000:300000))return;trafficBusy=true;trafficT=Date.now();
 try{const ac=new AbortController(),tm=setTimeout(()=>ac.abort(),8000);
  try{const r=await fetch('/api/traffic',{signal:ac.signal});if(!r.ok)throw new Error('HTTP '+r.status);trafficLast=await r.json();trafficErr=''}finally{clearTimeout(tm)}}
 catch(e){trafficErr=e&&e.name=='AbortError'?'timed out':String((e&&e.message)||'failed').slice(0,60)}
 finally{trafficSeen=true;trafficBusy=false;paintTraffic()}}
// ---- today ----
let todayLast=null,todayBusy=false;
// deck.js (loaded after this file) owns the shared wording; wait for it, but never hang if it did not load
const deckReady=()=>typeof DeckUI==='object'?Promise.resolve():new Promise(r=>{addEventListener('DOMContentLoaded',r,{once:true});setTimeout(r,3000)});
const probOf=x=>typeof DeckUI==='object'?DeckUI.problem(x):{line:'Not reporting. It tries again on its own.',diag:[]};
async function today(){if(todayBusy)return;todayBusy=true;ensureToday();
 try{
 await deckReady();
 const [dr,hr,cr,acR,scR,clR]=await Promise.allSettled([jget('/api/today'),jget('/api/health'),jget('/api/cams'),jget('/api/accounts'),jget('/api/schedules'),jget('/api/cluster')]);
 const latest=dr.status=='fulfilled'&&dr.value&&typeof dr.value==='object'&&!Array.isArray(dr.value)&&!dr.value.error?dr.value:null;
 const readFailed=!latest,d=readFailed?(todayLast||{}):latest;
 if(!readFailed)todayLast=d;
 const h=hr.status=='fulfilled'&&hr.value?hr.value:{error:'deck server did not answer',src:'fleet-health-last.json'};
 const cam=cr.status=='fulfilled'&&cr.value?cr.value:{error:'camera status unavailable'};
 const camRows=Array.isArray(cam.cams)?cam.cams:[],camLine=cam.error||!camRows.length?'Cameras not reporting':camRows.filter(x=>x&&x.ready).length+' of '+camRows.length+' cameras online';
 const unavailable=(src)=>({error:readFailed?'deck server did not answer':'source did not report',src});
 const g=d.gateway||unavailable('gateway /health'),m=d.mail||unavailable('inbox-full.json'),c=d.cron||unavailable('jobs.json'),k=d.markets||unavailable('newswire.db'),w=d.watch||unavailable('watch.json');
 const age=x=>((readFailed||x.stale)?'Out of date \u00B7 ':'')+'Updated '+ago(x.t);
 const down=(name,x)=>{const p=probOf(x);return T(name,'Not reporting',p.line,'bad',p.diag)};
 const gv=g.error||typeof g.ok!='boolean'?down('Gateway',g):T('Gateway',(g.ok?'Online':'Degraded')+(g.version?' v'+g.version:''),age(g),'big '+(readFailed?'stale':g.ok?'ok':'bad'));
 const mb=Array.isArray(m.mailboxes)?m.mailboxes:[],unread=mb.reduce((a,b)=>a+(b&&b.ok?(b.unread||0):0),0),off=mb.filter(b=>!b||!b.ok).length;
 const mv=m.error||!Array.isArray(m.mailboxes)?down('Mail',m):
  T('Mail',unread+' unread'+(off?' \u00B7 '+off+(off===1?' mailbox':' mailboxes')+' offline':''),(m.status=='partial'&&!m.stale&&!readFailed?'Partial \u00B7 ':'')+age(m),'big '+(readFailed||m.status!='ok'?'stale':'ok'));
 const nx=Array.isArray(c.next)?c.next[0]:null,failing=Array.isArray(c.failing)?c.failing:[],fl=failing.length,briefing=TodayUI.briefingNext(c)[0];
 const cv=c.error||!Array.isArray(c.next)?down('Automations',c):
  T('Automations',nx?nx.name+' \u00B7 '+hhmm(nx.at):'Nothing scheduled',c.enabled+' on \u00B7 '+c.paused+' paused'+(fl?' \u00B7 failing: '+failing.join(', '):'')+' \u00B7 '+age(c),readFailed?'stale':fl?'bad':'ok');
 $('#tnext').innerHTML=c.error||!Array.isArray(c.next)?down('Upcoming briefings',c):
  T('Upcoming briefings',briefing?briefing.name+' \u00B7 '+hhmm(briefing.at):'No briefing scheduled',age(c),readFailed||c.stale?'stale':'');
 const hv=h.error||!Number.isInteger(h.count)?down('Fleet check',h):
  h.count>0?T('Fleet check',(h.stale?'Cached: ':'')+h.count+' problem'+(h.count>1?'s':'')+': '+(Array.isArray(h.names)?h.names:[]).join(', '),srcAge(h)+' \u00B7 '+camLine,h.stale?'stale':'bad'):
  T('Fleet check','All clear',srcAge(h)+' \u00B7 '+camLine,h.stale?'stale':'ok');
 $('#tstat').innerHTML=gv+mv+cv+hv;
 // Attention strip (owner order 2026-10-28): only the few things that need a person, each with its own
 // one-line cause, merged across crons, cluster, gateway, mail, stale feeds and the next calendar item.
 // Everything healthy stays quiet in the sections below.
 const sf=$('#tstatusflag'),held=readFailed||g.ok!==true||m.status!=='ok'||m.stale||c.error||c.stale||fl>0||h.error||h.stale||!Number.isInteger(h.count)||h.count>0;
 if(sf){sf.textContent=held?'Needs attention':'';sf.className=held?'pill warn':'';}
 try{const att=[];
  if(g.error||g.ok!==true)att.push({k:'bad',text:'Gateway '+(g.error?'unreachable':'degraded'),why:(g.error||'health check not ok')+' \u00B7 '+age(g)});
  if(m.error)att.push({k:'bad',text:'Mail unreachable',why:m.error+' \u00B7 '+age(m)});
  else if(off>0)att.push({k:'bad',text:off+' mailbox'+(off>1?'es':'')+' offline',why:mb.filter(b=>!b||!b.ok).map(b=>(b&&b.email)||'mailbox').join(', ')});
  const sc=scR.status=='fulfilled'&&scR.value&&!scR.value.error?scR.value:null;
  if(sc){const cc=sc.counts||{},jobs=[];(sc.groups||[]).forEach(x=>{(x&&x.jobs||[]).forEach(j=>jobs.push(j))});
   const failed=jobs.filter(j=>j&&j.result=='failed'),over=jobs.filter(j=>j&&j.result=='overdue');
   if(failed.length)att.push({k:'bad',text:failed.length+' scheduled job'+(failed.length>1?'s':'')+' failing (all schedulers)',why:failed.slice(0,3).map(j=>j.name+' ('+j.host+')').join(', ')});
   if(over.length)att.push({k:'warn',text:over.length+' job'+(over.length>1?'s':'')+' overdue',why:over.slice(0,3).map(j=>j.name+' ('+j.host+')').join(', ')});
   if(Number(cc.sources_down)>0)att.push({k:'bad',text:cc.sources_down+' schedule source down',why:(sc.errors||[]).slice(0,2).map(e=>e.source+': '+e.reason).join(' \u00B7 ')});
  }
  const clr=clR.status=='fulfilled'&&clR.value&&!clR.value.error?clR.value:null;
  if(clr&&clr.engine&&clr.engine.status!='up')att.push({k:'bad',text:'Cluster engine '+(clr.engine.status||'unknown'),
   why:(clr.engine.container||'container unknown')+' \u00B7 '+(clr.engine.served_name||'model unknown')+' \u00B7 proxy '+(clr.proxy&&clr.proxy.pc_desktop_8080_up?'up':'down')});
  const stale=[];if(k.stale)stale.push('markets');if(w.stale)stale.push('Apple Watch');if(h.stale)stale.push('fleet check');if(m.stale)stale.push('mail');
  if(stale.length)att.push({k:'warn',text:stale.length+' feed'+(stale.length>1?'s':'')+' late',why:stale.join(', ')+' did not refresh on time'});
  const ac=acR.status=='fulfilled'&&acR.value&&!acR.value.error?acR.value:null,ev=ac&&ac.apple&&Array.isArray(ac.apple.events_today)?ac.apple.events_today:[];
  const timed=ev.filter(e=>e&&e.start).map(e=>({e,t:Date.parse(e.start)/1000})).filter(x=>isFinite(x.t)&&x.t>=Date.now()/1000).sort((a,b)=>a.t-b.t)[0];
  const nextEv=timed||ev.filter(e=>e&&e.all_day)[0]||null;
  if(nextEv&&nextEv.e)att.push({k:'warn',text:'Next up: '+((nextEv.e.title||'event')),why:(timed===nextEv?hhmm(nextEv.t)+' \u00B7 ':'all day \u00B7 ')+((nextEv.e.calendar)||'calendar')});
  const el=$('#tattn');if(el)el.innerHTML=typeof DeckUI=='object'&&DeckUI.attention?DeckUI.attention(att,Date.now(),{failed:readFailed,missing:[['Gateway',g],['Mail',m],['Automations',c],['Markets',k],['Apple Watch',w]].filter(x=>x[1]&&x[1].error).map(x=>x[0]).concat(Array.isArray(d.errors)?d.errors.map(e=>String(e&&e.source||e)):[])}):'';
 }catch(e){}
 const seenHl=new Set(),kp=probOf(k);
 const hl=k.error||!Array.isArray(k.items)?DeckUI.empty({k:'bad',title:'Headlines are not reporting',line:kp.line,diag:kp.diag}):
  (k.items.length?k.items.filter(i=>{const t=String(i&&i.title||'').toLowerCase();if(seenHl.has(t))return false;seenHl.add(t);return true}).slice(0,3).map(i=>{const u=safeHttp(i&&i.url);
   return (u?'<a class="frow" href="'+esc(u)+'" target="_blank" rel="noopener noreferrer">':'<div class="frow">')+'<span class="fl"><b>'+esc(i&&i.title)+'</b><small>'+esc(i&&i.source)+' \u00B7 '+ago(i&&i.at)+'</small></span>'+(u?'<span class="lk" aria-hidden="true">\u2197</span>':'')+(u?'</a>':'</div>')}).join(''):
  DeckUI.empty({title:'No headlines right now',line:'New stories show up as they are published.'}));
 const mk=$('#mk');mk.className=readFailed?'stale':'';mk.innerHTML='<div class="secttl"><span>Market news</span><span>'+(readFailed?'Out of date \u00B7 ':'')+(k.error?'Not reporting':'Updated '+esc(ago(k.t)))+'</span></div><div class="flist">'+hl+'</div>';
 try{$('#wcard').innerHTML=TodayUI.watchHtml(w,Date.now(),readFailed);$('#wcard').classList.toggle('stale',readFailed&&!w.error)}
 catch(e){$('#wcard').innerHTML='<div class="tile bad"><div class="h">'+SD('bad')+'Apple Watch</div><div class="v">Not reporting</div><div class="t">Could not show this. Reload the deck to try again.</div></div>'}
 paintTraffic();
 }finally{todayBusy=false}}
// ---- fleet ----
const tagWords=t=>String(t||'').replace(/STALE/gi,'Out of date').replace(/(\d+)m old/g,'$1 min old').replace(/(\d+)h old/g,'$1 h old').replace(/(\d+)d old/g,'$1 d old');
function fact(o){const st=/stale/i.test(o.tag||'')||/([2-9]\d|\d{3,})m old/.test(o.tag||'');return T(o.head,o.text||o.raw,(st&&!/stale/i.test(o.tag||'')?'Out of date \u00B7 ':'')+tagWords(o.tag),(st?'stale':''))}
function chip(b,s,ok,cls,dg){return '<div class="chip'+(ok?'':' bad')+(cls?' '+cls:'')+'"><b>'+SD(ok?'ok':'bad')+esc(b)+'</b><small>'+esc(s)+'</small>'+TodayUI.dgH(dg)+'</div>'}
const ageS=a=>a==null?'time unknown':a<45?'just now':a<5400?Math.max(1,Math.round(a/60))+' min ago':a<172800?Math.round(a/3600)+' h ago':Math.round(a/86400)+' d ago';
const niceUnit=s=>{const t=String(s||'').replace(/^hermes-/,'').replace(/\.(service|timer)$/,'').replace(/[-_]+/g,' ').trim();return t.charAt(0).toUpperCase()+t.slice(1)};
const grp=n=>{const w=n.split('-')[0];return w.charAt(0).toUpperCase()+w.slice(1).toLowerCase()};
// A blank Fleet body is never shown: loading, a failed read and an all-empty read each say what is going on (DeckUI.fleetNotice in deck.js).
const fleetWhy=e=>/^\d+$/.test(String(e&&e.message))?'http '+e.message:'deck server did not answer';
async function fleet(){try{
 if(!$('#fl1').innerHTML.trim()&&!$('#fl3').innerHTML.trim())$('#fl1').innerHTML=T('Fleet','Loading','Reading the fleet checks and the fleet board','stale');
 await deckReady();
 const [f,nd,dk,st,mc,signals]=await Promise.all([jget('/api/fleet').catch(e=>({error:fleetWhy(e),items:[]})),...['nodes','disks','sites','mcp'].map(x=>jget('/api/'+x).catch(()=>({error:'deck server did not answer'}))),jget('/api/fleet-widgets').catch(()=>null)]);
 let bd=null;try{bd=await jget('/api/fleet-board')}catch(e){}fleetLast=bd;
 const N=(typeof DeckUI=='object'&&DeckUI.fleetNotice)?DeckUI.fleetNotice({f,nd,dk,st,mc,bd}):{blank:false};
 if(N.blank){$('#fl1').dataset.ok='';$('#fl1').innerHTML=N.html;$('#fl2').innerHTML='';$('#fl3').innerHTML='<div id="fmeta">Fleet unreadable \u00B7 '+esc(ago(f.t))+'</div>';return}
 const B=(typeof DeckUI=='object'&&DeckUI.board)?DeckUI.board(bd,Date.now()):['','','','',''];
 const fOk=!!f&&!f.error;
 const it=fOk?(f.items||[]):[],sv=fOk?(f.services||{}).items||[]:[],rc=fOk?(f.reach||{}).items||[]:[];
 const gone=(name,x)=>{const p=probOf(x);return T(name,'Not reporting',p.line,'bad',p.diag)};
 const none=(h,why)=>T(h,'None reported',why,'stale');
 const fr=x=>[x.stale?'Out of date':'',x.age!=null?'Updated '+ageS(x.age):''].filter(Boolean).join(' \u00B7 ');
 const nodes=nd.error?gone('Node check',nd):!(nd.nodes||[]).length?none('No nodes','The nodes feed returned an empty list'):'<div id="fnd">'+(nd.nodes||[]).map(x=>{
   const hot=x.temp_c!=null&&x.temp_c>=85,k=!x.reachable?'bad':(nd.stale||hot)?'warn':'ok';
   return '<div class="tile'+(k=='bad'?' bad':k=='warn'?' stale':'')+'"><div class="h">'+SD(k)+esc(x.label)+'</div><div class="v">'+(x.reachable?(x.mem_pct!=null?Math.round(x.mem_pct)+'%':'--')+' \u00B7 '+(x.temp_c!=null?Math.round(x.temp_c)+'\u00B0C':'--'):'Not reachable')+'</div><div class="bar'+(x.mem_pct>=99?' hot':'')+'"><i style="width:'+(x.mem_pct||0)+'%"></i></div><div class="t">'+(x.mem_used_gb!=null?'Memory '+Math.round(x.mem_used_gb)+' of '+Math.round(x.mem_total_gb)+' GB':'')+'</div></div>'}).join('')+'</div>';
 // the stall watch strip (ops.js) sits on top of the first column; it keeps its own last render in window.STALLS_HTML
 $('#fl1').innerHTML='<div id="stalls">'+(window.STALLS_HTML||'')+'</div>'+(B[1]||'')+
  '<div class="secttl"><span>Cluster nodes</span><span>'+fr(nd)+'</span></div>'+nodes+
  (mc.error?gone('Tools',mc):T('Tools',mc.up+' up \u00B7 '+mc.down+' down',srcAge(mc),mc.down>0?'bad':mc.stale?'stale':'ok'));
 const by={};(st.items||[]).forEach(x=>{(by[grp(x.name)]=by[grp(x.name)]||[]).push(x)});
 const sites=st.error?gone('Site check',st):!(st.items||[]).length?none('Product sites','The sites feed returned an empty list'):'<div id="fst">'+Object.keys(by).map(g=>{const a=by[g],dn=a.filter(x=>!x.ok),mx=Math.max(...a.map(x=>x.ms||0));return chip(g+' '+(a.length-dn.length)+'/'+a.length,dn.length?'Down: '+dn.map(x=>x.name.replace(/^\w+-/,'')).join(', '):'Up \u00B7 slowest '+mx+' ms',!dn.length,'sm'+(st.stale?' stale':''))}).join('')+'</div>';
 $('#fl2').innerHTML=(fOk?'<div class="secttl"><span>Services</span><span>Checked '+ago(f.t)+'</span></div>'+(sv.length?'<div id="fsv">'+sv.map(x=>chip(niceUnit(x.unit),x.ok?'Running':String(x.state||'Not running').replace(/^./,c=>c.toUpperCase()),x.ok,'sm',[x.unit])).join('')+'</div>':none('Services','systemctl --user returned no units'))+
  '<div class="secttl"><span>Hosts</span><span>Checked '+ago(f.t)+'</span></div>'+(rc.length?'<div id="frc">'+rc.map(x=>chip(x.name,x.ok?'Online \u00B7 '+x.ms+' ms':'Not reachable',x.ok,'sm')).join('')+'</div>':none('Hosts','No host probes ran')):
  '<div class="secttl"><span>Services and hosts</span><span>Not reporting</span></div>'+(typeof DeckUI==='object'?DeckUI.down('Services and hosts',f,'fleet'):''))+
  '<div class="secttl"><span>Product sites</span><span>'+fr(st)+'</span></div>'+sites+(B[3]||'')+(B[4]||'')+
  (typeof DeckUI==='object'&&DeckUI.fleetSignals?DeckUI.fleetSignals(signals,Date.now()):'');
 const disks=dk.error?gone('Disk check',dk):!(dk.drives||[]).length?none('Disks','The disks feed returned an empty list'):(dk.drives||[]).map(d=>{const p=d.pct,hot=p!=null&&p>=90;return '<div class="dk'+(hot?' hot':'')+'"><span>'+(hot?'! ':'')+esc(d.host)+' <small>'+esc(d.label)+'</small></span><div class="bar"><i style="width:'+(p||0)+'%"></i></div><b>'+(p==null?'--':p+'%')+'</b></div>'}).join('');
 const facts=it.filter(x=>!/^(cluster|node|disk)/i.test(x.head)),stamp=fOk?Date.parse(f.stamp)/1000:NaN;
 $('#fl3').innerHTML=(B[0]||('<div class="secttl"><span>Disks</span><span>'+fr(dk)+'</span></div>'+disks))+(B[2]||'')+
  (facts.length?'<div id="fgrid">'+facts.map(fact).join('')+'</div>':'')+'<div id="fmeta">'+(isFinite(stamp)?'Checked '+esc(ago(stamp)):esc(f.empty_reason||f.error||'The fleet checks gave no time'))+(fOk&&f.rc?' \u00B7 a source is out of date':'')+'</div>';$('#fl1').dataset.ok='1'
}catch(e){const why=fleetWhy(e),prior=$('#fl1').dataset.ok==='1';
 if(prior){const n=$('#fnote');if(n)n.remove();$('#fl1').insertAdjacentHTML('afterbegin',T('Fleet refresh failed',why,'Showing the last good read','bad').replace('class="tile','id="fnote" class="tile'))}
 else{$('#fl1').innerHTML=(typeof DeckUI=='object'&&DeckUI.fleetNotice)?DeckUI.fleetNotice({err:why}).html:T('Fleet','Not reachable',why,'bad');$('#fl2').innerHTML='';$('#fl3').innerHTML=''}}}
let fleetLast=null;
// Fleet is not a red wall: a failing item reads from its mark and its word. The single most urgent one (a machine first, then a host, then a site) carries the fill.
function markUrgent(){document.querySelectorAll('#fleet .urgent').forEach(e=>e.classList.remove('urgent'));
 // Machines tiles (.tile.node) are built by DeckUI.bMachines into #fl3; the older cluster-node tiles sit in #fl1 #fnd. Both are machines, so both come before any host or site.
 for(const s of ['#fl3 .node.bad','#fl1 #fnd .tile.bad','#fl2 #frc .chip.bad','#fl2 #fst .chip.bad','#fl1 .tile.bad','#fl2 .chip.bad']){const e=document.querySelector(s);if(e){e.classList.add('urgent');return}}}
if(typeof MutationObserver==='function')['#fl1','#fl2','#fl3'].forEach(s=>{const e=$(s);if(e)new MutationObserver(markUrgent).observe(e,{childList:true})});
// ---- house ----
// ==== HOUSE UI HELPERS BEGIN (pure: no DOM, no fetch, no globals; tests/house_ui.test.js loads this block) ====
const HouseUI=(()=>{
 const isObj=x=>x!==null&&typeof x==='object'&&!Array.isArray(x);
 const num=v=>typeof v==='number'&&isFinite(v)?v:null;
 const chargingOf=s=>/charg/i.test(s||'')&&!/not |dis|stop|complete|idle|done/i.test(s||'');
 const on=s=>typeof s==='string'&&s!=='unavailable'&&s!=='unknown'&&s!=='';
 // One calm line of what the house is doing now. Every fact names the entity it came from, and a fact is
 // only printed when its source answered: no lock sensors means no lock claim, never "all locked".
 function facts(ha,car,cams){
  const e=isObj(ha)&&isObj(ha.entities)&&!ha.error?ha.entities:{},ids=Object.keys(e),out=[];
  const st=id=>isObj(e[id])?e[id]:null;
  const locks=ids.filter(id=>/^lock\./.test(id)&&on(e[id].state));
  const doors=ids.filter(id=>/^binary_sensor\..*(door|garage|window|entry)/.test(id)&&on(e[id].state));
  const temps=ids.filter(id=>/^sensor\..*temperature/.test(id)&&on(e[id].state)&&isFinite(Number(e[id].state)));
  if(locks.length){const open=locks.filter(id=>e[id].state!=='locked').length;
   out.push({k:'Locks',v:open?open+' unlocked':'all locked',mark:open?'bad':'ok',src:locks.length+' lock entities'})}
  if(doors.length){const open=doors.filter(id=>e[id].state==='on').length;
   out.push({k:'Doors',v:open?open+' open':'all closed',mark:open?'bad':'ok',src:doors.length+' door sensors'})}
  if(temps.length){const vals=temps.map(id=>Number(e[id].state)),t=Math.round(Math.max(...vals));
   out.push({k:'Warmest room',v:t+' '+(e[temps[0]].unit||'\u00B0F'),mark:t>=82?'bad':t>=78?'warn':'ok',src:temps.length+' temperature sensors'})}
  const cs=isObj(cams)&&Array.isArray(cams.cams)?cams.cams.filter(x=>x&&typeof x.ready==='boolean'):null;
  const ready=cs?cs.filter(x=>x.ready).length:null;
  if(ready!=null)out.push({k:'Cameras',v:ready+' of '+cs.length+' live',mark:ready===cs.length?'ok':ready?'warn':'bad',src:'MediaMTX paths'});
  if(isObj(car)&&!car.error){
   const b=num(car.battery),ch=chargingOf(String(car.charging||''));
   if(b!=null)out.push({k:'Car',v:Math.round(b)+'%'+(ch?' charging':'')+(car.locked===true?' \u00B7 locked':car.locked===false?' \u00B7 UNLOCKED':''),
    mark:car.locked===false||car.stale?'warn':'ok',src:'car.json'})}
  const wc=st('binary_sensor.whoop_local_connected'),wb=st('sensor.whoop_local_battery');
  if(wc)out.push({k:'WHOOP',v:wc.state==='on'?'on the wrist':'off',mark:wc.state==='on'?'ok':'warn',
   src:wb&&on(wb.state)?'strap '+Math.round(Number(wb.state))+'%':'strap'});
  return out}
 // The line keeps four facts; the rest stay available as the tooltip so nothing is invented or dropped silently.
 function nowLine(ha,car,cams){
  const fs=facts(ha,car,cams),hasHa=isObj(ha)&&!ha.error;
  const miss=[];
  if(!hasHa)miss.push('Home Assistant');
  if(hasHa&&!fs.some(f=>f.k==='Locks'))miss.push('lock sensors');
  if(hasHa&&!fs.some(f=>f.k==='Doors'))miss.push('door sensors');
  return {facts:fs,shown:fs.slice(0,4),text:fs.slice(0,4).map(f=>f.k.toLowerCase()+' '+f.v).join(' \u00B7 '),
   title:fs.map(f=>f.k+': '+f.v+' ('+f.src+')').join('\n'),
   mark:!fs.length?'bad':fs.some(f=>f.mark==='bad')?'bad':fs.some(f=>f.mark==='warn')?'warn':'ok',
   note:miss.length?'not reported: '+miss.join(', '):''}}
 // A live tile that stops advancing is dead even when the element still looks fine: 5 s without a frame
 // counts as a stall, and the tile drops to snapshots instead of waiting for its 9 s timer.
 const STALL_MS=5000;
 function stalled(now,lastFrameAt){const a=num(now),b=num(lastFrameAt);if(a==null||b==null)return false;return a-b>=STALL_MS}
 // Home Assistant weather states arrive as one word ("partlycloudy"); the tile says it like a person would.
 const WEATHER={clear:'Clear',sunny:'Sunny',partlycloudy:'Partly cloudy',cloudy:'Cloudy',fog:'Fog',hail:'Hail',
  lightning:'Lightning',lightning_rainy:'Lightning and rain',rainy:'Rain',pouring:'Heavy rain',snowy:'Snow',
  'snowy-rainy':'Snow and rain',windy:'Windy',windy_variant:'Windy',exceptional:'Severe'};
 const weatherWord=s=>{if(!s||!s.state)return '--';const k=String(s.state).toLowerCase();
  return WEATHER[k]||(k.charAt(0).toUpperCase()+k.slice(1).replace(/[-_]+/g,' '))};
 // House now (Home's first line). Internet and router (HA reachability sensors), cameras (MediaMTX ready), tailnet (own devices online),
 // the car's lock and whether you are home (person.mesh). Each fact comes from its own source; a missing one says "not reported", never a guess.
 // The house facts above (locks, doors, warmest room, WHOOP) ride after them when Home Assistant serves those entities.
 const ageOf=(t,now)=>{const x=num(t),n=num(now);if(x==null||n==null)return '';const s=Math.max(0,Math.round(n/1000-x));return s<45?'just now':s<5400?Math.max(1,Math.round(s/60))+' min ago':s<172800?Math.round(s/3600)+' h ago':Math.round(s/86400)+' d ago'};
 function headline(ha,car,cams,now,ts){
  const haOk=isObj(ha)&&!ha.error&&isObj(ha.entities),e=haOk?ha.entities:{};
  const st=id=>isObj(e[id])&&on(e[id].state)?e[id]:null;
  const parts=[];let bad=0,warn=0,miss=0,seen=0;
  const reach=(id,label)=>{const s=st(id);if(!s){miss++;parts.push(label+' not reported');return}seen++;const up=s.state==='on';if(!up)bad++;parts.push(label+(up?' up':' down'))};
  reach('binary_sensor.internet_reachable','Internet');reach('binary_sensor.router_reachable','Router');
  const cs=isObj(cams)&&!cams.error&&Array.isArray(cams.cams)?cams.cams.filter(x=>x&&typeof x.ready==='boolean'):[];
  if(cs.length){seen++;const r=cs.filter(x=>x.ready).length;if(!r)bad++;else if(r<cs.length)warn++;parts.push(r+' of '+cs.length+' cameras live')}else{miss++;parts.push('Cameras not reported')}
  const tc=isObj(ts)&&!ts.error&&isObj(ts.counts)?ts.counts:null,own=tc?num(tc.own_devices):null,up=tc?num(tc.own_online):null;
  if(own!=null&&up!=null&&own>0){seen++;if(up<own)warn++;parts.push('Tailnet '+up+' of '+own+' online')}else{miss++;parts.push('Tailnet not reported')}
  const cached=isObj(car)&&(car.stale===true||car.fresh===false);
  if(isObj(car)&&!car.error&&typeof car.locked==='boolean'){seen++;if(!car.locked)warn++;parts.push('Car '+(car.locked?'locked':'unlocked')+(cached?' (cached)':''))}else{miss++;parts.push('Car not reported')}
  const p=st('person.mesh');if(p){seen++;parts.push(p.state==='home'?'Home':p.state==='not_home'?'Away':p.state.charAt(0).toUpperCase()+p.state.slice(1).replace(/_/g,' '))}else{miss++;parts.push('Presence not reported')}
  if(haOk)facts(ha,null,null).slice(0,2).forEach(f=>parts.push(f.k+' '+f.v));
  if(!seen)return {mark:'bad',word:'House not reporting',line:'Home Assistant, the cameras, the tailnet and the car did not answer. It tries again on its own.',src:'',title:''};
  const upd=['binary_sensor.internet_reachable','binary_sensor.router_reachable','person.mesh'].map(id=>isObj(e[id])?num(e[id].updated):null).filter(x=>x!=null);
  const src=[haOk?'Home Assistant'+(upd.length?' '+ageOf(Math.max(...upd),now):''):'Home Assistant not reporting',cs.length?'MediaMTX':'',tc?'tailnet'+(num(ts.t)!=null?' '+ageOf(ts.t,now):''):'',
   isObj(car)&&!car.error?'car'+(num(car.seen)!=null?' seen '+ageOf(car.seen,now):''):''].filter(Boolean).join(' \u00B7 ');
  return {mark:bad?'bad':warn||miss?'warn':'ok',word:bad?'Needs a look':miss?'Partly reported':warn?'Check the house':'All good',line:parts.join(' \u00B7 '),src,title:parts.join('\n')}}
 return {facts,nowLine,headline,weatherWord,stalled,chargingOf,STALL_MS};
})();
// ==== HOUSE UI HELPERS END ====

// ==== HOUSE HEALTH BEGIN (pure: no DOM, no fetch; tests/house_health.test.js loads this block) ====
// null = Home Assistant has no reading for it; the House page says so in words (one empty state when none of the health sensors report)
const HEALTH_SENSORS=[['Heart rate','hr',' bpm'],['HRV','hrv',' ms'],['Sleep','sleep_h',' h'],['Watch battery','battery','%']];
const nm=(s,d)=>{const v=s&&s.state!=null&&s.state!=='unavailable'&&s.state!=='unknown'?s.state:null;return v==null?null:(isNaN(+v)?String(v):(+v).toFixed(d??0))+(s.unit?' '+s.unit:'')};
const healthRows=w=>{if(!w||typeof w!=='object')return HEALTH_SENSORS.map(([l])=>({label:l,value:null}));
 return HEALTH_SENSORS.map(([l,k,u])=>{const n=w[k];const ok=typeof n==='number'&&isFinite(n);return {label:l,value:ok?(Number.isInteger(n)?String(n):n.toFixed(1))+u:null}})};
// ==== HOUSE HEALTH END ====
// the car card says when the CAR was last seen (car.json ageSeconds, worked out by the server) and marks cached values; DeckUI.carCard owns the markup
async function car(){let h='',c=null;try{c=await jget('/api/car');h=typeof DeckUI==='object'?DeckUI.carCard(c,Date.now()):T('Car','Loading','The page is still starting.','stale')}catch(e){c={error:'deck did not answer'};h=T('Car','Not reporting','The deck did not answer. It tries again on its own.','bad')}
 $('#car').innerHTML=h;return c}
function paintHouseNow(h){const el=$('#hn');if(!el)return;el.dataset.mark=h.mark;el.title=h.title||'';
 el.innerHTML='<div class="hnl">'+SD(h.mark)+'<b>'+esc(h.word)+'</b></div><div class="hnf">'+esc(h.line)+'</div>'+(h.src?'<div class="t">'+esc(h.src)+'</div>':'')}
// a guest House is cameras and the bedroom speaker button: Home Assistant states, Apple Watch, car and ink are owner reads
async function ha(){if(GUEST)return;
 const [hr,cr,cm,tr]=await Promise.allSettled([jget('/api/ha'),car(),jget('/api/cams'),jget('/api/tailscale')]);
 const val=x=>x.status==='fulfilled'?x.value:{error:'deck did not answer'};
 try{paintHouseNow(HouseUI.headline(val(hr),val(cr),val(cm),Date.now(),val(tr)))}catch(err){}
 try{if(hr.status!=='fulfilled')throw hr.reason;const r=hr.value||{},e=r.entities||{};
 let watch=null;try{watch=await jget('/api/watch')}catch(err){watch={error:'deck did not answer'}}
 if(r.error){$('#vit').innerHTML=T('House','Not reporting','Check that Home Assistant is running. It tries again on its own.','bad',[String(r.error).slice(0,80)]);return}
 const ago2=x=>x&&x.updated?'Updated '+ago(x.updated):'';
 // the vitals tiles are about 117 px wide on a landscape phone: their freshness is the bare age ("38 min ago"), one line, never "Updated 38 min / ago"
 const agev=x=>x&&x.updated?ago(x.updated):'';
 const wage=watch&&watch.t?ago(watch.t):(watch&&watch.error==='file missing'?'No watch file yet':'time unknown');
 const health=healthRows(watch&&!watch.error?watch:null);
 const why=watch&&watch.error?(watch.error==='file missing'?'No watch file yet. It shows up after the next hourly check.':'The watch feed did not answer. It tries again on its own.'):(watch&&watch.reason)||'';
 const readings=watch&&watch.error?(typeof DeckUI==='object'?DeckUI.watchEmpty(watch,Date.now()):T('Apple Watch','Not reporting',why,'bad',[String(watch.error).slice(0,80)])):(health.some(x=>x.value!=null)?health.map(x=>T(x.label,x.value==null?'No reading':x.value,wage)).join(''):(typeof DeckUI==='object'?DeckUI.watchEmpty(watch,Date.now()):''));
 $('#vit').innerHTML=readings+T('Weather',wxWord(e['weather.forecast_home']),agev(e['weather.forecast_home']),'wxt');
 const ink=(l,id)=>{const s=e[id];if(typeof DeckUI==='object'&&DeckUI&&DeckUI.inkTile)return DeckUI.inkTile(l,s,Date.now());const v=s&&isFinite(parseFloat(s.state))?Math.round(parseFloat(s.state))+'%':'No reading';return T(l+' ink',v,ago2(s)||'Home Assistant',v==='No reading'?'stale':'ok')};
 $('#ink').innerHTML=ink('Black','sensor.hp_envy_6400_series_black_cartridge')+ink('Color','sensor.hp_envy_6400_series_tri_color_cartridge');
 const b=e['media_player.main_bedroom'];$('#bedst').textContent=b?b.state:'No reading';$('#bedsrc').textContent=ago2(b)||'Home Assistant'}catch(e){$('#vit').innerHTML=T('House','Not reporting','The deck did not answer. It tries again on its own.','bad')}}
$('#bedpp').onclick=async()=>{flag(await fetch('/api/ha-media?v=play-pause&host='+encodeURIComponent(host),{method:'POST'}).then(r=>r.json()));setTimeout(ha,800)};
// ---- cameras: visible House tiles use native HLS media, with sequential JPEG fallback ----
const CAMS=[1,2,3,4],vw=$('#viewer'),vmedia=$('#vmedia'),vv=$('#vv'),vs=$('#vsnap');
const vname=i=>'Cam '+(i+1),camPath=i=>'/cam/eufy_cam'+(i+1)+'/index.m3u8';
const camEntity=i=>'camera.eufy_cam_'+(i+1);
// ==== CAMERA UI HELPERS BEGIN (pure dimensions, rotation and snapshot age) ====
const CameraUI=(()=>{
 const rotation=(raw,i)=>{if(raw==null)return i==2?90:0;const n=Number(raw);return Number.isInteger(n)&&n>=0&&n<=270&&n%90==0?n:(i==2?90:0)};
 const frame=(w,h,r)=>r%180?{w:h,h:w}:{w,h};
 const cacheAge=raw=>raw==null||raw===''||!Number.isFinite(Number(raw))||Number(raw)<0?null:Number(raw);
 // Snapshot fallback re-probes live video: 15 s, 30 s, 60 s ... capped at 5 min; reset once video plays.
 const retryDelay=fails=>Math.min(15000*2**Math.min(Math.max(0,Math.floor(fails)||0),5),300000);
 // Viewer zoom: translate(x,y) scale(s) with origin top-left, 1x to 6x. `box` is the picture inside the
 // W x H viewer (object-fit:contain leaves black bars). Along an axis where the zoomed picture is wider
 // than the viewer it must cover the viewer edge to edge; where it is narrower it stays centered, so a
 // pan never drags the picture into the bars. zoomAt keeps the content under (px,py) at (qx,qy).
 const ZMIN=1,ZMAX=6,ZTAP=2.5;
 const axis=(t,s,b0,bl,L)=>(s*bl>=L?Math.min(-s*b0,Math.max(L-s*(b0+bl),t)):(L-s*bl)/2-s*b0)+0;
 const clampZoom=(z,W,H,box)=>{const s=Math.min(ZMAX,Math.max(ZMIN,Number(z.s)||1)),b=box||{x:0,y:0,w:W,h:H};
  if(s<=ZMIN)return {s:1,x:0,y:0};return {s,x:axis(z.x||0,s,b.x,b.w,W),y:axis(z.y||0,s,b.y,b.h,H)}};
 const zoomAt=(z,s,px,py,qx,qy,W,H,box)=>{const cx=(px-z.x)/z.s,cy=(py-z.y)/z.s,t=Math.min(ZMAX,Math.max(ZMIN,s));return clampZoom({s:t,x:qx-t*cx,y:qy-t*cy},W,H,box)};
 // double tap: zoomed in goes back to 1x, 1x goes to 2.5x around the tap point
 const tapZoom=(z,px,py,W,H,box)=>zoomAt(z,z.s>1.05?1:ZTAP,px,py,px,py,W,H,box);
 // where object-fit:contain puts a sw x sh source (turned by rot degrees) inside W x H
 const contentBox=(W,H,sw,sh,rot)=>{if(!(sw>0&&sh>0))return null;const a=rot%180?sh/sw:sw/sh;
  const w=W/H>a?H*a:W,h=W/H>a?H:W/a;return {x:(W-w)/2,y:(H-h)/2,w,h}};
 // A snapshot frame is a plain same-origin URL with a changing counter: never blob: or data: (the iPhone shell blocks both).
 const snapUrl=(entity,n)=>'/api/cam?e='+encodeURIComponent(String(entity==null?'':entity))+'&live=1&_='+(Math.max(0,Math.floor(Number(n)))||0);
// A tile gives HLS 15 s and the viewer 20 s to start playing, then falls back to snapshot polling. A cold MediaMTX muxer needs 6.4 to 8.6 s for its
// first frame (12 trials, median 7.1 s; docs/release-feedback-20261004.md), so a shorter window tears hls.js down before it can ever play. The snapshot
// poster is on screen from the first frame, so waiting is never black. A muxer that needs longer is picked up by the live probe (15 s, 30 s, 60 s ...).
const giveUpMs=viewer=>viewer?20000:15000;
 // Live video that stops (waiting) and does not resume within this long drops to snapshots instead of showing a stuck state.
 const stallMs=viewer=>viewer?6000:5000;
 // Human status words only; the badge never shows engineering states. state: live | snap | reconnecting | dark | offline | connecting.
 const ageLabel=sec=>{const s=Math.max(0,Math.floor(Number(sec)||0));return s<3?'just now':s<60?s+' s ago':s<3600?Math.floor(s/60)+' min ago':Math.floor(s/3600)+' h ago'};
 const statusText=(state,ageSec)=>state=='live'?'Live':state=='snap'?'Snapshot, '+ageLabel(ageSec):state=='dark'?'Dark image':state=='offline'?'Camera offline':state=='reconnecting'?'Reconnecting':'Connecting';
 // The low-latency config plays a cold stream (first frame 6.4 to 8.6 s) and a warm one (0.3 s). A plain-segment config never played
 // within 20 s on a cold stream (hls.js logged fragGap and level playlist time-outs), so no client gets it.
 const hlsConfig=()=>({lowLatencyMode:true,liveSyncDurationCount:2,liveMaxLatencyDurationCount:4,maxBufferLength:3,backBufferLength:0});
// Which player starts. The iPhone shell (OmarchyDeck/) blocks every non-deck URL with its default-deny content rule list, blob: included, and hls.js hands the
// video a blob: MediaSource, so there it never attaches: the element fails with MEDIA_ERR_SRC_NOT_SUPPORTED at once and hls.js raises no event (reproduced in WebKitGTK
// with the same rule list, qa/webkit-hls-probe.mjs RULES=1). Native HLS is a plain same-origin URL the rule allows, so the shell goes native first; hls.js
// stays first everywhere else (Android Chromium reports native HLS but never fetched the stream on the Pixel). native: canPlayType says HLS plays; hlsjs: hls.js can attach.
const pickEngine=(shell,native,hlsjs)=>shell&&native?'native':hlsjs?'hlsjs':native?'native':'snap';
 // cam-diag beacon body: whitelisted event, camera, mode and at most 12 scalar fields, 2 KB at most; anything else yields null
 const DIAG_EVENT=/^[a-z0-9_.]{1,32}$/,DIAG_KEY=/^[a-z0-9_]{1,24}$/,DIAG_MODES=['hls','snap','native','boot'];
 function diagBody(e,cam,mode,d){
  if(typeof e!=='string'||!DIAG_EVENT.test(e)||!DIAG_MODES.includes(mode))return null;
  const c=Number(cam);if(!Number.isInteger(c)||c<0||c>4)return null;
  const o={};let n=0;
  if(d&&typeof d==='object'&&!Array.isArray(d))for(const k of Object.keys(d)){if(n>=12)break;if(!DIAG_KEY.test(k))continue;const v=d[k];
   if(typeof v==='string')o[k]=v.slice(0,120);else if(typeof v==='boolean')o[k]=v;else if(typeof v==='number'&&Number.isFinite(v))o[k]=v;else continue;n++}
  const body=JSON.stringify({e,cam:c,mode,d:o});
  return body.length<=2000?body:null}
 // at most `total` beacons per page load and `perKey` per key (event and camera); returns true when one may be sent
 function diagBudget(total,perKey){let used=0;const seen={};
  return key=>{const k=String(key);if(used>=total||(seen[k]||0)>=perKey)return false;seen[k]=(seen[k]||0)+1;used++;return true}}
 // Measured rate and stall. The frame counter is getVideoPlaybackQuality (WebKit: webkitDecodedFrameCount). No counter means no rate, never a guess.
 const FRAME_STALL_MS=5000;
 const frameRate=(prev,cur,dtMs)=>Number.isFinite(prev)&&Number.isFinite(cur)&&Number.isFinite(dtMs)&&dtMs>0&&prev>=0&&cur>=prev?(cur-prev)*1000/dtMs:null;
 const rateText=(f,w,h)=>{const size=w>0&&h>0?Math.round(w)+'\u00D7'+Math.round(h):'';return f==null?['rate unknown',size].filter(Boolean).join(' \u00B7 '):[(Math.round(f*10)/10)+' fps',size||'size unknown','measured now'].join(' \u00B7 ')};
 const stalledFor=(lastAt,now,limit)=>Number.isFinite(lastAt)&&lastAt>0&&now-lastAt>limit;
 const hhmm=ms=>{const d=new Date(ms);return String(d.getHours()).padStart(2,'0')+':'+String(d.getMinutes()).padStart(2,'0')};
 const stallText=lastAt=>'Stalled \u00B7 last frame '+hhmm(lastAt);
 const REASONS={timeout:'The camera did not answer',load:'The frame did not load',hls_fatal:'The live stream stopped',stall:'The live stream stopped',video_error:'The video failed',src_blocked:'This browser cannot play the live stream',hls_blocked:'This browser cannot play the live stream',no_support:'This browser cannot play the live stream',start_error:'The live stream did not start'};
 const reasonText=r=>'Reason: '+(Object.prototype.hasOwnProperty.call(REASONS,r)?REASONS[r]:'unknown');
 return {rotation,frame,cacheAge,retryDelay,clampZoom,zoomAt,tapZoom,contentBox,ZMIN,ZMAX,ZTAP,snapUrl,giveUpMs,stallMs,ageLabel,statusText,hlsConfig,pickEngine,diagBody,diagBudget,frameRate,rateText,stalledFor,hhmm,stallText,reasonText,FRAME_STALL_MS};
})();
// ==== CAMERA UI HELPERS END ====
const camRotation=i=>CameraUI.rotation(localStorage.getItem('cam-rotation-'+(i+1)),i);
let vi=0,vOpen=false,hlsP=null,tiles=[],viewer=null;
function loadHls(){if(window.Hls)return Promise.resolve();return hlsP||(hlsP=new Promise((ok,no)=>{const s=document.createElement('script');s.src='/hls.min.js';s.onload=ok;s.onerror=()=>{hlsP=null;s.remove();no()};document.head.appendChild(s)}))}
// The rotated element gets the *swapped viewport* before object-fit. The viewer uses contain (no edge cropped); a tile turned sideways uses cover (.rot) so it fills without side bars.
function fitCamera(s){const r=camRotation(s.i),frame=CameraUI.frame(s.media.clientWidth,s.media.clientHeight,r);
 s.media.style.setProperty('--media-w',frame.w+'px');s.media.style.setProperty('--media-h',frame.h+'px');
 s.media.style.setProperty('--rotation',r+'deg');if(s!==viewer)s.root.classList.toggle('rot',r%180!==0)}
function updateRotation(){tiles.forEach(fitCamera);if(viewer){fitCamera(viewer);$('#vrotate').textContent='Rotate '+camRotation(vi)+'°';$('#vrotate').setAttribute('aria-label','Rotate '+vname(vi)+' clockwise, currently '+camRotation(vi)+' degrees')}}
function rotateViewer(){const next=(camRotation(vi)+90)%360;localStorage.setItem('cam-rotation-'+(vi+1),next);resetZoom();updateRotation()}
function judge(im){try{const c=document.createElement('canvas');c.width=32;c.height=18;const x=c.getContext('2d');x.drawImage(im,0,0,32,18);const d=x.getImageData(0,0,32,18).data;let sum=0;for(let i=0;i<d.length;i+=4)sum+=.2126*d[i]+.7152*d[i+1]+.0722*d[i+2];return sum/(d.length/4)}catch(e){return 99}}
function paintStatus(s){paintRate(s);const b=s.root.querySelector('.cam-status');if(!b)return;const t=CameraUI.statusText(s.state||'connecting',s.snapAt?(Date.now()-s.snapAt)/1000:0);if(b.textContent!==t)b.textContent=t}
// Measured rate and stall. A frame counter that advances is a frame shown; one that stops for FRAME_STALL_MS is a stall. No counter, no rate.
function frameCount(v){try{if(v.getVideoPlaybackQuality){const q=v.getVideoPlaybackQuality();if(q&&Number.isFinite(q.totalVideoFrames))return q.totalVideoFrames}if(Number.isFinite(v.webkitDecodedFrameCount))return v.webkitDecodedFrameCount}catch(e){}return null}
function sampleRate(s,now){const n=s.active&&s.mode=='hls'&&s.playing?frameCount(s.video):null;
 if(n==null){s.fps=null;s.rateN=null;s.stalled=false;paintRate(s);return}
 if(s.rateN!=null&&n>s.rateN)s.lastFrameAt=now;
 s.fps=s.rateN==null?null:CameraUI.frameRate(s.rateN,n,now-s.rateT);
 s.rateN=n;s.rateT=now;
 s.stalled=CameraUI.stalledFor(s.lastFrameAt,now,CameraUI.FRAME_STALL_MS);
 paintRate(s)}
function paintRate(s){
 const m=s.video,stalled=!!s.stalled&&!!s.playing;
 const t=stalled?CameraUI.stallText(s.lastFrameAt):s.state=='offline'?CameraUI.reasonText(s.reason):s.state=='live'?CameraUI.rateText(s.fps,m.videoWidth,m.videoHeight):'';
 const el=s.root.querySelector('.cam-rate');if(el&&el.textContent!==t)el.textContent=t;
 if(s===viewer)viewerStall(stalled,t)}
// The viewer shows the stall in its message line with a Retry button; the tile shows the same words on its rate line.
let stallShown=false,vRetry=null;
function viewerStall(on,t){const msg=$('#vmsg');if(!msg)return;
 if(!on){if(stallShown){stallShown=false;msg.textContent='';if(vRetry&&vRetry.parentNode)vRetry.parentNode.removeChild(vRetry)}return}
 if(!vRetry){vRetry=document.createElement('button');vRetry.id='vretry';vRetry.className='vb';vRetry.textContent='Retry';vRetry.setAttribute('aria-label','Retry this camera stream');vRetry.onclick=()=>retryStream(viewer)}
 stallShown=true;msg.textContent=t;msg.appendChild(vRetry)}
// Retry reloads only this stream; the other tiles keep playing.
function retryStream(s){if(!s.active)return;s.stalled=false;s.fps=null;s.reason='';s.fails=0;paintRate(s);startCamera(s)}
function cameraState(s,state){s.state=state;const d=s.root,has=!!s.url;d.dataset.state=state;
 d.classList.toggle('live',state=='live');d.classList.toggle('black',state=='dark');d.classList.toggle('nofeed',state=='offline');d.classList.toggle('old',state=='offline'&&has);
 d.classList.toggle('connecting',!has&&(state=='connecting'||state=='reconnecting'));
 paintStatus(s);
 if(s===viewer){d.classList.toggle('wait',state=='offline'||(!has&&state!='live'&&state!='dark'));d.classList.toggle('blk',state=='dark');
  $('#vmsg').textContent=state=='dark'?'Dark image from '+vname(s.i)+'. The sensor may be covered.':state=='offline'?vname(s.i)+' is offline. Trying again.':'Connecting to '+vname(s.i)}
 else d.querySelector('em').textContent=state=='dark'?'Dark image':state=='offline'?'Camera offline':'Connecting'}
// A tile keeps its last frame when it stops (it comes back with an honest "Snapshot, 3 min ago" instead of black); the viewer shows other cameras, so it clears.
function stopCamera(s,keep){if(!s)return;s.active=false;s.gen++;clearTimeout(s.timer);s.timer=0;clearTimeout(s.retry);s.retry=0;clearTimeout(s.stall);s.stall=0;
 if(s.hls){s.hls.destroy();s.hls=null}
 s.video.pause();s.video.removeAttribute('src');s.video.load();
 if(s===viewer&&!keep){s.image.removeAttribute('src');s.url=null;s.snapAt=0;s.root.classList.remove('poster');vw.classList.remove('snap','wait','blk','old','connecting')}
 s.playing=false;s.root.classList.remove('live')}
function snapshotMode(s,g,reason){if(!s.active||s.gen!=g||s.mode=='snap')return;
 clearTimeout(s.timer);clearTimeout(s.stall);if(s.hls){s.hls.destroy();s.hls=null}s.video.pause();s.video.removeAttribute('src');s.video.load();
 s.reason=reason||'unknown';camDiag('fallback',s.i+1,s.native?'native':'hls',{reason:reason||'unknown',viewer:s===viewer});
 s.mode='snap';s.playing=false;s.root.classList.remove('poster','live');s.root.classList.add('snap');cameraState(s,s.url?'snap':'connecting');snapshot(s,g);scheduleLive(s,g)}
// Keep the last snapshot on screen; only tear it down for HLS once the playlist answers.
function scheduleLive(s,g){clearTimeout(s.retry);s.retry=0;
 // hls.js was refused its MediaSource blob once on this tile (the iPhone shell's content rules): it never works for it, so with no native HLS the tile stays on snapshots and stops probing
 if(s.hlsBlocked&&!canNative(s.video))return;
 s.retry=setTimeout(()=>probeLive(s,g),CameraUI.retryDelay(s.fails++))}
async function probeLive(s,g){if(!s.active||s.gen!=g||s.mode!='snap')return;let ok=false;
 try{const r=await fetch(camPath(s.i),{cache:'no-store',signal:AbortSignal.timeout(5000)});ok=r.ok;if(r.status===401)camKeyReset()}catch(e){}
 if(!s.active||s.gen!=g||s.mode!='snap')return;
 if(ok)startCamera(s);else scheduleLive(s,g)}
// Beacons: fire and forget, never awaited, never throw. At most 40 per page load (5 per event and camera), whitelisted fields only.
const camDiagOk=CameraUI.diagBudget(40,5),DIAG_FIRST=new Set();
function camDiag(e,cam,mode,d){try{const body=CameraUI.diagBody(e,cam,mode,d);if(!body||!camDiagOk(e+':'+cam))return;
 fetch('/api/cam-diag',{method:'POST',keepalive:true,headers:{'Content-Type':'application/json'},body}).catch(()=>{})}catch(err){}}
// snap_ok and snap_fail: the first of each per tile (and per viewer camera) only
function camDiagFirst(e,s,d){const k=e+':'+s.i+':'+(s===viewer?'v':'t');if(DIAG_FIRST.has(k))return;DIAG_FIRST.add(k);camDiag(e,s.i+1,'snap',Object.assign({viewer:s===viewer},d))}
let bootSent=false;
function camBoot(video,eng){if(bootSent)return;bootSent=true;
 camDiag('boot',0,'boot',{hls:typeof Hls!=='undefined',supported:typeof Hls!=='undefined'&&!!Hls.isSupported(),mms:typeof ManagedMediaSource!=='undefined',ms:typeof MediaSource!=='undefined',
  native:canNative(video)?'yes':'no',inline:!!video.playsInline,shell:IN_SHELL,engine:String(eng||''),hlsjs:typeof Hls!=='undefined'&&Hls.version?String(Hls.version):'none'})}
function canNative(video){try{return !!video.canPlayType('application/vnd.apple.mpegurl')}catch(e){return false}}
// The /cam/ key (scoped to /cam/ only) lets the native player's very first request, the master playlist, authorize without relying on the web view's cookie jar;
// every playlist line below it already carries the key. One fetch per page load; an empty answer is not remembered.
// ==== CAM KEY BEGIN (tests/deck20261029_webshell.test.js loads this block with a stub fetch) ====
// A deck server restart mints a new key: a 401 or a media error on the native player drops the remembered key, so the next start fetches the new one.
let camKeyP=null;
function camKey(){return camKeyP||(camKeyP=fetch('/api/camkey',{cache:'no-store',credentials:'same-origin',signal:AbortSignal.timeout(4000)}).then(r=>r.ok?r.json():null)
 .then(j=>j&&typeof j.k==='string'&&/^[A-Za-z0-9_-]{8,64}$/.test(j.k)?j.k:'').catch(()=>'').then(k=>{if(!k)camKeyP=null;return k}))}
function camKeyReset(){camKeyP=null}
// ==== CAM KEY END ====
// Point the element at the HLS playlist itself. False when the tile was stopped or moved on while the key was fetched.
async function useNative(s,g){s.native=true;const k=await camKey();if(!s.active||s.gen!=g||s.mode!='hls')return false;
 s.video.src=camPath(s.i)+(k?'?k='+encodeURIComponent(k):'');return true}
function camHlsErr(s,d){camDiag('hls_error',s.i+1,'hls',{type:String(d&&d.type||''),details:String(d&&d.details||''),fatal:!!(d&&d.fatal),code:d&&d.response&&Number.isFinite(d.response.code)?d.response.code:0,viewer:s===viewer})}
// A frame is a plain same-origin URL, never blob: or data: (the iPhone shell blocks both). Load it off screen, then swap, so there is no flicker.
// poster=true: one frame shown while HLS connects; the snapshot loop (poster falsy) polls until HLS plays again.
let snapSeq=0;
function snapLoad(url){return new Promise((ok,no)=>{const im=new Image(),t=setTimeout(()=>{im.onload=im.onerror=null;im.src='';no(Error('timeout'))},8000);
 im.onload=()=>{clearTimeout(t);(im.decode?im.decode():Promise.resolve()).catch(()=>{}).then(()=>ok(im))};im.onerror=()=>{clearTimeout(t);no(Error('load'))};im.src=url})}
async function snapshot(s,g,poster){if(!s.active||s.gen!=g||(!poster&&s.mode!='snap'))return;
 const url=CameraUI.snapUrl(camEntity(s.i),++snapSeq);
 try{const im=await snapLoad(url);if(!s.active||s.gen!=g)return;
  if(poster&&(s.mode=='snap'||s.playing))return;
  s.image.src=url;s.url=url;s.snapAt=Date.now();
  if(poster){s.root.classList.add('poster');if(s.state!='live')cameraState(s,'snap')}
  else cameraState(s,judge(im)<6?'dark':'snap');
  camDiagFirst('snap_ok',s,{poster:!!poster,w:im.naturalWidth||0,h:im.naturalHeight||0})
 }catch(e){if(s.active&&s.gen==g){if(!poster){s.reason=String(e&&e.message||'load');cameraState(s,'offline')}camDiagFirst('snap_fail',s,{poster:!!poster,reason:String(e&&e.message||'error')})}}
 finally{if(!poster&&s.active&&s.gen==g&&s.mode=='snap')s.timer=setTimeout(()=>snapshot(s,g),s===viewer?1000:2500)}}
async function startCamera(s){stopCamera(s,true);s.active=true;s.mode='hls';s.native=false;s.triedNative=false;s.playing=false;const g=s.gen;
 s.root.classList.remove('snap');fitCamera(s);
 // the last frame we hold is on screen at once (a stale one says how old it is); the fresh poster replaces it a moment later
 s.root.classList.toggle('poster',!!s.url);cameraState(s,s.url?'snap':'connecting');
 s.timer=setTimeout(()=>snapshotMode(s,g,'timeout'),CameraUI.giveUpMs(s===viewer));
 snapshot(s,g,true);
 const video=s.video,url=camPath(s.i),can=canNative(video);
 try{
  let eng=CameraUI.pickEngine(IN_SHELL,can,!s.hlsBlocked);
  if(eng=='hlsjs'){
   await loadHls().catch(()=>{});
   if(!s.active||s.gen!=g||s.mode!='hls')return;
   eng=CameraUI.pickEngine(IN_SHELL,can,!!(window.Hls&&Hls.isSupported()))}
  camBoot(video,eng);
  camDiag('engine',s.i+1,eng=='hlsjs'?'hls':eng,{viewer:s===viewer,shell:IN_SHELL});
  if(eng=='hlsjs'){
   const h=new Hls(CameraUI.hlsConfig());
   s.hls=h;h.on(Hls.Events.ERROR,(_,d)=>{camHlsErr(s,d);if(d.fatal)snapshotMode(s,g,'hls_fatal')});
   h.attachMedia(video);h.loadSource(url);
  }else if(eng=='native'){if(!await useNative(s,g))return}
  else return snapshotMode(s,g,s.hlsBlocked?'hls_blocked':'no_support');
  video.play().catch(()=>{});
 }catch(e){snapshotMode(s,g,'start_error')}}
function makeCamera(i,root,media,video,image){const s={i,root,media,video,image,active:false,gen:0,hls:null,timer:0,retry:0,stall:0,fails:0,url:null,snapAt:0,state:'',mode:'',native:false,playing:false,hlsBlocked:false,fps:null,rateN:null,rateT:0,lastFrameAt:0,stalled:false,reason:''};
 video.addEventListener('playing',()=>{if(!s.active||s.mode!='hls')return;clearTimeout(s.timer);clearTimeout(s.stall);s.fails=0;s.playing=true;s.lastFrameAt=Date.now();s.rateN=null;s.stalled=false;root.classList.remove('poster');root.classList.add('live');cameraState(s,'live');camDiag('playing',s.i+1,s.native?'native':'hls',{viewer:s===viewer,w:video.videoWidth||0,h:video.videoHeight||0})});
 video.addEventListener('stalled',()=>{if(s.active&&s.mode=='hls')camDiag('stalled',s.i+1,s.native?'native':'hls',{viewer:s===viewer,ready:video.readyState,net:video.networkState})});
 // Live video that stalls says "Reconnecting" for a few seconds, then drops to snapshots. No state outlives the stall window.
 video.addEventListener('waiting',()=>{if(!s.active||s.mode!='hls'||!s.playing)return;cameraState(s,'reconnecting');clearTimeout(s.stall);const g=s.gen;s.stall=setTimeout(()=>snapshotMode(s,g,'stall'),CameraUI.stallMs(s===viewer))});
 video.addEventListener('error',()=>{if(!s.active||s.mode!='hls')return;const code=video.error&&Number.isFinite(video.error.code)?video.error.code:0;camDiag('video_error',s.i+1,s.native?'native':'hls',{code,viewer:s===viewer});
  if(s.native)camKeyReset();
  if(!s.hls){snapshotMode(s,s.gen,'video_error');return}
  // hls.js element refused its MediaSource blob before any frame (MEDIA_ERR_SRC_NOT_SUPPORTED): it cannot recover, so try the platform player once, else snapshots
  if(code==4&&!s.playing){const g=s.gen;s.hlsBlocked=true;s.hls.destroy();s.hls=null;s.video.removeAttribute('src');s.video.load();
   if(canNative(s.video)&&!s.triedNative){s.triedNative=true;camDiag('engine',s.i+1,'native',{viewer:s===viewer,shell:IN_SHELL,after:'blocked'});
    useNative(s,g).then(ok=>{if(ok)s.video.play().catch(()=>{})})}
   else snapshotMode(s,g,'src_blocked')}});
 new ResizeObserver(()=>{if(s.active)fitCamera(s)}).observe(media);
 return s}
// One watchdog tick for every tile: a live picture that stops advancing for 5 s drops to snapshots at once
// instead of waiting out the 9 s live timer, so a frozen tile is never left frozen until the next page visit.
setInterval(()=>{const now=Date.now();
 for(const s of tiles.concat(viewer?[viewer]:[])){
  if(!s.active||s.mode!='hls'||s.video.paused)continue;
  if(s.video.currentTime!==s.clock){s.clock=s.video.currentTime;s.frameAt=now}
  else if(HouseUI.stalled(now,s.frameAt||now))snapshotMode(s,s.gen)}},2000);
function ensureCameras(){if(tiles.length)return;const c=$('#cams');
 c.innerHTML=CAMS.map(i=>'<button class="cam press" data-i="'+(i-1)+'" aria-label="Open camera '+i+' live"><span class="cam-media"><video muted playsinline autoplay preload="none"></video><img alt=""></span><em>Connecting</em><span class="nm"><span>Cam '+i+'</span><i class="cam-status">Connecting</i><i class="cam-rate"></i></span></button>').join('');
 tiles=Array.from(c.children,(d,i)=>{d.onclick=()=>openViewer(i);const m=d.querySelector('.cam-media');return makeCamera(i,d,m,m.querySelector('video'),m.querySelector('img'))});
 viewer=makeCamera(vi,vw,vmedia,vv,vs)}
function syncCameras(){const active=!document.hidden&&mode!='ambient',onHome=pname()=='home'||pname()=='house',house=active&&onHome;
 if(!house||vOpen)tiles.forEach(s=>{if(s.active)stopCamera(s)});
 else{ensureCameras();tiles.forEach(s=>{if(!s.active)startCamera(s)})}
 if(viewer){if(!active||!vOpen||!onHome){if(viewer.active)stopCamera(viewer)}
  else if(!viewer.active){viewer.i=vi;startCamera(viewer)}}}
function cams(){syncCameras()}
// the "Snapshot, 8 s ago" words keep counting while a snapshot is on screen
setInterval(()=>{if(document.hidden)return;tiles.forEach(s=>{if(s.active&&s.state=='snap')paintStatus(s)});if(viewer&&viewer.active&&viewer.state=='snap')paintStatus(viewer)},1000);
// frame sampler: every 2 s, the measured rate and any stall, for every open stream (never while the page is hidden)
setInterval(()=>{if(document.hidden)return;const now=Date.now();tiles.forEach(s=>sampleRate(s,now));if(viewer)sampleRate(viewer,now)},2000);
function openViewer(i){ensureCameras();vi=((i%4)+4)%4;vOpen=true;resetZoom();vw.classList.add('on');$('#vname').textContent=vname(vi);
 $$('#vdots i').forEach((d,k)=>d.classList.toggle('on',k==vi));viewer.i=vi;updateRotation();syncCameras();$('#vclose').focus()}
function closeViewer(){vOpen=false;resetZoom();vw.classList.remove('on','snap','wait','blk','old','live','poster','connecting');syncCameras();document.querySelector('.cam[data-i="'+vi+'"]').focus()}
function stepViewer(d){if(!vOpen)return;vi=((vi+d)%4+4)%4;if(viewer.active)stopCamera(viewer);viewer.i=vi;resetZoom();
 $('#vname').textContent=vname(vi);$$('#vdots i').forEach((dot,k)=>dot.classList.toggle('on',k==vi));updateRotation();syncCameras()}
$('#vclose').onclick=closeViewer;$('#vprev').onclick=()=>stepViewer(-1);$('#vnext').onclick=()=>stepViewer(1);$('#vrotate').onclick=rotateViewer;
// ---- viewer zoom: two-finger pinch (1x to 6x), one-finger pan while zoomed, double tap 1x / 2.5x.
// At 1x a one-finger swipe still changes camera (left/right) or closes (down). Pointer events with
// touch-action:none on #viewer, so iPhone Safari never turns a pinch into page zoom.
let vz={s:1,x:0,y:0};
function applyZoom(z){vz=z;const on=z.s>1.001;$('#vzoom').style.transform=on?'translate('+z.x.toFixed(1)+'px,'+z.y.toFixed(1)+'px) scale('+z.s.toFixed(3)+')':'';
 vw.dataset.zoom=z.s.toFixed(2);vw.classList.toggle('zoomed',on);$('#vzl').textContent=(Math.round(z.s*10)/10)+'\u00D7';$('#vzl').setAttribute('aria-label','Zoom '+(Math.round(z.s*10)/10)+' times, tap to reset')}
function resetZoom(){applyZoom({s:1,x:0,y:0})}
$('#vzl').onclick=resetZoom;
// the picture's place inside the viewer: live video size, else the snapshot size, else the whole viewer
function vgeom(){const r=vmedia.getBoundingClientRect(),m=vw.classList.contains('snap')?vs:vv;
 return {W:r.width,H:r.height,box:CameraUI.contentBox(r.width,r.height,m.videoWidth||m.naturalWidth,m.videoHeight||m.naturalHeight,camRotation(vi))}}
function zoomTo(s,px,py,qx,qy,z0){const g=vgeom();applyZoom(CameraUI.zoomAt(z0||vz,s,px,py,qx,qy,g.W,g.H,g.box))}
{const P=new Map();let g=null,tap=null;
 const rel=e=>{const r=vmedia.getBoundingClientRect();return {x:e.clientX-r.left,y:e.clientY-r.top}};
 const two=()=>{const [a,b]=[...P.values()];return {m:{x:(a.x+b.x)/2,y:(a.y+b.y)/2},d:Math.hypot(a.x-b.x,a.y-b.y)||1}};
 vw.addEventListener('pointerdown',e=>{if(!vOpen||e.target.closest('.vb'))return;P.set(e.pointerId,rel(e));try{vw.setPointerCapture(e.pointerId)}catch(_){}
  if(P.size>=2){const t=two();g={k:'pinch',z0:vz,m0:t.m,d0:t.d}}else g={k:'one',z0:vz,p0:P.get(e.pointerId),t0:e.timeStamp,moved:false,multi:false}});
 vw.addEventListener('pointermove',e=>{if(!g||!P.has(e.pointerId))return;const p=rel(e);P.set(e.pointerId,p);
  if(g.k=='pinch'&&P.size>=2){const t=two();zoomTo(g.z0.s*t.d/g.d0,g.m0.x,g.m0.y,t.m.x,t.m.y,g.z0)}
  else if(g.k=='one'){const dx=p.x-g.p0.x,dy=p.y-g.p0.y;if(Math.hypot(dx,dy)>8)g.moved=true;
   if(g.z0.s>1.001){const q=vgeom();applyZoom(CameraUI.clampZoom({s:g.z0.s,x:g.z0.x+dx,y:g.z0.y+dy},q.W,q.H,q.box))}}});
 const end=e=>{if(!P.has(e.pointerId))return;const p=rel(e);P.delete(e.pointerId);if(!g)return;
  // one finger left after a pinch keeps panning from where the pinch stopped; it never changes camera
  if(g.k=='pinch'){if(P.size==1){const [q]=[...P.values()];g={k:'one',z0:vz,p0:q,t0:e.timeStamp,moved:true,multi:true}}else if(!P.size)g=null;tap=null;return}
  if(P.size)return;const was=g;g=null;if(e.type=='pointercancel')return;
  const dx=p.x-was.p0.x,dy=p.y-was.p0.y;
  if(!was.moved&&e.timeStamp-was.t0<300){
   if(tap&&e.timeStamp-tap.t<320&&Math.hypot(p.x-tap.x,p.y-tap.y)<40){tap=null;zoomTo(vz.s>1.05?1:CameraUI.ZTAP,p.x,p.y,p.x,p.y)}else tap={t:e.timeStamp,x:p.x,y:p.y};return}
  tap=null;if(was.multi||was.z0.s>1.001)return;
  if(Math.abs(dx)>60&&Math.abs(dx)>Math.abs(dy)*1.5)stepViewer(dx<0?1:-1);else if(dy>90&&Math.abs(dy)>Math.abs(dx)*1.5)closeViewer()};
 vw.addEventListener('pointerup',end);vw.addEventListener('pointercancel',end);
 // WebKit gesture events: cancel them while the viewer is open so the page itself never zooms
 for(const t of ['gesturestart','gesturechange','gestureend'])document.addEventListener(t,e=>{if(vOpen)e.preventDefault()},{passive:false});
 // desktop: ctrl+wheel (trackpad pinch) and plain wheel zoom around the cursor
 vw.addEventListener('wheel',e=>{if(!vOpen)return;e.preventDefault();const p=rel(e);zoomTo(vz.s*Math.exp(-e.deltaY*(e.ctrlKey?0.01:0.002)),p.x,p.y,p.x,p.y)},{passive:false});
 addEventListener('resize',()=>{if(vOpen&&vz.s>1.001)resetZoom()})}
addEventListener('keydown',e=>{if(!vOpen)return;if(e.key=='Escape')closeViewer();if(e.key=='ArrowRight')stepViewer(1);if(e.key=='ArrowLeft')stepViewer(-1);
 const cx=innerWidth/2,cy=innerHeight/2;if(e.key=='+'||e.key=='=')zoomTo(vz.s*1.5,cx,cy,cx,cy);if(e.key=='-')zoomTo(vz.s/1.5,cx,cy,cx,cy);if(e.key=='0')resetZoom()});
// ---- burn-in guard ----
let last=Date.now(),mode='awake',swallow=false,swT=0,ox=0,oy=0;
function setMode(m){mode=m;$('#app').style.opacity=m=='dim'?DIM_OPACITY:1;$('#amb').classList.toggle('on',m=='ambient');if(m=='ambient')drift();syncCameras()}
function drift(){const a=$('#ambin'),W=innerWidth-a.offsetWidth,H=innerHeight-a.offsetHeight;a.style.transform='translate('+Math.round(Math.random()*Math.max(0,W))+'px,'+Math.round(Math.random()*Math.max(0,H))+'px)'}
function shiftGrid(){ox=Math.floor(Math.random()*(SHIFT_MAX_PX+1));oy=Math.floor(Math.random()*(SHIFT_MAX_PX+1));$('#app').style.transform='translate('+ox+'px,'+oy+'px)'}
const guard=e=>{
 if(e.type=='pointerdown'||e.type=='touchstart'){
  last=Date.now();
  if(mode!='awake'){swallow=true;clearTimeout(swT);swT=setTimeout(()=>swallow=false,700);setMode('awake');if(hostPage())refresh()}
 }
 if(swallow){e.stopPropagation();e.preventDefault()}
};
for(const t of ['pointerdown','pointerup','pointercancel','touchstart','touchend','touchmove','click','mousedown','mouseup','contextmenu'])
 addEventListener(t,guard,{capture:true,passive:false});
addEventListener('scroll',()=>{if(swallow)pager.scrollLeft=page*pager.clientWidth},true);
setInterval(()=>{if(vOpen)last=Date.now();const idle=Date.now()-last;
 if(idle>=T_AMB){if(mode!='ambient')setMode('ambient')}
 else if(idle>=T_DIM){if(mode!='dim')setMode('dim')}
},1000);
setInterval(()=>{if(mode=='ambient')drift()},DRIFT_MS);
setInterval(()=>{if(mode=='awake')shiftGrid()},SHIFT_MS);
// ---- boot ----
// (focus pill removed)
setHost(host);clock();wx();wake();loadKeys();
// Old tab names move to the group that holds them. A hash like #fleet/crons wins over the saved page. #t= is the burn-in timer, not a page.
const PAGE_OLD={house:'home',invest:'markets',keys:'pad',cluster:'fleet',dev:'fleet',crons:'fleet',schedules:'fleet',launch:'fleet',agents:'fleet'};
const SUB_OLD={keys:'keys',cluster:'cluster',dev:'dev',crons:'crons',schedules:'schedules',launch:'launch',agents:'agents',fleet:'fleet',pad:'pad'};
function savedSpot(){let raw='';const h=String(HASH||'').replace(/^#/,'');if(h&&!/^t=/.test(h))raw=decodeURIComponent(h.split('&')[0]);if(!raw)raw=localStorage.getItem('page')||'';
 const bits=raw.split('/'),a=bits[0]||'',b=bits[1]||'';const name=PAGE_OLD[a]||a;const sub=b||(PAGE_OLD[a]?SUB_OLD[a]:'')||localStorage.getItem('sub:'+name)||'';return {name,sub}}
function showSub(name,sub,save){const pageEl=document.querySelector('#pager>.page[data-name="'+name+'"]');if(!pageEl)return;
 const panels=[...pageEl.querySelectorAll(':scope>.sub')];if(!panels.length)return;
 if(!panels.some(p=>p.dataset.sub===sub))sub=panels[0].dataset.sub;
 panels.forEach(p=>{const on=p.dataset.sub===sub;p.hidden=!on;p.classList.toggle('on',on)});
 pageEl.querySelectorAll('.subrow [data-sub]').forEach(b=>{const on=b.dataset.sub===sub;b.classList.toggle('on',on);b.setAttribute('aria-selected',on?'true':'false')});
 if(save){localStorage.setItem('page',name);localStorage.setItem('sub:'+name,sub)}}
document.addEventListener('click',e=>{const b=e.target.closest&&e.target.closest('.subrow [data-sub]');if(!b)return;const pageEl=b.closest('.page');if(!pageEl)return;showSub(pageEl.dataset.name,b.dataset.sub,true);pageVisible()});
const kbt=$('#kbtoggle');if(kbt)kbt.addEventListener('click',()=>{const pad=$('#padpg');if(!pad)return;const open=pad.classList.toggle('kb-open');kbt.setAttribute('aria-expanded',open?'true':'false')});
// Reopen on the page used last (by name, so adding pages never shifts it). Instant, no animation.
{const spot=savedSpot();if(spot.sub)showSub(spot.name,spot.sub,true);const want=PAGES.findIndex(p=>p.dataset.name===spot.name);page=want>0?want:0;if(spot.name)localStorage.setItem('page',PAGES[page]?PAGES[page].dataset.name:spot.name);showTab(page,true);
 // the saved page is in place before the first paint: no flash of Today, no animation
 if(page){pager.scrollLeft=page*pager.clientWidth;requestAnimationFrame(()=>{goPage(page,true);pageVisible()})}else pageVisible();
 // each page comes back to where it was read before a reload, once its content is tall enough
 requestAnimationFrame(()=>PAGES.forEach(restoreScroll))}
addEventListener('keydown',()=>{last=Date.now()},{capture:true});
// Poll only while the deck is visible and awake, one call in flight per poller (Dell calls ride ssh).
const gated=(fn)=>{let busy=false;return async()=>{if(busy||document.hidden||mode=='ambient')return;busy=true;try{await fn()}finally{busy=false}}};
setInterval(clock,10000);setInterval(gated(()=>hostPage()?refresh():null),3000);setInterval(gated(()=>pname()==='home'?stats():null),5000);setInterval(wx,600000);
setInterval(()=>{if(document.hidden||mode=='ambient')return;const n=pname(),leaf=leafOf(n);if(n==='today'){today();traffic()}if(n==='home'){ha();cams()}if(leaf==='fleet')fleet();if(typeof deckPage=='function')deckPage(leaf,true)},15000);
// Every open tab also refreshes on its own at least once an hour, and again when the deck comes back on screen.
setInterval(()=>{if(document.hidden||mode=='ambient')return;pageVisible()},3600000);
