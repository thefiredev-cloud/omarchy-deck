// Pixel Deck Invest tab: markets, portfolio and catalysts. Loaded after app.js and deck.js.
// Feeds: GET /api/markets (public quotes, movers, catalysts), GET /api/portfolio (symbols, prices and day percent only),
// GET /api/portfolio-values (quantities, values, dollar changes, cash: requested only when the owner taps Reveal).
// Every number shows its age. Unknown is an em dash, never 0. Direction is shown by an arrow and a sign, never by colour.
// Wording and the empty state come from deck.js (DeckUI.down, DeckUI.empty); this block takes DeckUI as a free variable.
// ==== DECK INVEST UI BEGIN (pure: no DOM, no fetch, no globals; tests/deck_invest.test.js loads this block) ====
const DeckInvest=(()=>{
 const esc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const isObj=x=>x!==null&&typeof x==='object'&&!Array.isArray(x);
 const arr=x=>Array.isArray(x)?x:[];
 const num=v=>typeof v==='number'&&isFinite(v)?v:null;
 const str=(v,n)=>typeof v==='string'?v.trim().slice(0,n||120):'';
 const DASH='\u2014',HIDE_MS=30000;
 const MON=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'],DOW=['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
 const SD=k=>'<i class="sd '+k+'"></i>';
 const toEpoch=v=>{if(num(v)!=null)return v>1e12?v/1000:v;if(typeof v==='string'&&v){const p=Date.parse(v);return isFinite(p)?p/1000:null}return null};
 function ago(t,now){const x=toEpoch(t);if(x==null)return 'time unknown';const s=Math.max(0,Math.round(now/1000-x));
  return s<45?'just now':s<5400?Math.max(1,Math.round(s/60))+' min ago':s<172800?Math.round(s/3600)+' h ago':Math.round(s/86400)+' d ago'}
const safeUrl=u=>typeof u==='string'&&/^https?:\/\/[^\s"'<>\\@]+$/i.test(u)?u:'';
 const groupSep=s=>s.replace(/\B(?=(\d{3})+(?!\d))/g,',');
 // price text by instrument group: yields in percent, FX and rates keep their usual decimals, big prices drop cents
 function px(v,group,id){const n=num(v);if(n==null)return DASH;
  if(group==='rates')return n.toFixed(3)+'%';
  if(group==='fx')return n.toFixed(id==='usdjpy'||id==='dxy'?2:4);
  if(n>=10000)return groupSep(String(Math.round(n)));
  if(n>=1000)return groupSep(n.toFixed(group==='crypto'?0:2));
  if(group==='crypto'&&n<10)return n.toFixed(4);
  return n.toFixed(2)}
 const usd=(v,d)=>{const n=num(v);if(n==null)return DASH;const a=Math.abs(n),s=groupSep(a.toFixed(d==null?0:d));return (n<0?'\u2212$':'$')+s};
 const sgnUsd=v=>{const n=num(v);if(n==null)return DASH;return (n>0?'+':n<0?'\u2212':'')+'$'+groupSep(Math.abs(n).toFixed(0))};
 const dir=v=>num(v)==null?'na':v>0?'up':v<0?'dn':'fl';
 const pct=v=>{const n=num(v);if(n==null)return DASH;return (n>0?'\u25B2 +':n<0?'\u25BC \u2212':'\u25A0 ')+Math.abs(n).toFixed(2)+'%'};
 const feedStale=f=>isObj(f)&&!f.error&&f.stale===true;
// ONE timestamp per feed: generated_at (FEEDS.md, 2026-10-21), else t. as_of says when the data was true: it is named in the same line only when clearly older than the
// file (a closed market keeps its last quote time), never as a second "Updated". An object as_of is read at `key`; the portfolio's own sentence is as_of_note.
const genAt=f=>{const g=toEpoch(f.generated_at);return g!=null?g:toEpoch(f.t)};
const asOfAt=(f,key)=>{const a=f.as_of;return toEpoch(isObj(a)?(key?a[key]:null):a)};
const fresh=(f,now,key)=>{const g=genAt(f),o=asOfAt(f,key),r=num(f.refresh)>0?f.refresh:300,lag=g!=null&&o!=null&&g-o>Math.max(900,3*r)?' \u00B7 data from '+ago(o,now):'';
 return (feedStale(f)?'Out of date \u00B7 ':'')+(g==null?'Update time unknown':'Updated '+ago(g,now))+lag};
const head=(title,f,now,key)=>'<div class="secttl"><span>'+esc(title)+'</span><span>'+esc(isObj(f)&&!f.error?fresh(f,now,key):'Not reporting')+'</span></div>';
const asOfNote=f=>isObj(f)&&typeof f.as_of_note==='string'&&str(f.as_of_note,220)?'<div class="tnote asof">'+esc(str(f.as_of_note,220))+'</div>':'';
 const tile=(h,v,t,k,extra)=>'<div class="tile'+(k==='bad'?' bad':k==='stale'?' stale':'')+(extra?' '+extra:'')+'"><div class="h">'+(k?SD(k==='stale'?'warn':k):'')+esc(h)+'</div><div class="v">'+esc(v)+'</div>'+(t!=null?'<div class="t">'+esc(t)+'</div>':'')+'</div>';
 const down=(title,f)=>DeckUI.down(title,f,'invest');
 // failed parts collapse into one line; the sources and reasons stay in the hidden details
const errRows=f=>{const es=arr(isObj(f)&&f.errors).filter(isObj);if(!es.length)return '';const names=DeckUI.errNames(es);
  return '<div class="frow err"><span>'+(es.length===1?'One source is not reporting.':es.length+' sources are not reporting.')+'</span>'+(names?'<span class="errn">'+DeckUI.esc(names)+'</span>':'')+
   DeckUI.diagHtml(es.slice(0,8).map(e=>(str(e.source,40)||'source')+': '+(str(e.reason,120)||'no reason given')))+'</div>'};
 // one quote row: label and sub on the left, price over a signed percent on the right
 function qrow(label,sub,price,change,url,mark,ptxt){const u=safeUrl(url),tag=u?'a':'div';
  return '<'+tag+' class="frow ivq"'+(u?' href="'+esc(u)+'" target="_blank" rel="noopener noreferrer"':'')+'><span class="fl"><b>'+esc(label)+(mark?' <span class="pill">'+esc(mark)+'</span>':'')+'</b>'+(sub?'<small>'+esc(sub)+'</small>':'')+'</span>'+
   '<span class="fr"><b>'+esc(price)+'</b><small class="iv-'+dir(change)+'">'+esc(ptxt||pct(change))+'</small></span></'+tag+'>'}
 // a yield moves in basis points, not in percent of its level
 const bp=v=>{const n=num(v);if(n==null)return DASH;const x=Math.round(n*1000)/10;return (x>0?'\u25B2 +':x<0?'\u25BC \u2212':'\u25A0 ')+Math.abs(x).toFixed(1)+' bp'}
const SRC=[[/federalreserve|^Federal Reserve$/i,'Fed'],[/bls\.gov/i,'BLS'],[/bea\.gov/i,'BEA'],[/nasdaq/i,'Nasdaq'],[/DOL/,'DOL'],[/ISM/,'ISM'],[/treasurydirect/i,'Treasury'],[/sec\.gov|^SEC$/i,'SEC'],[/yahoo/i,'Yahoo'],[/cnbc/i,'CNBC'],[/marketwatch/i,'MarketWatch'],[/^EIA/,'EIA'],[/^CBOE/i,'Cboe']];
const shortSrc=t=>{const x=str(t,80);const h=SRC.find(r=>r[0].test(x));return h?h[1]:x.slice(0,16)};
 const GROUPS=[['us','US stocks'],['futures','Futures'],['vol','Volatility'],['rates','Rates'],['fx','Dollar and FX'],['commodity','Oil and gold'],['crypto','Crypto, 24h']];
 const SESSION={open:'US market open',pre:'Pre-market',after:'After hours',closed:'US market closed'};
 function etToday(now){try{return new Date(now).toLocaleDateString('en-CA',{timeZone:'America/New_York'})}catch(e){return new Date(now).toISOString().slice(0,10)}}
 function dayLabel(iso,now){const m=/^(\d{4})-(\d{2})-(\d{2})$/.exec(iso||'');if(!m)return DASH;
  const d=new Date(Date.UTC(+m[1],+m[2]-1,+m[3])),t=etToday(now).split('-').map(Number),
   diff=Math.round((d-Date.UTC(t[0],t[1]-1,t[2]))/864e5),base=DOW[d.getUTCDay()]+' '+MON[d.getUTCMonth()]+' '+d.getUTCDate();
  return diff===0?'Today':diff===1?'Tomorrow, '+base:base}
 function clockET(hhmm){const m=/^(\d{2}):(\d{2})$/.exec(hhmm||'');if(!m)return '';const h=+m[1];return ((h+11)%12+1)+':'+m[2]+' '+(h<12?'AM':'PM')+' ET'}

 // ---- column 1: market board ----
 function board(f,now){
  if(!isObj(f)||f.error)return head('Markets',f,now)+down('Markets',f);
  const k=feedStale(f)?'stale':'ok',s=isObj(f.session)?f.session:{},b=arr(f.board).filter(isObj);
  const state=SESSION[s.state]||'Session unknown',by=Object.create(null);for(const r of b)by[r.id]=r;
  const lead=['spy','qqq'].filter(i=>by[i]&&num(by[i].pct)!=null).map(i=>(i==='spy'?'S&P 500 ':'Nasdaq 100 ')+pct(by[i].pct)).join('  \u00B7  ');
  const t2=(s.state==='closed'&&s.last_close?'last close '+dayLabel(s.last_close,now)+' \u00B7 ':'')+'public quotes, about 15 min delayed';
  let h=head('Markets',f,now,'quotes')+tile(state,lead||str(f.headline,120)||'No quotes',t2,k,'ivn');
  for(const [g,label] of GROUPS){const rows=b.filter(r=>r.group===g);if(!rows.length)continue;
   h+='<div class="secttl"><span>'+esc(label)+'</span></div><div class="flist">'+rows.map(r=>qrow(str(r.label,24)||str(r.symbol,12),str(r.symbol,12)+(r.price==null?' \u00B7 no quote':' \u00B7 '+ago(r.t,now)),px(r.price,r.group,r.id),r.group==='rates'?r.chg:r.pct,'','',r.group==='rates'?bp(r.chg):null)).join('')+'</div>'}
  return h+errRows(f)}

 // ---- column 2: portfolio ----
 // rev = ctl.view() or null. Amounts are drawn only from rev.vals (the values view); the public feed never carries one.
 function portfolio(p,m,rev,now){
  if(!isObj(p)||p.error)return head('Portfolio',p,now)+down('Portfolio',p);
  const k=feedStale(p)?'stale':'ok',t=isObj(p.totals)?p.totals:{},bs=isObj(p.basis)?p.basis:{},ps=arr(p.positions).filter(isObj);
  const vals=rev&&isObj(rev.vals)?rev.vals:null,vt=vals&&isObj(vals.totals)?vals.totals:null;
  const vmap=Object.create(null);if(vals)for(const v of arr(vals.positions)){if(isObj(v)&&typeof v.symbol==='string')vmap[v.symbol]=v}
  const eqAge=num(bs.equity_qty_age_days);
  const note=(eqAge==null?'equity quantities: age unknown':'equity quantities '+eqAge+' day'+(eqAge===1?'':'s')+' old (owner screenshot)')+' \u00B7 crypto '+(bs.crypto_live===true?'live balance':'balance not live');
  let h=head('Portfolio',p,now)+asOfNote(p)+tile('Day change',pct(t.day_pct),note+' \u00B7 '+num(t.priced)+' of '+num(t.positions)+' priced',k,'big ivn iv-t-'+dir(t.day_pct));
  if(t.margin_in_use===true)h+=tile('Margin','In use','broker cash was negative in the last snapshot','stale','ivn');
  // controls
  h+='<div class="fctl">'+(vals?'<button class="b fh" data-act="hide">Hide amounts</button><span class="fcd" data-exp="'+esc(rev.exp)+'">'+esc(fcd(rev.exp,now))+'</span>'
   :'<button class="b fr" data-act="reveal"'+(rev&&rev.busy?' disabled':'')+'>'+(rev&&rev.busy?'Loading':'Show amounts')+'</button>')+'</div>';
  if(rev&&rev.err)h+='<div class="frow err">'+SD('bad')+'<span>'+esc(rev.err)+'</span></div>';
  if(vt){
   h+=tile('Day change, dollars',sgnUsd(vt.day_chg_usd),'positions '+usd(vt.positions_usd)+' \u00B7 equity '+usd(vt.equity_usd)+' \u00B7 crypto '+usd(vt.crypto_usd),k);
   if(num(vt.margin_cash_usd)!=null)h+=tile('Cash and margin',usd(vt.margin_cash_usd),'excess liquidity '+usd(vt.excess_liquidity_usd)+' \u00B7 from the snapshot, '+(eqAge==null?'age unknown':eqAge+' day'+(eqAge===1?'':'s')+' old')+(num(vt.net_est_usd)!=null?' \u00B7 net estimate '+usd(vt.net_est_usd):''),'stale')}
  h+='<div class="secttl"><span>Positions</span><span>'+(vals?'amounts shown':'percent only')+'</span></div><div class="flist">'+
   (ps.length?ps.map(x=>{const v=vmap[x.symbol],sub=(str(x.name,28)||x.kind)+(v&&num(v.qty)!=null?' \u00B7 '+fmtQty(v.qty)+' \u00D7 '+px(x.price,x.kind==='crypto'?'crypto':'')+(num(v.value)!=null?' = '+usd(v.value):''):'');
     return qrow(str(x.symbol,12),sub,px(x.price,x.kind==='crypto'?'crypto':''),x.pct,'',x.kind==='crypto'?'24h':'')+
      (v&&num(v.day_chg)!=null?'<div class="frow ivd"><span class="fl"><small>day, dollars</small></span><span class="fr"><small class="iv-'+dir(v.day_chg)+'">'+esc(sgnUsd(v.day_chg))+'</small></span></div>':'')}).join(''):'<div class="frow"><span class="fl"><small>No positions in the snapshot</small></span></div>')+'</div>';
  return h+errRows(p)}
 const fmtQty=q=>{const n=num(q);if(n==null)return DASH;return n>=100?groupSep(String(Math.round(n))):String(+n.toFixed(4))};
 const fcd=(exp,now)=>{const s=Math.max(0,Math.round((exp-now)/1000));return 'hides in '+s+' s'};

 // ---- column 3: catalysts (upcoming), filings and news (recent), movers, watchlist ----
 // upcoming events open at UP_SHORT rows and recent items at RC_SHORT; Show more adds UP_STEP or RC_STEP, Show fewer goes back. view = {up, rc} row counts.
 const UP_SHORT=12,UP_STEP=12,RC_SHORT=8,RC_STEP=12,SHORT={up:UP_SHORT,rc:RC_SHORT},STEP={up:UP_STEP,rc:RC_STEP};
 const isRecent=c=>c.kind==='filing'||c.kind==='news';
 const moreRows=(k,shown,total,view)=>{const step=STEP[k],left=total-shown;
  return (left>0?'<button type="button" class="b more" data-ivmore="'+k+'">Show '+Math.min(step,left)+' more</button>':'')+(shown>SHORT[k]?'<button type="button" class="b more" data-less="1" data-ivmore="'+k+'">Show fewer</button>':'')};
 const shownCount=(k,view,total)=>Math.min(total,Math.max(SHORT[k],num(view&&view[k])==null?SHORT[k]:Math.round(view[k])));
 function crow(c,now,titleMax){
  const when=[dayLabel(c.date,now),c.time_et?clockET(c.time_et):(c.when||'')].filter(Boolean).join(' \u00B7 '),imp=c.impact==='H'?'High':c.impact==='M'?'Medium':'Low';
  const u=safeUrl(c.url),tag=u?'a':'div';
  return '<'+tag+' class="frow"'+(u?' href="'+esc(u)+'" target="_blank" rel="noopener noreferrer"':'')+'><span class="fl"><b>'+esc(str(c.title,titleMax))+(c.watch&&!isRecent(c)?' <span class="pill">held or watched</span>':'')+'</b><small>'+esc(when)+(c.detail?' \u00B7 '+esc(str(c.detail,34)):'')+(c.eps_est?' \u00B7 EPS est '+esc(str(c.eps_est,12)):'')+' \u00B7 '+esc(shortSrc(c.source))+'</small></span><span class="fr"><span class="pill'+(c.impact==='H'?' warn':'')+'">'+imp+'</span></span></'+tag+'>'}
 function catalysts(f,now,view){
  if(!isObj(f)||f.error)return head('Catalysts',f,now)+down('Catalysts',f);
  const today=etToday(now),all=arr(f.catalysts).filter(isObj),up=all.filter(c=>!isRecent(c)&&str(c.date,10)>=today),rc=all.filter(c=>isRecent(c)&&str(c.date,10)!==''),
   nu=shownCount('up',view,up.length),nr=shownCount('rc',view,rc.length);
  let h=head('Catalysts',f,now)+(up.length?'<div class="flist">'+up.slice(0,nu).map(c=>crow(c,now,60)).join('')+'</div>'+moreRows('up',nu,up.length,view)
   :tile('Catalysts','None listed','no upcoming events from the calendar sources',k2(f)));
  if(rc.length)h+='<div class="secttl"><span>Filings and news</span><span>newest first</span></div><div class="flist">'+rc.slice(0,nr).map(c=>crow(c,now,110)).join('')+'</div>'+moreRows('rc',nr,rc.length,view);
  const mv=isObj(f.movers)?f.movers:{};
  const list=(title,rows)=>{const r=arr(rows).filter(isObj).slice(0,4);return '<div class="secttl"><span>'+esc(title)+'</span></div>'+(r.length?'<div class="flist">'+r.map(x=>qrow(str(x.symbol,8),str(x.name,30),px(x.price,''),x.pct,'')).join('')+'</div>':'<div class="frow err"><span>none reported</span></div>')};
  h+=list('Gainers',mv.gainers)+list('Losers',mv.losers)+'<div class="secttl"><span>Movers basis</span><span>'+esc(str(mv.basis,80))+'</span></div>';
  const w=arr(f.watchlist).filter(isObj);
  h+='<div class="secttl"><span>Watchlist</span></div><div class="flist">'+(w.length?w.map(x=>qrow(str(x.symbol,10),(str(x.name,26)||'')+(x.next_earnings?' \u00B7 reports '+dayLabel(x.next_earnings,now):''),px(x.price,''),x.pct,'',x.held?'held':'')).join(''):'<div class="frow"><span class="fl"><small>Empty</small></span></div>')+'</div>';
  return h}
 const k2=f=>feedStale(f)?'stale':'ok';

 // ---- Reveal controller: the one place that holds amounts. 30 s, then they are dropped. ----
 function ctl(env,ms){
  const LIFE=ms||HIDE_MS;let vals=null,exp=0,timer=null,gen=0,err='',busy=false;
  const drop=()=>{vals=null;exp=0;if(timer){env.clearT(timer);timer=null}};
  function hide(){gen++;const was=vals!==null||busy||err!=='';drop();busy=false;err='';if(was)env.onChange()}
  function sweep(){if(vals!==null&&env.now()>=exp){hide();return true}return false}
  async function reveal(){if(busy)return;busy=true;err='';const g=gen;env.onChange();
   let r=null;try{r=await env.get('/api/portfolio-values')}catch(e){r=null}
   if(g!==gen)return; // hidden while the request was in flight: the answer is dropped unread
   busy=false;
   if(!isObj(r)||r.error){err=isObj(r)&&r.error?'amounts unavailable: '+str(r.error,40):'deck server did not answer';env.onChange();return}
   vals={totals:isObj(r.totals)?r.totals:null,positions:arr(r.positions)};exp=env.now()+LIFE;
   timer=env.setT(()=>{hide()},LIFE);env.onChange()}
  return {reveal,hide,sweep,view:()=>({vals,exp,err,busy})}}

 // ---- loading and slow states: the Markets page is never a blank panel ----
 // A skeleton shows the moment the page opens and says so when the answer is slow. Nothing is written to device storage here (see the wiring test):
 // the last good markets feed stays in memory, so a later visit or a failed refresh still shows it, marked out of date.
 const SLOW_MS=8000,ABORT_MS=60000;
 const skRows=n=>Array.from({length:n},(_,i)=>'<div class="frow ivsk" aria-hidden="true"><span class="fl"><b class="sk s'+(i%4)+'"></b><small class="sk t'+(i%3)+'"></small></span><span class="fr"><b class="sk p"></b></span></div>').join('');
 const skel=(title,slow,n)=>'<div class="ivskel" role="status" aria-busy="true" data-skel="1"><div class="secttl"><span>'+esc(title)+'</span><span>'+(slow?'Still loading':'Loading')+'</span></div><div class="flist">'+skRows(n||6)+'</div>'+
  (slow?'<div class="tnote">Taking longer than usual. It keeps trying and fills in when the server answers.</div>':'')+'</div>';
 const headSkel=slow=>skel('Market news',slow,3);
 const headDown=()=>'<div class="secttl"><span>Market news</span><span>Not reporting</span></div>'+DeckUI.empty({k:'bad',title:'Market news is not reporting',line:'The deck server did not answer in time. Try again.',retry:'page'});

 // [markets, portfolio, catalysts] column html. st = {m, p} each 'loading' | 'slow' | 'done': a column whose feed has not answered yet shows a skeleton
 // (never blank); a feed that answered with nothing shows its own "not reporting" state. No st means everything has answered.
 function page(m,p,rev,now,view,st){
  const part=(fn,t)=>{try{return fn()}catch(e){return DeckUI.empty({k:'bad',title:'Could not show '+t,line:'Try again. If it keeps happening, reload the deck.',retry:'invest'})}};
  const waiting=(k,f)=>!f&&st&&st[k]&&st[k]!=='done'?st[k]:'';
  const col=(k,f,title,fn)=>waiting(k,f)?skel(title,waiting(k,f)==='slow'):part(fn,title);
  return [col('m',m,'Markets',()=>board(m,now)),col('p',p,'Portfolio',()=>portfolio(p,m,rev,now)),col('m',m,'Catalysts',()=>catalysts(m,now,view))]}
 return {esc,px,pct,bp,usd,sgnUsd,dir,ago,dayLabel,clockET,etToday,board,portfolio,catalysts,page,ctl,fcd,HIDE_MS,safeUrl,SHORT,STEP,skel,headSkel,headDown,SLOW_MS,ABORT_MS}
})();
// ==== DECK INVEST UI END ====
// ---- glue (DOM + fetch). Skipped where there is no document (node tests). ----
if(typeof document!=='undefined'&&document.getElementById('invest')){
 const IV={m:null,p:null,t:0,busy:false,st:{m:'loading',p:'loading'},view:{up:DeckInvest.SHORT.up,rc:DeckInvest.SHORT.rc}};
 // a request that never answers must not hold the page blank (or the busy flag) forever: it is cut off after ABORT_MS and reads as "not reporting"
 const ivGet=p=>{const c=typeof AbortController==='function'?new AbortController():null,t=c?setTimeout(()=>c.abort(),DeckInvest.ABORT_MS):0;
  return fetch(p,{cache:'no-store',credentials:'same-origin',signal:c?c.signal:undefined}).then(r=>r.ok?r.json():{error:'http '+r.status}).catch(()=>null).finally(()=>clearTimeout(t))};
 const ICTL=DeckInvest.ctl({get:ivGet,setT:(fn,ms)=>setTimeout(fn,ms),clearT:t=>clearTimeout(t),now:()=>Date.now(),onChange:()=>ivPaint()});
 function ivPaint(){const cols=DeckInvest.page(IV.m,IV.p,ICTL.view(),Date.now(),IV.view,IV.st);['iv1','iv2','iv3'].forEach((id,i)=>{const el=document.getElementById(id);if(el)el.innerHTML=cols[i]})}
 { const css=document.createElement('style');css.id='iv-skel-css';
  css.textContent='.ivsk .sk{display:block;height:.9em;border-radius:6px;background:linear-gradient(90deg,var(--line) 25%,color-mix(in srgb,var(--line) 55%,var(--text-3)) 50%,var(--line) 75%);background-size:200% 100%;animation:ivshine 1.4s linear infinite}'+
   '.ivsk .sk.t0,.ivsk .sk.t1,.ivsk .sk.t2{height:.7em;margin-top:var(--sp-1)}.ivsk .s0{width:62%}.ivsk .s1{width:78%}.ivsk .s2{width:54%}.ivsk .s3{width:70%}.ivsk .t0{width:34%}.ivsk .t1{width:44%}.ivsk .t2{width:28%}.ivsk .p{width:3.4em}'+
   '@keyframes ivshine{to{background-position:-200% 0}}@media (prefers-reduced-motion:reduce){.ivsk .sk{animation:none}}';
  document.head.appendChild(css)}
 window.v10Invest=()=>investPage(false);
 // the Market news strip (#mhead) is painted by deck.js; it is empty until its feed answers, so show a skeleton (and a timeout message) until then
 let headSlow=0,headDead=0;
 function ivHead(){const el=document.getElementById('mhead');if(!el||el.innerHTML.trim()!=='')return;
  el.innerHTML=DeckInvest.headSkel(false);clearTimeout(headSlow);clearTimeout(headDead);
  headSlow=setTimeout(()=>{if(el.querySelector('[data-skel]'))el.innerHTML=DeckInvest.headSkel(true)},DeckInvest.SLOW_MS);
  headDead=setTimeout(()=>{if(el.querySelector('[data-skel]'))el.innerHTML=DeckInvest.headDown()},DeckInvest.ABORT_MS+2000)}
async function investPage(tick){if(IV.busy||(tick&&Date.now()-IV.t<60000))return;IV.busy=true;IV.t=Date.now();
  if(IV.m===null)IV.st.m='loading';
  if(IV.p===null)IV.st.p='loading';
  ivPaint();
  const slow=setTimeout(()=>{if(IV.st.m==='loading')IV.st.m='slow';if(IV.st.p==='loading')IV.st.p='slow';ivPaint()},DeckInvest.SLOW_MS);
  try{await Promise.all([
   ivGet('/api/markets').then(m=>{IV.m=m&&!m.error?m:IV.m&&!IV.m.error?Object.assign({},IV.m,{stale:true}):m;IV.st.m='done';ivPaint()}),
   ivGet('/api/portfolio').then(p=>{IV.p=p;IV.st.p='done';ivPaint()})])}
  finally{clearTimeout(slow);IV.busy=false}}
 document.getElementById('invest').addEventListener('click',e=>{const mb=e.target.closest('button[data-ivmore]');
  if(mb){const k=mb.dataset.ivmore;IV.view[k]=mb.dataset.less?DeckInvest.SHORT[k]:IV.view[k]+DeckInvest.STEP[k];ivPaint();return}
  const b=e.target.closest('button.fr,button.fh');if(!b||b.disabled)return;
  if(b.dataset.act==='hide')ICTL.hide();else ICTL.reveal()});
 const prev=deckPage;
deckPage=function(name,tick){const on=name==='invest'||name==='markets';if(!on)ICTL.hide();prev(name,tick);if(on){ivHead();investPage(tick)}};
 document.addEventListener('visibilitychange',()=>{if(document.hidden)ICTL.hide()});
 addEventListener('pagehide',()=>ICTL.hide());
 // one-second tick: expire a reveal even if a timer was throttled, hide in ambient mode, keep the countdown honest without repainting
 setInterval(()=>{const v=ICTL.view();if(v.vals===null)return;
  if(typeof mode!=='undefined'&&mode==='ambient'){ICTL.hide();return}
  if(ICTL.sweep())return;
  const now=Date.now();document.querySelectorAll('#invest .fcd[data-exp]').forEach(el=>{el.textContent=DeckInvest.fcd(+el.dataset.exp,now)})},1000);
 if(!document.hidden&&typeof pname==='function'&&(pname()==='invest'||pname()==='markets')){ivHead();investPage(false)}
}
