// All crons page: every scheduled job Tanner owns (GET /api/schedules, read only, written by deck-feed-crons).
// Loaded after deck.js; uses DeckUI (esc, ago, until, toEpoch, line, state) and the page glue (once, feedGet, renderFail, $).
// Hermes jobs, systemd user timers (hosts that answered), Mac mini launchd and GitHub Actions schedules in one list.
// Default view = active work (enabled, running or failing); History = paused, finished and retired rows, kept and never counted as active.
// ==== SCHEDULES UI HELPERS BEGIN (pure: no DOM, no fetch; tests/deck_schedules_ui.test.js loads this block with DeckUI injected) ====
const SchedUI=(()=>{
const {esc,ago,until,toEpoch,line,state,down,diagHtml,schedule,redact,fixRow}=DeckUI;
 const isObj=x=>x!==null&&typeof x==='object'&&!Array.isArray(x);
 const arr=x=>Array.isArray(x)?x:[];
 const num=v=>typeof v==='number'&&isFinite(v)?v:null;
 const str=(v,n)=>typeof v==='string'?v.trim().slice(0,n||120):'';
 const RESULTS=['ok','failed','running','never','paused','skipped','overdue','unknown'];
 const MSTATUS=['ok','failed','skipped','running','unknown','pending'];
 const LABEL={ok:'OK',failed:'Failed',running:'Running',never:'Never ran',paused:'Paused',skipped:'Skipped',overdue:'Overdue',unknown:'Unknown'};
 const memBad=j=>arr(j.members).some(m=>m.status==='failed');
 const isBad=j=>j.result==='failed'||j.result==='overdue'||memBad(j);
 const isActive=j=>j.enabled||j.result==='running'||isBad(j);
 const clock=t=>{const x=toEpoch(t);if(x==null)return '';const d=new Date(x*1000);return d.toLocaleDateString([],{weekday:'short'})+' '+d.toLocaleTimeString([],{hour:'numeric',minute:'2-digit'})};
 // a job from the feed, with every field forced to a known type; the result word is trusted only from the fixed list
 function norm(j,g){
  const r=str(j&&j.result,12);
  return {name:str(j&&j.name,90)||'unnamed',host:str(j&&j.host,20)||str(g&&g.host,20)||'host?',kind:str(j&&j.kind,12),schedule:str(j&&j.schedule,90),
   enabled:!!(j&&j.enabled),lifecycle:str(j&&j.lifecycle,12),last:toEpoch(j&&j.last),started:toEpoch(j&&j.started),triggered:toEpoch(j&&j.triggered),next:toEpoch(j&&j.next),approx:!!(j&&j.approx_next),
   result:RESULTS.includes(r)?r:'unknown',detail:str(j&&j.detail,120),about:str(j&&j.about,90),gid:str(g&&g.id,40),glabel:str(g&&g.label,40),
   members:arr(j&&j.members).filter(isObj).slice(0,120).map(m=>({name:str(m.name,60)||'member',status:MSTATUS.includes(str(m.status,12))?str(m.status,12):'unknown',
    started:toEpoch(m.started),finished:toEpoch(m.finished),due:toEpoch(m.due),deferred:toEpoch(m.deferred_since),overdue:m.overdue===true,overrun:m.overrun===true,exit:typeof m.exit==='number'&&isFinite(m.exit)?m.exit:null}))}}
 // rows merged away by consolidation: kept as history, never counted as active
 function retiredOf(f){const out=[];groups(f).forEach(g=>arr(g.retired).filter(isObj).forEach(r=>out.push({name:str(r.name,90)||'unnamed',host:str(r.host,20)||str(g.host,20),kind:'retired',schedule:'',
  enabled:false,lifecycle:'retired',last:null,started:null,next:null,approx:false,result:'paused',detail:(str(r.outcome,90)||'merged into '+(str(r.merged_into,60)||'another job'))+(toEpoch(r.at)!=null?' \u00B7 '+clock(toEpoch(r.at)):''),
  about:'',gid:str(g.id,40),glabel:str(g.label,40),members:[]})));return out}
 function groups(f){return isObj(f)?arr(f.groups).filter(isObj):[]}
 function flatten(f){const out=[];groups(f).forEach(g=>arr(g.jobs).filter(isObj).forEach(j=>out.push(norm(j,g))));return out}
 // needs a look first, then running, then the soonest next run, then never-run, then paused
 const rank=j=>isBad(j)?0:j.result==='running'?1:j.result==='paused'?4:j.next!=null?2:3;
 function sorted(list){return list.slice().sort((a,b)=>{const ra=rank(a),rb=rank(b);if(ra!==rb)return ra-rb;
  if(ra===0)return (b.last||0)-(a.last||0)||a.name.localeCompare(b.name);
  if(ra===2)return a.next-b.next||a.name.localeCompare(b.name);
  return a.name.localeCompare(b.name)})}
 function matches(j,q){q=str(q,60).toLowerCase();if(!q)return true;return (j.name+' '+j.host+' '+j.kind+' '+j.schedule+' '+j.detail+' '+j.about+' '+j.result+' '+arr(j.members).map(m=>m.name).join(' ')).toLowerCase().includes(q)}
 function pick(j,filter){if(filter==='problem')return isBad(j);if(filter==='running')return j.result==='running';
  if(filter==='history')return !isActive(j);if(filter==='all')return true;
  if(filter&&filter.indexOf('g:')===0)return j.gid===filter.slice(2)&&isActive(j);return isActive(j)}
 function lastText(j,now){
  if(j.result==='never')return 'never run';
  if(j.result==='running')return 'running now'+(j.started!=null?' \u00B7 started '+ago(j.started,now):' \u00B7 start time unknown');
  if(j.result==='paused'&&j.lifecycle==='retired')return 'retired'+(j.about?' \u00B7 '+j.about:j.detail?' \u00B7 '+j.detail:'')+(j.last!=null?' \u00B7 last run '+ago(j.last,now):'');
  if(j.result==='paused')return 'paused'+(j.detail?' \u00B7 '+j.detail:'')+(j.last!=null?' \u00B7 last run '+ago(j.last,now):'');
  const w=j.result==='ok'||j.result==='overdue'?'ok':j.result==='unknown'?'status unknown':j.result;
  return 'last '+w+(j.last!=null?' '+ago(j.last,now):' \u00B7 time unknown'+(j.triggered!=null?' \u00B7 timer fired '+ago(j.triggered,now):''))+(j.detail?' \u00B7 '+j.detail:'')}
 function nextText(j,now){
  if(!j.enabled||j.result==='paused')return '';
  if(j.next==null)return j.result==='running'?'':'next: not scheduled';
  const u=until(j.next,now);return (j.approx?'next ~':'next ')+u+(j.next-now/1000>72000?' ('+clock(j.next)+')':'')}
// failed, unknown and overdue members are shown under their batch; skipped and pending stay neutral
 const memAttn=m=>m.status==='failed'||m.status==='unknown'||m.overdue;
function memText(j){if(!j.members.length)return '';const bad=j.members.filter(m=>m.status==='failed').map(m=>m.name),unk=j.members.filter(m=>m.status==='unknown').length,od=j.members.filter(m=>m.overdue).length;
  return j.members.length+' members'+(bad.length?' \u00B7 '+bad.length+' failed: '+bad.slice(0,4).join(', ')+(bad.length>4?' +'+(bad.length-4):''):' \u00B7 none failed')+(unk?' \u00B7 '+unk+' unknown':'')+(od?' \u00B7 '+od+' overdue':'')}
function row(j,now,i){
  const bad=isBad(j),off=j.result==='paused'&&!bad;
  const sub=[j.host,j.kind,j.schedule].filter(Boolean).join(' \u00B7 ');
  const nx=nextText(j,now),mt=memText(j);
  const pill=j.lifecycle==='retired'?'Retired':j.lifecycle==='done'&&j.result!=='running'?'Finished':LABEL[j.result];
 return '<div'+(i==null?'':' data-sched="'+i+'" role="button" tabindex="0"')+' class="scrow'+(bad?' bad':'')+(off?' off':'')+'"><span class="fl"><b>'+(bad?'<i class="sd bad"></i>':'')+esc(j.name)+'</b><small>'+esc(sub)+'</small>'+
   '<small>'+esc(lastText(j,now)+(nx?' \u00B7 '+nx:''))+'</small>'+(mt?'<small>'+esc(mt)+'</small>':'')+'</span><span class="pill rs-'+j.result+(bad?' bad':'')+'">'+esc(pill)+'</span></div>'}
 function chips(f,list,active,retired){
  const mk=(k,label,n,down)=>'<button class="b scf'+(active===k?' on':'')+'" data-f="'+esc(k)+'">'+esc(label)+' '+(down?'!':n)+'</button>';
  const act=list.filter(isActive).length;
  const out=[mk('active','Active',act),mk('problem','Needs a look',list.filter(isBad).length),mk('running','Running',list.filter(j=>j.result==='running').length),
   mk('history','History',list.length-act+(retired||0)),mk('all','All (incl. archived)',list.length+(retired||0))];
  groups(f).forEach(g=>out.push(mk('g:'+str(g.id,40),str(g.label,40)||str(g.id,40)||'group',list.filter(j=>j.gid===str(g.id,40)&&isActive(j)).length,g.ok===false)));
  return out.join('')}
 function agoT(t,now){return num(t)==null?'time unknown':ago(t,now)}
 function summary(f,list,now){
  const act=list.filter(isActive),bad=list.filter(isBad).length,run=list.filter(j=>j.result==='running').length;
  const pseudo=retiredOf(f).length,hist=list.length-act.length+pseudo,ret=list.filter(j=>j.lifecycle==='retired').length+pseudo;
  const soon=act.filter(j=>j.enabled&&j.next!=null&&j.next>now/1000).map(j=>j.next).sort((x,y)=>x-y)[0];
  const nx=soon!=null?until(soon,now):null;
  const gs=groups(f),downs=gs.filter(g=>g.ok===false),oks=gs.filter(g=>g.ok!==false);
  const trunc=gs.filter(g=>num(g.n)!=null&&g.n>arr(g.jobs).length);
  const notes=[];gs.forEach(g=>arr(g.notes).forEach(x=>notes.push(str(g.label,40)+': '+str(x,120))));
  const unk=list.filter(j=>j.result==='running'&&j.started==null).length;
  const scope='Observed on: '+oks.map(g=>str(g.label,40)||str(g.id,40)).join(', ')+(downs.length?'. Not observed: '+downs.map(g=>str(g.label,40)||str(g.id,40)).join(', ')+'. This is not the full fleet.':'.');
  return '<div class="secttl"><span>All schedulers</span><span>Hermes, timers, launchd and GitHub</span></div><div class="secttl"><span>'+act.length+' active \u00B7 '+bad+' need a look \u00B7 '+run+' running'+(nx?' \u00B7 next '+esc(nx):'')+'</span><span>'+esc(line(f,now))+'</span></div>'+
   '<div class="tnote">'+esc(hist+' in history (paused, finished or retired)'+(ret?' \u00B7 '+ret+' retired by consolidation':'')+' \u00B7 not counted as active')+'</div>'+
   '<div class="tnote">'+esc(scope)+'</div>'+fixRow('crons',bad)+
   downs.map(g=>{const k=isObj(g.last_known)?g.last_known:null;
    return '<div class="frow err"><i class="sd bad"></i><span>'+esc(str(g.label,40)||str(g.id,40))+' could not be read. Unknown, not zero'+
     (k&&num(k.n)!=null?'; last seen '+k.n+' jobs ('+(num(k.active)!=null?k.active+' active, ':'')+agoT(k.t,now)+')':'; no earlier reading')+'.</span>'+diagHtml([str(g.error,120)||'source failed'])+'</div>'}).join('')+
   (unk?'<div class="tnote">'+unk+(unk===1?' running job has':' running jobs have')+' no start time, so no age is shown.</div>':'')+
   notes.map(x=>'<div class="tnote">'+esc(x)+'</div>').join('')+
   trunc.map(g=>'<div class="tnote">'+esc(str(g.label,40))+': showing '+arr(g.jobs).length+' of '+g.n+'</div>').join('')}
 function unavailable(f){return '<div class="secttl"><span>All schedulers</span><span>Not reporting</span></div>'+down('All crons',f,'schedules')}
// shown jobs for the filter and search, in row order; the same list the rows are drawn from
function shownOf(all,filter,q){return sorted(all.filter(j=>pick(j,filter)&&matches(j,q)))}
// the whole page: {chips, sum, list} as html strings
function view(f,now,filter,q){
  if(state(f)==='bad')return {chips:'',sum:'',list:unavailable(f),broken:true};
  const all=flatten(f),shown=shownOf(all,filter,q),ret=retiredOf(f),qq=str(q,60).toLowerCase();
  const rets=filter==='history'||filter==='all'?ret.filter(j=>matches(j,qq)):[];
  const rows=shown.map((j,i)=>row(j,now,i)).concat(rets.map(j=>row(j,now)));
  return {chips:chips(f,all,filter,ret.length),sum:summary(f,all,now),broken:false,
   list:rows.length?rows.join(''):'<div class="tnote">'+(all.length?'No job matches this filter':'The feed lists no jobs')+'</div>'}}
// detail sheet, read only: plain words first. Hermes jobs add their last output once it is read.
const isHermes=j=>!!j&&j.kind==='hermes';
const opensOn=k=>k==='Enter'||k===' '||k==='Spacebar';
function lastWords(j,now){if(j.result==='running')return 'Running now \u00B7 '+(j.started==null?'start time unknown':'started '+ago(j.started,now)+' \u00B7 '+clock(j.started));
 // paused is a schedule state, not an outcome: a paused row shows its last actual run time (and outcome when the feed knows it) or unknown
 if(j.result==='paused'){const o=(j.detail.match(/last (\w+)/)||[])[1];
  return 'Last run: '+(j.last==null?'time unknown':ago(j.last,now)+' \u00B7 '+clock(j.last))+(o&&o!=='unknown'?' \u00B7 outcome '+o:'')}
 if(j.last==null)return 'Last run: '+(j.result==='never'?'never ran':'time unknown'+(j.result==='unknown'?', completion not recorded':'')+(j.triggered!=null?' \u00B7 timer last fired '+ago(j.triggered,now):''));
 return 'Last run: '+LABEL[j.result]+' \u00B7 '+ago(j.last,now)+' \u00B7 '+clock(j.last)}
function nextWords(j,now){if(j.result==='paused'||!j.enabled)return 'Next run: none, paused';
 if(j.result==='running')return 'Next run: running now';
 if(j.next==null)return 'Next run: not scheduled';
 return 'Next run: '+(j.approx?'about ':'')+until(j.next,now)+' \u00B7 '+clock(j.next)}
// out: undefined while the output is read, null when none is asked for, else {lines,t} | {none} | {fail} | {note}
function outputPart(j,out,now){
 if(!isHermes(j))return ['Last output: only Hermes jobs keep output here.'];
 if(out===undefined)return ['Last output: reading\u2026'];
 if(!out)return ['Last output: not read.'];
 if(out.fail)return ['Last output: could not be read. Close and open the job to try again.'];
 if(out.note)return ['Last output: '+out.note];
 if(out.none||!arr(out.lines).length)return ['Last output: none yet. The job has not written a run.'];
 return ['Last output, '+(num(out.t)==null?'time unknown':ago(out.t,now))+':'].concat(arr(out.lines).map(String))}
function memberLines(j,now){if(!j.members.length)return [];
 const out=['Batch members ('+j.members.length+'):'],ms=j.members.slice().sort((a,b)=>(memAttn(b)?1:0)-(memAttn(a)?1:0));
 ms.slice(0,14).forEach(m=>out.push(m.name+': '+m.status+(m.overdue?' \u00B7 overdue'+(m.due!=null?', due '+ago(m.due,now):''):'')+(m.deferred!=null?' \u00B7 deferred since '+ago(m.deferred,now):'')+(m.overrun?' \u00B7 still running past its wait':'')+(m.exit!=null&&m.exit!==0?' \u00B7 exit '+m.exit:'')+(m.finished!=null?' \u00B7 ended '+ago(m.finished,now):m.started!=null?' \u00B7 started '+ago(m.started,now):'')));
 if(ms.length>14)out.push('+ '+(ms.length-14)+' more members');return out}
function sheet(j,now,feedT,out){
 const sw=j.schedule?schedule(j.schedule):'unknown';
 return {kind:'card',title:j.name,sub:'Scheduled job \u00B7 read only',
  lines:['Schedule: '+sw,lastWords(j,now),nextWords(j,now),
   'Source: '+j.host+' \u00B7 '+(j.glabel||j.kind)+(num(feedT)==null?'':' \u00B7 list checked '+ago(feedT,now))].concat(memberLines(j,now),outputPart(j,out,now)),
  log:['Host '+j.host,'Kind '+j.kind,'Enabled '+(j.enabled?'yes':'no'),'Schedule text '+(j.schedule||'unknown')].concat(j.detail?['Detail '+redact(j.detail)]:[]),
  logTitle:'Details',actions:[]}}
// GET /api/crons: the 8-char ids of Hermes jobs with exactly this name (active or paused)
function cronIds(list,name){const L=isObj(list)?arr(list.active).concat(arr(list.paused)).filter(isObj):[];
 return L.filter(x=>str(x.name,80)===str(name,80)).map(x=>str(x.id,8)).filter(id=>/^[0-9a-f]{8}$/.test(id))}
// GET /api/crons/<id8> reply -> output state for the sheet; lines are redacted here as well
function outputView(reply,ok){if(!ok||!isObj(reply)||reply.error)return {fail:true};
 const lo=isObj(reply.last_output)?reply.last_output:null;if(!lo)return {none:true};
 const lines=arr(lo.lines).map(x=>redact(str(x,200))).filter(Boolean).slice(0,3);
 return lines.length?{lines,t:num(lo.t)}:{none:true}}
return {norm,flatten,sorted,matches,pick,row,lastText,nextText,chips,summary,view,unavailable,rank,isBad,isActive,retiredOf,RESULTS,shownOf,isHermes,opensOn,lastWords,nextWords,outputPart,sheet,cronIds,outputView}
})();
// ==== SCHEDULES UI HELPERS END ====
// ---- page glue (DOM + fetch) ----
(()=>{
 if(typeof document==='undefined')return;
 const css=document.createElement('style');
 css.textContent=[
  '#sched{height:100%;display:grid;grid-template-rows:auto auto minmax(0,1fr);gap:var(--sp-3);min-height:0;min-width:0}',
  '#scbar{display:flex;gap:var(--sp-3);align-items:center;min-width:0}',
  '#scq{flex:0 0 30%;min-width:0;height:var(--touch);border:0;border-radius:var(--r-control);background:var(--raised);box-shadow:var(--edge);color:var(--text-1);font:var(--fw-reg) 16px/1 var(--font);padding:0 var(--sp-4);user-select:text;-webkit-user-select:text;-webkit-appearance:none;appearance:none}',
  '#scq:focus{box-shadow:inset 0 0 0 2px var(--tint)}#scq::placeholder{color:var(--text-3)}#scf{flex:1}',
  '#scsum .secttl{margin-bottom:0}#scsum .frow.err{min-height:0}',
  '#sclist{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));grid-auto-rows:max-content;align-content:start;gap:var(--sp-2) var(--sp-3);min-height:0;overflow-y:auto;overflow-x:hidden;touch-action:pan-x pan-y;overscroll-behavior:contain;scrollbar-width:none;padding-bottom:var(--sp-3)}',
  '#sclist::-webkit-scrollbar{display:none}#sclist .tnote,#sclist .es{grid-column:1/-1}',
  '.scrow{display:flex;align-items:center;gap:var(--sp-3);background:var(--raised);box-shadow:var(--edge);border-radius:var(--r-control);padding:var(--sp-3) var(--sp-3) var(--sp-3) var(--sp-4);min-width:0;min-height:52px}',
  '.scrow .fl{flex:1;min-width:0;display:flex;flex-direction:column;gap:var(--sp-1)}',
  '.scrow .fl b{font-size:var(--fs-body);font-weight:var(--fw-semi);overflow:hidden;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;word-break:break-word}',
  '.scrow .fl small{font-size:var(--fs-micro);color:var(--text-3);font-variant-numeric:tabular-nums;overflow:hidden;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;word-break:break-word}',
  '.scrow .pill{flex:none}',
  '.scrow.bad{background:var(--bad-wash)}.scrow.bad small{color:var(--text-2)}',
  '.scrow.off b{color:var(--text-2)}',
  '.scrow[data-sched]{cursor:pointer}.scrow[data-sched]:active{transform:scale(.97)}.scrow[data-sched]:focus-visible{outline:2px solid var(--tint);outline-offset:2px}',
  '#sched.broken{grid-template-rows:minmax(0,1fr)}#sched.broken #scbar,#sched.broken #scsum{display:none}',
  '@media (orientation:portrait){#sched{height:auto;min-height:100%;grid-template-rows:none;align-content:start}#scq,#scf{flex:1 0 100%}#scbar{flex-wrap:wrap}#sclist{overflow:visible;-webkit-mask-image:none;mask-image:none;animation:none;grid-template-columns:minmax(0,1fr)}}'
 ].join('\n');
 document.head.appendChild(css);
 const SC={f:null,filter:localStorage.getItem('sched-view')||'active',q:''};
 function paintSched(){
  try{const v=SchedUI.view(SC.f,Date.now(),SC.filter,SC.q);$('#sched').classList.toggle('broken',v.broken);$('#scf').innerHTML=v.chips;$('#scsum').innerHTML=v.sum;$('#sclist').innerHTML=v.list}
  catch(e){$('#sched').classList.add('broken');$('#sclist').innerHTML=renderFail('All crons')}}
 window.v10Schedules=()=>once('schedules',async()=>{SC.f=await feedGet('schedules');paintSched()});
 let qT=0;
 $('#scq').addEventListener('input',()=>{clearTimeout(qT);qT=setTimeout(()=>{SC.q=$('#scq').value;paintSched()},120)});
 $('#scf').addEventListener('click',e=>{const b=e.target.closest('.scf');if(!b)return;SC.filter=b.dataset.f||'active';localStorage.setItem('sched-view',SC.filter);paintSched()});
 // deck.js runs deckPage() before this file exists, so the page the deck opens on is painted here
// tap or Enter/Space on an All crons row opens the detail sheet from deck.js (openSheet). Read only: GET requests only.
async function readJson(url){return jget(url).then(j=>({ok:true,j}),()=>({ok:false,j:null}))}
// a Hermes job's output: its name on the Hermes list picks the 8-char id, then GET /api/crons/<id8> returns its last run
async function lastOutput(j){const list=await readJson('/api/crons');if(!list.ok)return {fail:true};
 const ids=SchedUI.cronIds(list.j,j.name);
 if(ids.length===0)return {note:'this job is not on the Hermes job list, so it has no saved output here.'};
 if(ids.length>1)return {note:'more than one Hermes job has this name. Open it on the Crons tab.'};
 const r=await readJson('/api/crons/'+ids[0]);return SchedUI.outputView(r.j,r.ok)}
async function openDetail(el){
 const j=SchedUI.shownOf(SchedUI.flatten(SC.f),SC.filter,SC.q)[+el.dataset.sched];if(!j)return;
 const feedT=SC.f&&SC.f.t,spec=SchedUI.sheet(j,Date.now(),feedT,undefined);
 openSheet(spec,el);
 if(!SchedUI.isHermes(j))return;
 const tok=SHEET.tok;let out;
 try{out=await lastOutput(j)}catch(e){out={fail:true}}
 if(tok!==SHEET.tok||SHEET.spec!==spec)return;
 Object.assign(spec,SchedUI.sheet(j,Date.now(),feedT,out));paintSheet()}
$('#sclist').addEventListener('click',e=>{const el=e.target.closest&&e.target.closest('.scrow[data-sched]');if(el)openDetail(el)});
$('#sclist').addEventListener('keydown',e=>{if(!SchedUI.opensOn(e.key))return;const el=e.target.closest&&e.target.closest('.scrow[data-sched]');if(!el)return;e.preventDefault();openDetail(el)});
 if(!document.hidden&&pname()==='schedules')window.v10Schedules();
})();
