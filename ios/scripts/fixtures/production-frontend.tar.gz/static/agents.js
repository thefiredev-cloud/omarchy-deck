// Agents page: pick a mission and a target, read the message that opens, tap Send. Nothing starts until Send (owner feedback 2026-10-07, TestFlight build 11:
// "quick launch agents from here ... fix bugs, find bugs, security, product upgrades, polish ... fix crons"). The message goes through the run window's own
// composer (openCompose, then POST /api/run-send), so it is the same Hermes run path the cron sheets use. This file only reads feeds (GET) and builds text.
// Loaded after deck.js; uses DeckUI (esc, cleanText, line, state) and the page glue (once, feedGet, fillCols, renderFail, openCompose, buzz, $).
// ==== AGENTS UI HELPERS BEGIN (pure: no DOM, no fetch; tests/agents_ui.test.js loads this block with DeckUI injected) ====
const AgentsUI=(()=>{
 const {esc,cleanText}=DeckUI;
 const isObj=x=>x!==null&&typeof x==='object'&&!Array.isArray(x);
 const arr=x=>Array.isArray(x)?x:[];
 const str=(v,n)=>typeof v==='string'?v.trim().slice(0,n||80):'';
 const MAX=1500,ALL='all';
 // A message is plain text: the rules at the end say what the agent may and may not do, so a short list never loses them.
 const RULES='Rules: work in your own worktree, prove each change by running it, never push main, never deploy, never spend money, and ask me before anything that sends or posts outside. Reply with five short bullets at most.';
 const MISSIONS=[
  {id:'crons',label:'Fix failing crons',does:'Reads each failing job\u2019s log, fixes the cause and runs it again',kind:'crons'},
  {id:'ci',label:'Fix failing CI',does:'Reads the failing checks on main and fixes them on a branch',kind:'ci'},
  {id:'bugs',label:'Find bugs',does:'Reads and runs the code, lists real defects, fixes the safe ones',kind:'target'},
  {id:'security',label:'Security review',does:'Looks for exposed secrets, open ports and unsafe code',kind:'target'},
  {id:'upgrades',label:'Product upgrades',does:'Builds the changes a person would use most',kind:'target'},
  {id:'polish',label:'Polish and taste',does:'Fixes rough edges in layout, copy and feel',kind:'target'},
  {id:'profit',label:'Marketplace profit',does:'Finds what we can sell on Facebook Marketplace, eBay, Amazon, Walmart, OfferUp and Etsy',kind:'plain'}];
 const BAD={failed:1,overdue:1};
 // jobs the schedules feed calls failed or overdue, worst first as the feed lists them
 function failingJobs(sf){const out=[];
  arr(isObj(sf)&&sf.groups).filter(isObj).forEach(g=>arr(g.jobs).filter(isObj).forEach(j=>{if(BAD[str(j.result,12)]||arr(j.members).some(m=>isObj(m)&&m.status==='failed'))out.push({name:str(j.name,70)||'unnamed',host:str(j.host,24),result:BAD[str(j.result,12)]?str(j.result,12):'failed',detail:str(j.detail,60)})}));
  return out}
 const repoName=r=>{const s=str(r,80),i=s.lastIndexOf('/');return i>=0?s.slice(i+1):s};
// failing workflows on main, then open pull requests whose own checks fail, from the dev feed
function failingCi(df){const g=isObj(df)&&isObj(df.github)?df.github:{};
  const main=arr(g.failing_main).filter(isObj).map(x=>({repo:repoName(x.repo),workflow:str(x.workflow,60)})).filter(x=>x.repo);
  const prs=arr(g.open_prs).filter(isObj).filter(x=>str(x.ci,12)==='fail'&&Number.isFinite(x.num)).map(x=>({repo:repoName(x.repo),workflow:'pull request #'+x.num+(str(x.title,50)?': '+str(x.title,50):'')})).filter(x=>x.repo);
  return main.concat(prs)}
 const NAME=/^[A-Za-z0-9][A-Za-z0-9._-]{0,39}$/;
 // what an agent can be pointed at: repos with a failing main first, then repos with open pull requests, then Vercel projects; names only
 function targets(df){const g=isObj(df)&&isObj(df.github)?df.github:{},v=isObj(df)&&isObj(df.vercel)?df.vercel:{},seen=new Set(),out=[];
  const add=(n,repo)=>{n=repo?repoName(n):str(n,80);if(NAME.test(n)&&!seen.has(n)&&out.length<10){seen.add(n);out.push(n)}};
  arr(g.failing_main).filter(isObj).forEach(x=>add(x.repo,1));arr(g.open_prs).filter(isObj).forEach(x=>add(x.repo,1));arr(v.projects).filter(isObj).forEach(x=>add(x.name));
  return out}
 const cur=(sf,df)=>({crons:isObj(sf)?failingJobs(sf):null,ci:isObj(df)&&isObj(df.github)?failingCi(df):null});
 // the second line of a mission button: what it will act on right now
 function context(m,t,sf,df){const c=cur(sf,df);
  if(m.kind==='crons')return c.crons==null?'Job list not available':c.crons.length?c.crons.length+(c.crons.length===1?' job needs':' jobs need')+' a look':'Nothing failing now';
  if(m.kind==='ci')return c.ci==null?'Checks not available':c.ci.length?c.ci.length+(c.ci.length===1?' check is':' checks are')+' failing':'Everything is green';
  if(m.kind==='target')return 'On '+(t===ALL?'everything we ship':t);
  return 'Reads prices before it posts anything'}
 // list lines are cut whole, from the end, until the message fits; the rules are always the last paragraph
 function fit(head,lines,total,tail){let n=lines.length;
  for(;;){const more=total-n,body=head+'\n\n'+lines.slice(0,n).join('\n')+(more>0?'\n+ '+more+' more, in the same order the deck lists them':'')+'\n\n'+tail;
   if(Array.from(body).length<=MAX||n===0)return cleanText(body,MAX);n--}}
 function draft(id,t,sf,df){const m=MISSIONS.find(x=>x.id===id);if(!m)return '';const c=cur(sf,df),what=t===ALL||!NAME.test(String(t))?'everything we ship (the repos and sites on my Dev tab)':t;
  if(id==='crons'){const j=c.crons||[];
   return j.length?fit('Fix the scheduled jobs that are failing right now ('+j.length+'). For each one read its log, find the cause, fix the source, run it once and confirm it passes. Skip any that need me present and say which.',
     j.slice(0,12).map(x=>'- '+x.name+(x.host?' ('+x.host+')':'')+', '+x.result+(x.detail?': '+x.detail:'')),j.length,RULES)
    :cleanText('Check every scheduled job on my All crons tab. None showed as failing when I opened this, so look for jobs that report ok but have not really run lately, and fix the cause of any you find.\n\n'+RULES,MAX)}
  if(id==='ci'){const x=c.ci||[];
   return x.length?fit('Fix the checks failing right now ('+x.length+'): workflows on main and open pull requests. For each one read the failing log and fix the cause on a branch; a pull request uses its own branch, anything else gets a new pull request. Do not merge.',
     x.slice(0,10).map(r=>'- '+r.repo+(r.workflow?': '+r.workflow:'')),x.length,RULES)
    :cleanText('No checks showed as failing when I opened this. Read the latest runs on my repos, confirm they are green, and fix anything that is flaky or slow.\n\n'+RULES,MAX)}
  if(id==='bugs')return cleanText('Find bugs in '+what+'. Read the code and run it. List the real defects with a way to reproduce each, then fix the ones that are safe to fix and say what is left.\n\n'+RULES,MAX);
  if(id==='security')return cleanText('Review the security of '+what+'. Look for exposed secrets, open ports, unsafe input handling, weak auth and risky dependencies. Fix what is safe to fix and list the rest with the worst case for each.\n\n'+RULES,MAX);
  if(id==='upgrades')return cleanText('Find and build the three upgrades to '+what+' that a person would use most. Judge by real use, not by what sounds impressive. Show me a before and an after for each.\n\n'+RULES,MAX);
  if(id==='polish')return cleanText('Polish '+what+'. Fix rough edges in layout, copy and feel: anything cut off, crowded, inconsistent or generic. Keep what already works and show me a before and an after.\n\n'+RULES,MAX);
  return cleanText('Find ways for us to make money from what we already have. Search listings and prices on Facebook Marketplace, eBay, Amazon, Walmart, OfferUp and Etsy with the read-only tools first, rank the best opportunities by profit after fees, and draft the listings. Do not post, buy or message anyone without asking me.\n\n'+RULES,MAX)}
 const chip=(on,val,label)=>'<button type="button" class="b agt'+(on?' on':'')+'" data-t="'+esc(val)+'"'+(on?' aria-pressed="true"':' aria-pressed="false"')+'>'+esc(label)+'</button>';
 const mission=(m,t,sf,df)=>'<button type="button" class="b agm" data-m="'+m.id+'"><b>'+esc(m.label)+'</b><small>'+esc(m.does)+'</small><small class="agc">'+esc(context(m,t,sf,df))+'</small></button>';
 // three columns in landscape, one stack in portrait: intro and target, the five fix and find missions, the rest
 function view(sf,df,target){const list=targets(df),t=target===ALL||list.includes(target)?target:ALL;
  const intro='<section class="tsec"><div class="secttl"><span>Agents</span><span>Hermes runs them</span></div><div class="tnote">Pick a mission. The message opens for you to read and change. Nothing starts until you tap Send.</div></section>'+
   '<section class="tsec"><div class="secttl"><span>Aim at</span><span>'+esc(t===ALL?'Everything':t)+'</span></div><div class="chips wrap" role="group" aria-label="Target">'+chip(t===ALL,ALL,'Everything')+list.map(n=>chip(t===n,n,n)).join('')+'</div></section>';
  const fix=MISSIONS.slice(0,4),rest=MISSIONS.slice(4);
  return {t,cols:[intro,'<section class="tsec"><div class="secttl"><span>Fix and find</span></div><div class="agl">'+fix.map(m=>mission(m,t,sf,df)).join('')+'</div></section>',
   '<section class="tsec"><div class="secttl"><span>Improve and earn</span></div><div class="agl">'+rest.map(m=>mission(m,t,sf,df)).join('')+'</div></section>']}}
 return {MISSIONS,ALL,MAX,RULES,failingJobs,failingCi,targets,context,draft,view};
})();
// ==== AGENTS UI HELPERS END ====
// ---- page glue (DOM + fetch) ----
(()=>{
 if(typeof document==='undefined')return;
 const css=document.createElement('style');
 css.textContent=[
  '#agents .agl{display:flex;flex-direction:column;gap:var(--sp-3)}',
  '.fixrow{display:flex;flex-wrap:wrap;align-items:center;gap:var(--sp-2) var(--sp-3);margin:var(--sp-2) 0 var(--sp-3)}',
  'button.b.fix{flex:none;height:var(--touch);min-width:120px;padding:0 var(--sp-4);font-size:var(--fs-meta);box-shadow:none;background:color-mix(in srgb,var(--tint) 18%,var(--raised));color:var(--tint)}',
  '.fixrow small{flex:1 1 180px;min-width:0;font-size:var(--fs-micro);color:var(--text-3);line-height:1.35}',
  'button.b.agm{flex-direction:column;align-items:flex-start;justify-content:center;gap:var(--sp-1);min-height:76px;padding:var(--sp-3) var(--sp-4);text-align:left;width:100%;min-width:0;font-weight:var(--fw-reg)}',
  'button.b.agm b{font-size:var(--fs-body);font-weight:var(--fw-semi);color:var(--text-1)}',
  'button.b.agm small{font-size:var(--fs-meta);color:var(--text-2);line-height:1.4;max-width:100%;overflow-wrap:anywhere}',
  'button.b.agm small.agc{color:var(--tint);font-weight:var(--fw-semi)}',
  '#agents .chips.wrap{gap:var(--sp-2)}'
 ].join('\n');
 document.head.appendChild(css);
 const AG={sf:null,df:null,t:localStorage.getItem('agent-target')||AgentsUI.ALL};
 function paintAgents(){try{const v=AgentsUI.view(AG.sf,AG.df,AG.t);AG.t=v.t;fillCols(['ag1','ag2','ag3'],v.cols,'Agents')}catch(e){$('#ag1').innerHTML=renderFail('Agents')}}
 window.v11Agents=()=>once('agents',async()=>{[AG.sf,AG.df]=await Promise.all([feedGet('schedules'),feedGet('dev')]);paintAgents()});
 $('#agents').addEventListener('click',e=>{const t=e.target.closest&&e.target.closest('.agt'),m=e.target.closest&&e.target.closest('.agm');
  if(t){AG.t=t.dataset.t;localStorage.setItem('agent-target',AG.t);buzz('selection');paintAgents();return}
  if(m){buzz('light');openCompose(AgentsUI.draft(m.dataset.m,AG.t,AG.sf,AG.df),m)}});
 // "Fix these" on the All crons and Dev pages: read the feed again, open the message in the run window's composer. It sends nothing; Send is the second tap.
 document.addEventListener('click',async e=>{const b=e.target.closest&&e.target.closest('button.fix[data-fix]');if(!b||b.disabled)return;
  const kind=b.dataset.fix;if(kind!=='crons'&&kind!=='ci')return;b.disabled=true;buzz('light');
  try{const [sf,df]=await Promise.all([kind==='crons'?feedGet('schedules'):null,kind==='ci'?feedGet('dev'):null]);openCompose(AgentsUI.draft(kind,AgentsUI.ALL,sf,df),b)}
  catch(err){}finally{b.disabled=false}});
 // deck.js runs deckPage() before this file exists, so the page the deck opens on is painted here
 if(!document.hidden&&pname()==='agents')window.v11Agents();
})();
