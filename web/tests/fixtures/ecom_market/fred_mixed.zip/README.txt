----------------------------------------------------------------
FRED Graph Observations
Federal Reserve Economic Data, Federal Reserve Bank of St. Louis
Link: https://fred.stlouisfed.org
Help: https://fredhelp.stlouisfed.org
This data may be copyrighted. Please refer to the Terms of Use:
https://fred.stlouisfed.org/legal#fred-terms-faq
File Created: 2026-11-14 7:18 pm CST
----------------------------------------------------------------

---------  -----------------------------------------------------------------  ------------------------
ECOMPCTSA  E-Commerce Retail Sales as a Percent of Total Sales, Percent,      Data Updated: 2026-08-18
           Quarterly, Seasonally Adjusted
RSXFS      Advance Retail Sales: Retail Trade, Millions of Dollars, Monthly,  Data Updated: 2026-10-15
           Seasonally Adjusted
GASDESW    US Diesel Sales Price, Dollars per Gallon, Weekly, Not Seasonally  Data Updated: 2026-11-10
           Adjusted
---------  -----------------------------------------------------------------  ------------------------

